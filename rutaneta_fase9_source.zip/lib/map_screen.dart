import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' show LatLng;
import 'geo.dart';
import 'store.dart';

class _Zone {
  final String name;
  final LatLng center;
  final double perKm;
  final double radius;
  const _Zone(this.name, this.center, this.perKm, this.radius);
}

const List<_Zone> _zones = [
  _Zone('San Salvador', LatLng(13.6929, -89.2182), 0.45, 4500),
  _Zone('Santa Tecla', LatLng(13.6769, -89.2797), 0.62, 3500),
  _Zone('Soyapango', LatLng(13.7102, -89.1394), 0.30, 3500),
  _Zone('Apopa', LatLng(13.8069, -89.1792), 0.22, 3500),
];

Color _zoneColor(double v) {
  if (v >= 0.60) return const Color(0xFF5DFFAA);
  if (v >= 0.40) return const Color(0xFF00E676);
  if (v >= 0.25) return const Color(0xFFFFEB3B);
  return const Color(0xFFFF5263);
}

IconData _placeIcon(String category) {
  switch (category) {
    case 'Gasolinera':
      return Icons.local_gas_station;
    case 'Comida':
      return Icons.restaurant;
    case 'Farmacia':
    case 'Salud':
      return Icons.local_pharmacy;
    case 'Supermercado':
    case 'Minisúper':
    case 'Tienda':
      return Icons.storefront;
    case 'Mercado':
      return Icons.store_mall_directory;
    case 'Finanzas':
      return Icons.account_balance;
    case 'Automotriz':
      return Icons.car_repair;
    case 'Transporte':
      return Icons.directions_bus;
    case 'Alimentos':
      return Icons.bakery_dining;
    case 'Ropa y belleza':
      return Icons.checkroom;
    case 'Tecnología':
      return Icons.devices_other;
    case 'Turismo':
      return Icons.hotel;
    case 'Recreación':
      return Icons.park;
    case 'Servicios':
      return Icons.miscellaneous_services;
    case 'Oficina':
      return Icons.business_center;
    case 'Educación':
      return Icons.school;
    case 'Taller':
      return Icons.handyman;
    case 'Semáforo':
      return Icons.traffic;
    default:
      return Icons.place;
  }
}

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});
  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final MapController controller = MapController();
  LatLng? me;
  List<NearbyPlace> places = [];
  TrafficRouteInfo? traffic;
  String category = 'Todos';
  int radiusKm = 5;
  double zoom = 11;
  bool showNames = true;
  bool loading = false;
  bool placesLoading = false;
  bool trafficLoading = false;

  Future<void> _locate() async {
    setState(() => loading = true);
    try {
      final p = await currentLatLng();
      if (!mounted) return;
      if (p == null) {
        _message('Activa la ubicación y da el permiso');
        return;
      }
      setState(() => me = p);
      controller.move(p, 14);
      await _loadPlaces(p);
    } catch (_) {
      if (mounted) _message('No pude obtener tu ubicación');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _loadPlaces(LatLng point) async {
    setState(() => placesLoading = true);
    try {
      final result = await nearbyPlaces(point, radiusMeters: radiusKm * 1000);
      if (mounted) {
        setState(() => places = result);
        if (result.isEmpty) {
          _message(
            'No hay locales cargados en este radio. Revisa la conexión o amplía la búsqueda.',
          );
        }
      }
    } catch (_) {
      if (mounted) _message('No se pudieron cargar los locales cercanos');
    } finally {
      if (mounted) setState(() => placesLoading = false);
    }
  }

  void _showPlaceDetails(NearbyPlace place) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    _placeIcon(place.category),
                    color: Theme.of(context).colorScheme.primary,
                    size: 32,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      place.name,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                '${place.category} · ${place.distanceKm.toStringAsFixed(1)} km',
              ),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(sheetContext);
                  controller.move(place.point, 16);
                },
                icon: const Icon(Icons.center_focus_strong),
                label: const Text('Centrar en el mapa'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showPlacesList() {
    final filtered = category == 'Todos'
        ? places
        : places.where((place) => place.category == category).toList();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.72,
        minChildSize: 0.42,
        maxChildSize: 0.92,
        builder: (context, scrollController) => Container(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: SafeArea(
            top: false,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Locales y servicios',
                              style: Theme.of(context).textTheme.titleLarge
                                  ?.copyWith(fontWeight: FontWeight.bold),
                            ),
                            Text(
                              '${filtered.length} resultados · radio de $radiusKm km',
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: 'Cerrar',
                        onPressed: () => Navigator.pop(sheetContext),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),
                Expanded(
                  child: ListView.separated(
                    controller: scrollController,
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final place = filtered[index];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Theme.of(
                            context,
                          ).colorScheme.primary.withAlpha(35),
                          child: Icon(
                            _placeIcon(place.category),
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                        title: Text(
                          place.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Text(place.category),
                        trailing: Text(
                          '${place.distanceKm.toStringAsFixed(1)} km',
                        ),
                        onTap: () {
                          Navigator.pop(sheetContext);
                          controller.move(place.point, 16);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _trafficToHome() async {
    if (me == null) {
      await _locate();
    }
    if (me == null || !store.hasHome) {
      _message('Activa Mi ubicación y guarda tu casa en Ajustes');
      return;
    }
    setState(() => trafficLoading = true);
    try {
      final result = await trafficRoute(
        GeoPoint(me!.latitude, me!.longitude),
        GeoPoint(store.homeLat!, store.homeLon!),
      );
      if (!mounted) return;
      if (result == null) {
        _message('Mapbox no pudo calcular el tráfico en este momento');
      } else {
        setState(() => traffic = result);
        if (result.points.isNotEmpty) {
          controller.fitCamera(
            CameraFit.coordinates(
              coordinates: result.points,
              padding: const EdgeInsets.all(70),
            ),
          );
        }
      }
    } catch (_) {
      if (mounted) _message('No se pudo consultar el tráfico');
    } finally {
      if (mounted) setState(() => trafficLoading = false);
    }
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final home = store.hasHome ? LatLng(store.homeLat!, store.homeLon!) : null;
    final visiblePlaces = category == 'Todos'
        ? places
        : places.where((p) => p.category == category).toList();
    final categories = <String>{
      'Todos',
      ...places.map((p) => p.category),
    }.toList();
    final labelsOnMap = showNames && zoom >= 14;
    final trafficColor = traffic?.congestion.any((c) => c == 'severe') == true
        ? Colors.red
        : traffic?.congestion.any((c) => c == 'heavy') == true
        ? Colors.orange
        : Colors.green;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mapa y tráfico'),
        actions: [
          IconButton(
            tooltip: 'Cargar locales',
            onPressed: me == null || placesLoading
                ? null
                : () => _loadPlaces(me!),
            icon: placesLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: controller,
            options: MapOptions(
              initialCenter: LatLng(13.72, -89.2),
              initialZoom: 11,
              interactionOptions: InteractionOptions(
                flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
              ),
              onPositionChanged: (camera, hasGesture) {
                if (!mounted || (camera.zoom - zoom).abs() < 0.5) return;
                setState(() => zoom = camera.zoom);
              },
            ),
            children: [
              TileLayer(
                urlTemplate:
                    'https://basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
                userAgentPackageName: 'com.rutaviva.rutaviva',
              ),
              RichAttributionWidget(
                alignment: AttributionAlignment.bottomLeft,
                popupBackgroundColor: const Color(0xFF20212D),
                showFlutterMapAttribution: false,
                attributions: const [
                  TextSourceAttribution('© OpenStreetMap contributors'),
                  TextSourceAttribution('© CARTO'),
                ],
              ),
              CircleLayer(
                circles: [
                  for (final z in _zones)
                    CircleMarker(
                      point: z.center,
                      radius: z.radius,
                      useRadiusInMeter: true,
                      color: _zoneColor(z.perKm).withAlpha(30),
                      borderColor: _zoneColor(z.perKm),
                      borderStrokeWidth: 2,
                    ),
                ],
              ),
              if (traffic != null && traffic!.points.length > 1)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: traffic!.points,
                      strokeWidth: 7,
                      color: trafficColor,
                    ),
                  ],
                ),
              MarkerLayer(
                markers: [
                  for (final p in visiblePlaces)
                    Marker(
                      point: p.point,
                      width: labelsOnMap ? 178 : 44,
                      height: labelsOnMap ? 52 : 44,
                      child: GestureDetector(
                        onTap: () => _showPlaceDetails(p),
                        child: labelsOnMap
                            ? Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 5,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xF2181924),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: const Color(0xFF00D96A),
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      blurRadius: 8,
                                      color: Colors.black54,
                                    ),
                                  ],
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      _placeIcon(p.category),
                                      color: const Color(0xFF00D96A),
                                      size: 20,
                                    ),
                                    const SizedBox(width: 6),
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            p.name,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 11,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          Text(
                                            '${p.category} · ${p.distanceKm.toStringAsFixed(1)} km',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              color: Color(0xFFC7CBD4),
                                              fontSize: 9,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFF20212D),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: const Color(0xFF00D96A),
                                    width: 2,
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      blurRadius: 4,
                                      color: Colors.black38,
                                    ),
                                  ],
                                ),
                                child: Icon(
                                  _placeIcon(p.category),
                                  color: const Color(0xFF00D96A),
                                  size: 24,
                                ),
                              ),
                      ),
                    ),
                  for (final z in _zones)
                    Marker(
                      point: z.center,
                      width: 110,
                      height: 44,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xEE151621),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: _zoneColor(z.perKm)),
                          boxShadow: [
                            BoxShadow(
                              color: _zoneColor(z.perKm).withAlpha(70),
                              blurRadius: 12,
                            ),
                          ],
                        ),
                        child: Text(
                          '${z.name}\n\$${z.perKm.toStringAsFixed(2)}/km',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ),
                  if (home != null)
                    Marker(
                      point: home,
                      width: 40,
                      height: 40,
                      child: const Icon(
                        Icons.home,
                        color: Colors.orange,
                        size: 34,
                      ),
                    ),
                  if (me != null)
                    Marker(
                      point: me!,
                      width: 40,
                      height: 40,
                      child: const Icon(
                        Icons.my_location,
                        color: Color(0xFF00D96A),
                        size: 34,
                      ),
                    ),
                ],
              ),
            ],
          ),
          Positioned(
            top: 8,
            left: 8,
            right: 8,
            child: SafeArea(
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Locales y zonas rentables',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      SizedBox(
                        height: 38,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: categories.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 6),
                          itemBuilder: (_, i) => ChoiceChip(
                            label: Text(categories[i]),
                            selected: category == categories[i],
                            onSelected: (_) =>
                                setState(() => category = categories[i]),
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      SizedBox(
                        height: 36,
                        child: ListView(
                          scrollDirection: Axis.horizontal,
                          children: [
                            for (final radius in [5, 10, 20])
                              Padding(
                                padding: const EdgeInsets.only(right: 6),
                                child: ChoiceChip(
                                  label: Text('$radius km'),
                                  selected: radiusKm == radius,
                                  onSelected: (selected) {
                                    if (!selected) return;
                                    setState(() => radiusKm = radius);
                                    if (me != null) _loadPlaces(me!);
                                  },
                                ),
                              ),
                          ],
                        ),
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              places.isEmpty
                                  ? 'Pulsa «Mi ubicación» para buscar locales'
                                  : '${visiblePlaces.length} locales visibles · radio $radiusKm km',
                              style: Theme.of(context).textTheme.bodySmall,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          IconButton(
                            tooltip: showNames
                                ? 'Ocultar nombres en el mapa'
                                : 'Mostrar nombres al acercar',
                            onPressed: () =>
                                setState(() => showNames = !showNames),
                            icon: Icon(
                              showNames
                                  ? Icons.label_outline
                                  : Icons.label_off_outlined,
                            ),
                          ),
                        ],
                      ),
                      if (traffic != null) ...[
                        const SizedBox(height: 6),
                        Text(
                          'Tráfico a casa: ${traffic!.km.toStringAsFixed(1)} km · ${traffic!.minutes.toStringAsFixed(0)} min',
                          style: TextStyle(
                            color: trafficColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton.extended(
            heroTag: 'traffic',
            onPressed: trafficLoading ? null : _trafficToHome,
            icon: trafficLoading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.traffic),
            label: const Text('Tráfico a casa'),
          ),
          if (places.isNotEmpty) ...[
            const SizedBox(height: 10),
            FloatingActionButton.extended(
              heroTag: 'places',
              onPressed: _showPlacesList,
              icon: const Icon(Icons.storefront_outlined),
              label: Text('Locales (${visiblePlaces.length})'),
            ),
          ],
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            heroTag: 'location',
            onPressed: loading ? null : _locate,
            icon: loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.my_location),
            label: const Text('Mi ubicación'),
          ),
        ],
      ),
    );
  }
}
