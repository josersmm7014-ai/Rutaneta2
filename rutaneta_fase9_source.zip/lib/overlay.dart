import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'capture.dart';
import 'models.dart';
import 'ocr.dart';
import 'store.dart';

/// Lado de la app principal: abre/cierra la burbuja, le envía datos y
/// atiende el botón CALCULAR (captura + lectura + veredicto).
class OverlayCtrl {
  static bool _listening = false;
  static bool _busy = false;
  static OcrResult? _pendingCapture;

  /// Llamar una vez al iniciar la app.
  static void init() {
    if (_listening) return;
    _listening = true;
    store.addListener(push);
    FlutterOverlayWindow.overlayListener.listen((event) {
      if (event == 'toggleHome') {
        store.toggleHomeMode();
      } else if (event == 'ready') {
        push();
      } else if (event == 'capture') {
        _handleCapture();
      } else if (event == 'acceptCapture') {
        _acceptCapture();
      } else if (event == 'retryCapture') {
        _handleCapture();
      }
    });
  }

  static Future<bool> isActive() => FlutterOverlayWindow.isActive();

  /// Pide el permiso de dibujar sobre otras apps y abre la burbuja.
  static Future<bool> start() async {
    var ok = await FlutterOverlayWindow.isPermissionGranted();
    if (!ok) {
      ok = (await FlutterOverlayWindow.requestPermission()) ?? false;
    }
    if (!ok) return false;
    if (!await FlutterOverlayWindow.isActive()) {
      await FlutterOverlayWindow.showOverlay(
        enableDrag: true,
        overlayTitle: 'RutaNeta',
        overlayContent: 'Burbuja activa',
        flag: OverlayFlag.defaultFlag,
        visibility: NotificationVisibility.visibilityPublic,
        positionGravity: PositionGravity.auto,
        height: 480,
        width: 640,
      );
    }
    Future.delayed(const Duration(milliseconds: 800), push);
    return true;
  }

  static Future<void> stop() async {
    if (await FlutterOverlayWindow.isActive()) {
      await FlutterOverlayWindow.closeOverlay();
    }
  }

  static Future<void> _send(Map<String, dynamic> data) async {
    try {
      if (!await FlutterOverlayWindow.isActive()) return;
      await FlutterOverlayWindow.shareData(jsonEncode(data));
    } catch (_) {
      // Si la burbuja no está lista, se reintenta en el próximo cambio.
    }
  }

  static Future<void> push() async {
    final trips = store.todayTrips;
    final net = trips.fold<double>(0, (s, t) => s + t.net);
    final hours = trips.fold<double>(0, (s, t) => s + t.hours);
    final kmPass = trips.fold<double>(0, (s, t) => s + t.km);
    final kmEmpty = trips.fold<double>(
      0,
      (s, t) => s + (t.returnEmpty ? t.km : 0),
    );
    await _send({
      'net': net,
      'perHour': hours > 0 ? net / hours : 0.0,
      'kmPass': kmPass,
      'kmEmpty': kmEmpty,
      'homeMode': store.homeMode,
    });
  }

  /// Toma la pantalla, lee precio/km/minutos y manda el veredicto a la burbuja.
  static Future<void> _handleCapture() async {
    if (_busy) return;
    _busy = true;
    try {
      if (!store.canCalc) {
        await _send({
          'state': 'error',
          'msg':
              'Llegaste al límite de ${freeCalcsPerDay} cálculos de hoy. Abre RutaNeta para más información.',
        });
        return;
      }
      // Espera a que la burbuja se oculte de la captura.
      await Future<void>.delayed(const Duration(milliseconds: 450));
      final path = await Capture.capture();
      if (path == null) {
        await _send({
          'state': 'error',
          'msg':
              'La captura no está activa. Abre RutaNeta y vuelve a activar el modo flotante.',
        });
        return;
      }
      final r = await readScreenshot(path);
      final v = store.vehicle;
      if (v == null) {
        await _send({
          'state': 'error',
          'msg': 'Configura tu vehículo antes de calcular',
        });
        return;
      }
      _pendingCapture = r;
      if (r.price == null || r.km == null || r.minutes == null) {
        final found = <String>[
          if (r.price != null) 'precio',
          if (r.km != null) 'km',
          if (r.minutes != null) 'minutos',
        ];
        await _send({
          'state': 'review',
          'price': r.price,
          'km': r.km,
          'minutes': r.minutes,
          'msg': found.isEmpty
              ? 'No pude leer datos. Toca REINTENTAR.'
              : 'Solo pude leer: ${found.join(', ')}. Falta completar el viaje.',
        });
        return;
      }
      await _send({
        'state': 'review',
        'price': r.price,
        'km': r.km,
        'minutes': r.minutes,
        'msg': 'Revisa los datos antes de calcular',
      });
    } catch (_) {
      await _send({
        'state': 'error',
        'msg': 'Error al leer la pantalla. Toca REINTENTAR.',
      });
    } finally {
      _busy = false;
    }
  }

  static Future<void> _acceptCapture() async {
    final r = _pendingCapture;
    final v = store.vehicle;
    if (r == null ||
        v == null ||
        r.price == null ||
        r.km == null ||
        r.minutes == null) {
      await _send({
        'state': 'error',
        'msg': 'Falta algún dato. Toca REINTENTAR.',
      });
      return;
    }
    // La captura/OCR es asíncrona; vuelve a revisar la cuota justo antes
    // de contar el cálculo para evitar excederla si se usó otra pantalla.
    if (!store.canCalc) {
      await _send({
        'state': 'error',
        'msg':
            'Llegaste al límite de ${freeCalcsPerDay} cálculos de hoy. Abre RutaNeta para más información.',
      });
      return;
    }
    store.useCalc();
    final trip = Trip(
      id: 'tmp',
      date: DateTime.now(),
      origin: '',
      destination: '',
      price: r.price!,
      km: r.km!,
      minutes: r.minutes!,
      returnEmpty: true,
      fuelCost: v.fuelCostFor(r.km! * 2),
    );
    await _send({
      'state': 'result',
      'verdict': trip.verdict,
      'perHour': trip.perHour,
      'net': trip.net,
      'price': trip.price,
      'km': trip.km,
      'minutes': trip.minutes,
    });
  }
}

/// Lado de la burbuja (corre en su propio proceso de Flutter).
class OverlayBubble extends StatefulWidget {
  const OverlayBubble({super.key});

  @override
  State<OverlayBubble> createState() => _OverlayBubbleState();
}

enum _Mode { idle, loading, review, result, error }

class _OverlayBubbleState extends State<OverlayBubble> {
  bool compact = false;
  double net = 0;
  double perHour = 0;
  double kmPass = 0;
  double kmEmpty = 0;
  bool homeMode = false;

  _Mode mode = _Mode.idle;
  String verdict = '';
  double rPerHour = 0;
  double rNet = 0;
  double rPrice = 0;
  double rKm = 0;
  double rMin = 0;
  String errorMsg = '';
  double? detectedPrice;
  double? detectedKm;
  double? detectedMinutes;
  Timer? _timer;
  StreamSubscription? _sub;

  @override
  void initState() {
    super.initState();
    _sub = FlutterOverlayWindow.overlayListener.listen(_onData);
    FlutterOverlayWindow.shareData('ready');
  }

  void _onData(dynamic event) {
    try {
      final m = jsonDecode('$event') as Map<String, dynamic>;
      if (m.containsKey('state')) {
        final st = m['state'] as String;
        if (st == 'review') {
          setState(() {
            mode = _Mode.review;
            detectedPrice = (m['price'] as num?)?.toDouble();
            detectedKm = (m['km'] as num?)?.toDouble();
            detectedMinutes = (m['minutes'] as num?)?.toDouble();
            errorMsg = (m['msg'] as String?) ?? 'Revisa los datos';
          });
          return;
        }
        if (st == 'result') {
          setState(() {
            mode = _Mode.result;
            verdict = m['verdict'] as String;
            rPerHour = (m['perHour'] as num).toDouble();
            rNet = (m['net'] as num).toDouble();
            rPrice = (m['price'] as num).toDouble();
            rKm = (m['km'] as num).toDouble();
            rMin = (m['minutes'] as num).toDouble();
          });
          _backToIdleIn(12);
        } else {
          setState(() {
            mode = _Mode.error;
            errorMsg = (m['msg'] as String?) ?? 'Error';
          });
          _backToIdleIn(7);
        }
        return;
      }
      setState(() {
        net = (m['net'] as num).toDouble();
        perHour = (m['perHour'] as num).toDouble();
        kmPass = (m['kmPass'] as num).toDouble();
        kmEmpty = (m['kmEmpty'] as num).toDouble();
        homeMode = m['homeMode'] as bool;
      });
    } catch (_) {}
  }

  void _backToIdleIn(int seconds) {
    _timer?.cancel();
    _timer = Timer(Duration(seconds: seconds), () {
      if (mounted) setState(() => mode = _Mode.idle);
    });
  }

  void _calculate() {
    _timer?.cancel();
    // Primero se oculta todo texto con dólares para que no salga en la captura.
    setState(() => mode = _Mode.loading);
    FlutterOverlayWindow.shareData('capture');
    _backToIdleIn(15);
  }

  Future<void> _setCompact(bool value) async {
    setState(() => compact = value);
    await FlutterOverlayWindow.resizeOverlay(
      value ? 190 : 640,
      value ? 120 : 480,
      true,
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _sub?.cancel();
    super.dispose();
  }

  String _m(double v) => '\$${v.toStringAsFixed(2)}';

  Color _color(String v) {
    if (v == 'CONVIENE') return const Color(0xFF1B8E5A);
    if (v == 'DUDOSO') return const Color(0xFFE0A100);
    return const Color(0xFFC62828);
  }

  @override
  Widget build(BuildContext context) {
    if (compact) {
      return Material(
        color: Colors.transparent,
        child: GestureDetector(
          onTap: () => _setCompact(false),
          child: Container(
            margin: const EdgeInsets.all(4),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: const Color(0xEE101614),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(color: const Color(0xFF4ADE80), width: 2),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.route, color: Color(0xFF4ADE80), size: 24),
                SizedBox(width: 7),
                Text(
                  'RutaNeta',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(width: 5),
                Icon(Icons.open_in_full, color: Colors.white70, size: 18),
              ],
            ),
          ),
        ),
      );
    }
    const green = Color(0xFF1B8E5A);
    Widget body;
    Color border = green;

    if (mode == _Mode.loading) {
      body = const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 28,
              height: 28,
              child: CircularProgressIndicator(strokeWidth: 3),
            ),
            SizedBox(height: 10),
            Text(
              'Calculando…',
              style: TextStyle(color: Colors.white, fontSize: 16),
            ),
          ],
        ),
      );
    } else if (mode == _Mode.review) {
      body = Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            errorMsg,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, fontSize: 14),
          ),
          const SizedBox(height: 8),
          Text(
            'Precio: ${detectedPrice == null ? 'NO LEÍDO' : _m(detectedPrice!)}',
            style: const TextStyle(color: Colors.white, fontSize: 17),
          ),
          Text(
            'Distancia: ${detectedKm == null ? 'NO LEÍDA' : '${detectedKm!.toStringAsFixed(1)} km'}',
            style: const TextStyle(color: Colors.white, fontSize: 17),
          ),
          Text(
            'Tiempo: ${detectedMinutes == null ? 'NO LEÍDO' : '${detectedMinutes!.toStringAsFixed(0)} min'}',
            style: const TextStyle(color: Colors.white, fontSize: 17),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: FilledButton(
                  onPressed:
                      detectedPrice != null &&
                          detectedKm != null &&
                          detectedMinutes != null
                      ? () => FlutterOverlayWindow.shareData('acceptCapture')
                      : null,
                  child: const Text('ACEPTAR'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton(
                  onPressed: () =>
                      FlutterOverlayWindow.shareData('retryCapture'),
                  child: const Text('REINTENTAR'),
                ),
              ),
            ],
          ),
        ],
      );
    } else if (mode == _Mode.result) {
      border = _color(verdict);
      body = GestureDetector(
        onTap: () => setState(() => mode = _Mode.idle),
        child: Container(
          decoration: BoxDecoration(
            color: _color(verdict),
            borderRadius: BorderRadius.circular(14),
          ),
          padding: const EdgeInsets.all(10),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  verdict,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  '${_m(rPerHour)} por hora',
                  style: const TextStyle(color: Colors.white, fontSize: 20),
                ),
                Text(
                  'Neto ${_m(rNet)} de ${_m(rPrice)}',
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                ),
                Text(
                  '${rKm.toStringAsFixed(1)} km · ${rMin.toStringAsFixed(0)} min (con regreso vacío)',
                  style: const TextStyle(color: Colors.white70, fontSize: 12),
                ),
                const SizedBox(height: 4),
                const Text(
                  'Toca para cerrar',
                  style: TextStyle(color: Colors.white70, fontSize: 11),
                ),
              ],
            ),
          ),
        ),
      );
    } else if (mode == _Mode.error) {
      border = Colors.orange;
      body = GestureDetector(
        onTap: () => setState(() => mode = _Mode.idle),
        child: Center(
          child: Text(
            errorMsg,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, fontSize: 14),
          ),
        ),
      );
    } else {
      body = Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'Neto hoy: ${_m(net)}',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 15,
            ),
          ),
          Text(
            '${_m(perHour)} por hora · ${kmPass.toStringAsFixed(1)} km con pasajero · ${kmEmpty.toStringAsFixed(1)} vacíos',
            style: const TextStyle(color: Colors.white70, fontSize: 11),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 76,
            child: FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF4ADE80),
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              onPressed: _calculate,
              child: const Text(
                'CALCULAR',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 56,
            child: FilledButton(
              style: FilledButton.styleFrom(
                backgroundColor: homeMode
                    ? const Color(0xFFFFD54F)
                    : const Color(0xFF303936),
                foregroundColor: homeMode ? Colors.black : Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 12),
              ),
              onPressed: () => FlutterOverlayWindow.shareData('toggleHome'),
              child: Text(
                homeMode ? 'Hacia casa: ACTIVO' : 'Hacia casa',
                style: const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      );
    }

    return Material(
      color: Colors.transparent,
      child: Container(
        margin: const EdgeInsets.all(4),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: const Color(0xEE101614),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: border, width: 2),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'RutaNeta',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                ),
                IconButton(
                  tooltip: 'Reducir burbuja',
                  style: IconButton.styleFrom(
                    minimumSize: const Size.square(56),
                  ),
                  onPressed: () => _setCompact(true),
                  icon: const Icon(
                    Icons.minimize,
                    color: Colors.white,
                    size: 26,
                  ),
                ),
                IconButton(
                  tooltip: 'Cerrar burbuja',
                  style: IconButton.styleFrom(
                    minimumSize: const Size.square(56),
                    iconSize: 28,
                  ),
                  onPressed: () => FlutterOverlayWindow.closeOverlay(),
                  icon: const Icon(Icons.close, color: Colors.white, size: 26),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Expanded(child: body),
          ],
        ),
      ),
    );
  }
}
