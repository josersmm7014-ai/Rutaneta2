import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:latlong2/latlong.dart';
import 'package:rutaviva/geo.dart';

Map<String, dynamic> _route({
  required double distance,
  required double duration,
  double? typical,
  required List<List<double>> coordinates,
  required List<Map<String, dynamic>> legs,
}) {
  return {
    'distance': distance,
    'duration': duration,
    if (typical != null) 'duration_typical': typical,
    'geometry': {'type': 'LineString', 'coordinates': coordinates},
    'legs': legs,
  };
}

Map<String, dynamic> _annotation({
  List<dynamic>? congestion,
  List<dynamic>? numeric,
  List<dynamic>? duration,
  List<dynamic>? distance,
}) {
  return {
    if (congestion != null) 'congestion': congestion,
    if (numeric != null) 'congestion_numeric': numeric,
    if (duration != null) 'duration': duration,
    if (distance != null) 'distance': distance,
  };
}

http.Client _client(Map<String, dynamic> route, void Function(Uri)? onUri) {
  return MockClient((request) async {
    onUri?.call(request.url);
    return http.Response(
      jsonEncode({
        'code': 'Ok',
        'routes': [route],
      }),
      200,
      headers: {'content-type': 'application/json'},
    );
  });
}

void main() {
  test(
    'construye URL Uri.https, convierte unidades y deriva segmentos',
    () async {
      Uri? requested;
      final route = _route(
        distance: 4000,
        duration: 900,
        typical: 600,
        coordinates: [
          [-89.20, 13.70],
          [-89.19, 13.71],
          [-89.18, 13.72],
        ],
        legs: [
          {
            'annotation': _annotation(
              congestion: ['low', 'unknown'],
              numeric: [10, 0],
              duration: [450, 450],
              distance: [1000, 3000],
            ),
          },
        ],
      );

      final result = await trafficRoute(
        const GeoPoint(13.70, -89.20),
        const GeoPoint(13.72, -89.18),
        client: _client(route, (uri) => requested = uri),
      );

      expect(result, isNotNull);
      expect(result!.km, 4);
      expect(result.minutes, 15);
      expect(result.typicalMinutes, 10);
      expect(result.delayMinutes, 5);
      expect(result.source, 'Mapbox');
      expect(result.checkedAt, isNotNull);
      expect(result.checkedAt!.isUtc, isFalse);
      expect(result.points, hasLength(3));
      expect(result.congestion, ['low', 'unknown']);
      expect(result.segments, hasLength(2));
      expect(result.segments[0].points, [
        const LatLng(13.70, -89.20),
        const LatLng(13.71, -89.19),
      ]);
      expect(result.segments[0].congestion, 'low');
      expect(result.segments[1].congestion, 'unknown');
      expect(result.hasTrafficData, isTrue);
      expect(result.coverageRatio, closeTo(1000 / 4000, 0.000001));
      expect(result.status, 'Fluido');

      expect(requested, isNotNull);
      expect(requested!.scheme, 'https');
      expect(requested!.host, 'api.mapbox.com');
      expect(
        requested!.path,
        '/directions/v5/mapbox/driving-traffic/-89.2,13.7;-89.18,13.72',
      );
      expect(
        requested!.queryParameters['annotations'],
        'congestion,congestion_numeric,duration,distance',
      );
      expect(requested!.queryParameters['overview'], 'full');
      expect(requested!.queryParameters['geometries'], 'geojson');
      expect(requested!.queryParameters.containsKey('future_depart'), isFalse);
      expect(requested!.queryParameters['access_token'], startsWith('pk.'));
    },
  );

  test(
    'concatena anotaciones de todas las legs sin desplazar segmentos',
    () async {
      final result = await trafficRoute(
        const GeoPoint(13.70, -89.20),
        const GeoPoint(13.72, -89.18),
        client: _client(
          _route(
            distance: 2000,
            duration: 300,
            coordinates: [
              [-89.20, 13.70],
              [-89.19, 13.71],
              [-89.18, 13.72],
            ],
            legs: [
              {
                'annotation': _annotation(congestion: ['low'], distance: [750]),
              },
              {
                'annotation': _annotation(
                  congestion: ['heavy'],
                  distance: [1250],
                ),
              },
            ],
          ),
          null,
        ),
      );

      expect(result, isNotNull);
      expect(result!.congestion, ['low', 'heavy']);
      expect(result.segments.map((segment) => segment.congestion), [
        'low',
        'heavy',
      ]);
      expect(result.status, 'Alto');
      expect(result.coverageRatio, 1);
    },
  );

  test('mantiene unknown para annotation ausente o incompleta', () async {
    final result = await trafficRoute(
      const GeoPoint(13.70, -89.20),
      const GeoPoint(13.71, -89.19),
      client: _client(
        _route(
          distance: 1000,
          duration: 60,
          coordinates: [
            [-89.20, 13.70],
            [-89.19, 13.71],
            [-89.18, 13.72],
          ],
          legs: [
            {
              'annotation': _annotation(congestion: ['moderate']),
            },
          ],
        ),
        null,
      ),
    );

    expect(result, isNotNull);
    expect(result!.congestion, ['moderate', 'unknown']);
    expect(result.hasTrafficData, isTrue);
    expect(result.coverageRatio, 0.5);
    expect(result.segments[1].congestion, 'unknown');
  });

  test('devuelve null para HTTP fallido y payload inválido', () async {
    final failed = await trafficRoute(
      const GeoPoint(13.70, -89.20),
      const GeoPoint(13.71, -89.19),
      client: MockClient(
        (_) async => http.Response('service unavailable', 503),
      ),
    );
    final invalid = await trafficRoute(
      const GeoPoint(13.70, -89.20),
      const GeoPoint(13.71, -89.19),
      client: MockClient((_) async => http.Response('{"routes":[{}]}', 200)),
    );

    expect(failed, isNull);
    expect(invalid, isNull);
  });
}
