import 'package:flutter_test/flutter_test.dart';
import 'package:rutaviva/fare_recommendation.dart';
import 'package:rutaviva/models.dart';

Trip _trip({
  double price = 7,
  double km = 10,
  double minutes = 30,
  bool returnEmpty = false,
  double fuelCost = 2,
}) {
  return Trip(
    id: 'test',
    date: DateTime(2026, 1, 1),
    origin: 'A',
    destination: 'B',
    price: price,
    km: km,
    minutes: minutes,
    returnEmpty: returnEmpty,
    fuelCost: fuelCost,
  );
}

void main() {
  group('recommendFare', () {
    test(
      'calcula referencia y redondea cada tarifa hacia arriba a centavos',
      () {
        final result = recommendFare(_trip(), targetNetPerHour: 10);

        expect(result.breakEvenFare, 2.71);
        expect(result.recommendedFare, 8.59);
        expect(result.requiredIncrease, 1.59);
        expect(result.targetNetPerHour, 10);
        expect(result.projectedNet, closeTo(5.0015, 1e-12));
        expect(result.projectedPerHour, closeTo(10.003, 1e-12));
      },
    );

    test(
      'la tarifa recomendada garantiza el objetivo después del redondeo',
      () {
        final result = recommendFare(
          _trip(fuelCost: 1.37, km: 12.5, minutes: 47),
          targetNetPerHour: 8.75,
        );

        expect(result.recommendedFare, greaterThanOrEqualTo(0));
        expect(result.projectedPerHour, greaterThanOrEqualTo(8.75 - 1e-9));
        expect(result.projectedNet, greaterThanOrEqualTo(0));
      },
    );

    test('duplica recorrido, desgaste y horas cuando hay regreso vacío', () {
      final result = recommendFare(
        _trip(returnEmpty: true),
        targetNetPerHour: 10,
      );

      expect(result.breakEvenFare, 3.06);
      expect(result.recommendedFare, 14.83);
      expect(result.requiredIncrease, 7.83);
      expect(result.projectedNet, closeTo(10.0055, 1e-12));
      expect(result.projectedPerHour, closeTo(10.0055, 1e-12));
    });

    test('semáforo verde en el límite de objetivo neto por hora', () {
      final result = recommendFare(
        _trip(price: 11.3 / .85, fuelCost: 1, km: 10, minutes: 60),
        targetNetPerHour: 10,
      );

      expect(result.signal, 'green');
      expect(result.verdict, 'CONVIENE');
    });

    test('semáforo amarillo exactamente en la mitad del objetivo', () {
      final result = recommendFare(
        _trip(price: 6.3 / .85, fuelCost: 1, km: 10, minutes: 60),
        targetNetPerHour: 10,
      );

      expect(result.signal, 'yellow');
      expect(result.verdict, 'DUDOSO');
    });

    test('semáforo rojo por debajo de la mitad del objetivo', () {
      final result = recommendFare(
        _trip(price: 6, fuelCost: 1, km: 10, minutes: 60),
        targetNetPerHour: 10,
      );

      expect(result.signal, 'red');
      expect(result.verdict, 'NO CONVIENE');
    });

    test('semáforo rojo también cuando el neto actual es negativo', () {
      final result = recommendFare(
        _trip(price: .5, fuelCost: 1, km: 10, minutes: 60),
        targetNetPerHour: 10,
      );

      expect(result.signal, 'red');
      expect(result.verdict, 'NO CONVIENE');
    });

    test('una oferta superior no se reduce y no requiere aumento', () {
      final result = recommendFare(_trip(price: 20), targetNetPerHour: 10);

      expect(result.recommendedFare, 8.59);
      expect(result.requiredIncrease, 0);
    });

    test('rechaza horas, objetivo, valores no finitos y costes negativos', () {
      expect(
        () => recommendFare(_trip(minutes: 0), targetNetPerHour: 10),
        throwsArgumentError,
      );
      expect(
        () => recommendFare(_trip(), targetNetPerHour: 0),
        throwsArgumentError,
      );
      expect(
        () => recommendFare(_trip(), targetNetPerHour: double.nan),
        throwsArgumentError,
      );
      expect(
        () => recommendFare(_trip(fuelCost: -0.01), targetNetPerHour: 10),
        throwsArgumentError,
      );
      expect(
        () => recommendFare(_trip(km: -1), targetNetPerHour: 10),
        throwsArgumentError,
      );
      expect(
        () =>
            recommendFare(_trip(price: double.infinity), targetNetPerHour: 10),
        throwsArgumentError,
      );
    });
  });
}
