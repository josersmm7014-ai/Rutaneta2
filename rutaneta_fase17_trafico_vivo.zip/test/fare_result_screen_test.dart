import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:rutaviva/screens.dart';
import 'package:rutaviva/store.dart';
import 'package:rutaviva/overlay_calculation.dart';

void main() {
  testWidgets(
    'Resultado y tarjeta usan el mismo objetivo y caben con texto grande',
    (tester) async {
      tester.view.physicalSize = const Size(360, 800);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      SharedPreferences.setMockInitialValues({
        'targetNetPerHour': 8.0,
        'vehicle': jsonEncode({
          'engine': '1.6',
          'fuel': 'Especial',
          'kmPerGal': 35.0,
          'fuelPrice': 5.13,
          'dailyGoal': 25.0,
        }),
      });
      await store.load();
      final trip = calculateOverlayTrip(
        vehicle: store.vehicle!,
        price: 10,
        km: 15.4,
        minutes: 23,
        returnEmpty: true,
      );
      await tester.pumpWidget(
        MaterialApp(
          builder: (context, child) => MediaQuery(
            data: MediaQuery.of(
              context,
            ).copyWith(textScaler: const TextScaler.linear(1.3)),
            child: child!,
          ),
          home: ResultScreen(trip: trip, warnings: const []),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text('CONVIENE'), findsNothing);
      expect(find.text('NO CONVIENE'), findsWidgets);
      await tester.ensureVisible(find.text('RECOMENDACIÓN DE TARIFA'));
      await tester.pumpAndSettle();
      expect(find.text('Sugerida para \$8.00/h'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
    },
  );
}
