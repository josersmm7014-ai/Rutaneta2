import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:rutaviva/overlay.dart';
import 'package:rutaviva/overlay_controller.dart';
import 'package:rutaviva/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  for (final entry in const {
    'red': 2.0,
    'yellow': 10.0,
    'green': 20.0,
  }.entries) {
    testWidgets(
      'El resultado ${entry.key} mantiene color y veredicto al reducir',
      (tester) async {
        SharedPreferences.setMockInitialValues({
          'vehicle': jsonEncode({
            'engine': '1.6',
            'fuel': 'Especial',
            'kmPerGal': 35.0,
            'fuelPrice': 5.13,
            'dailyGoal': 25.0,
          }),
        });
        await store.load();
        final messenger =
            TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
        messenger.setMockMethodCallHandler(
          const MethodChannel('x-slayer/overlay_channel'),
          (call) async {
            if (call.method == 'getScreenSize')
              return {'width': 360.0, 'height': 800.0};
            return true;
          },
        );
        messenger.setMockMethodCallHandler(
          const MethodChannel('x-slayer/overlay'),
          (_) async => true,
        );
        messenger.setMockMethodCallHandler(
          const MethodChannel('rutaviva/overlay_bridge'),
          OverlayCtrl.handleCommand,
        );
        await tester.pumpWidget(
          const MaterialApp(
            home: Scaffold(
              body: SizedBox(width: 330, height: 480, child: OverlayBubble()),
            ),
          ),
        );
        await tester.pumpAndSettle();
        await tester.tap(find.text('RutaNeta'));
        await tester.pumpAndSettle();
        await tester.tap(find.text('INGRESAR VIAJE MANUALMENTE'));
        await tester.pumpAndSettle();
        await tester.enterText(find.byType(TextField).at(0), '${entry.value}');
        await tester.enterText(find.byType(TextField).at(1), '15.4');
        await tester.enterText(find.byType(TextField).at(2), '23');
        await tester.ensureVisible(find.text('CALCULAR CON ESTOS DATOS'));
        await tester.tap(find.text('CALCULAR CON ESTOS DATOS'));
        await tester.pumpAndSettle();
        final light = tester.widget<Container>(
          find.byKey(ValueKey('traffic-${entry.key}')),
        );
        final color = {
          'red': const Color(0xFFFF5C6C),
          'yellow': const Color(0xFFFFD54F),
          'green': const Color(0xFF4ADE80),
        }[entry.key];
        expect((light.decoration! as BoxDecoration).color, color);
        final verdict = {
          'red': 'NO CONVIENE',
          'yellow': 'DUDOSO',
          'green': 'CONVIENE',
        }[entry.key]!;
        expect(find.text(verdict), findsOneWidget);
        expect(find.text('TARIFA RECOMENDADA'), findsOneWidget);
        await tester.tap(find.byTooltip('Reducir'));
        await tester.pumpAndSettle();
        expect(find.text(verdict), findsOneWidget);
        expect(find.text('TARIFA RECOMENDADA'), findsNothing);
        expect(tester.takeException(), isNull);
        await tester.pumpWidget(const SizedBox());
      },
    );
  }
  test('Carga el objetivo guardado y rechaza objetivos inválidos', () async {
    SharedPreferences.setMockInitialValues({'targetNetPerHour': 7.5});
    final preferences = Store();
    await preferences.load();
    expect(preferences.targetNetPerHour, 7.5);
    expect(() => preferences.setTargetNetPerHour(0), throwsFormatException);
    expect(
      () => preferences.setTargetNetPerHour(double.nan),
      throwsFormatException,
    );
  });
}
