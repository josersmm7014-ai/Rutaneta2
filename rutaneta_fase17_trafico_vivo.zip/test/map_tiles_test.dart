import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:rutaviva/geo.dart';

void main() {
  group('Configuración del fondo cartográfico', () {
    test('El mapa oscuro usa Mapbox con autenticación y teselas de 512', () {
      final template = mapboxTileTemplate();
      final url = template
          .replaceAll('{z}', '11')
          .replaceAll('{x}', '516')
          .replaceAll('{y}', '945');
      final uri = Uri.parse(url);
      expect(uri.scheme, 'https');
      expect(uri.host, 'api.mapbox.com');
      expect(uri.path, '/styles/v1/mapbox/dark-v11/tiles/512/11/516/945');
      expect(uri.queryParameters['access_token'], startsWith('pk.'));
      expect(template, contains('{z}/{x}/{y}'));
      expect(template, isNot(contains('cartocdn')));
    });

    test('El mapa claro conserva el token y cambia únicamente el estilo', () {
      final dark = Uri.parse(mapboxTileTemplate());
      final light = Uri.parse(mapboxTileTemplate(dark: false));
      expect(light.path, contains('/light-v11/tiles/512/'));
      expect(
        light.queryParameters['access_token'],
        dark.queryParameters['access_token'],
      );
    });

    test('El mapa no usa CARTO y ajusta la escala de las teselas a 512', () {
      final mapSource = File('lib/map_screen.dart').readAsStringSync();
      expect(mapSource, isNot(contains('basemaps.cartocdn.com')));
      expect(mapSource, contains('tileSize: 512'));
      expect(mapSource, contains('zoomOffset: -1'));
    });

    test('El logo oficial está disponible y la atribución incluye enlaces', () {
      expect(File('assets/icon/mapbox-logo.png').existsSync(), isTrue);
      final mapSource = File('lib/map_screen.dart').readAsStringSync();
      expect(mapSource, contains('https://www.mapbox.com/about/maps'));
      expect(mapSource, contains('https://www.openstreetmap.org/copyright'));
      expect(mapSource, contains('https://apps.mapbox.com/feedback/'));
    });
  });
}
