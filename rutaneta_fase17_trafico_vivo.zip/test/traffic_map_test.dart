import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('el mapa usa fondo Mapbox de tráfico claro por defecto y controles', () {
    final source = File('lib/map_screen.dart').readAsStringSync();

    expect(source, contains('mapboxTileTemplate('));
    expect(source, contains('dark: !brightMap'));
    expect(source, contains('traffic: trafficLayer'));
    expect(source, contains('bool brightMap = true'));
    expect(source, contains('bool trafficLayer = true'));
    expect(source, contains('onLongPress: _onMapLongPress'));
    expect(source, contains('Future.wait<TrafficRouteInfo?>'));
  });

  test('no vuelve a mostrar zonas de rentabilidad inventadas', () {
    final source = File('lib/map_screen.dart').readAsStringSync();

    expect(source, isNot(contains('class _Zone')));
    expect(source, isNot(contains('zonas rentables')));
    expect(source, isNot(contains('\$0.45/km')));
  });

  test(
    'la ruta distingue segmentos sin datos y conserva manejo de ciclo de vida',
    () {
      final source = File('lib/map_screen.dart').readAsStringSync();

      expect(source, contains("_trafficColor('unknown')"));
      expect(source, contains('withAlpha(returnRoute ? 130 : 190)'));
      expect(source, contains('WidgetsBindingObserver'));
      expect(source, contains('Timer.periodic(const Duration(minutes: 2)'));
      expect(source, contains('ModalRoute.of(context)'));
      expect(source, contains('removeObserver(this)'));
    },
  );
}
