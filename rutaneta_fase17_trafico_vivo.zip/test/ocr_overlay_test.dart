import 'package:flutter_test/flutter_test.dart';
import 'package:rutaviva/models.dart';
import 'package:rutaviva/ocr.dart';
import 'package:rutaviva/overlay_calculation.dart';

void main() {
  test('Reconoce el ejemplo inDrive 7 dólares, 2.1 km, 13 minutos', () {
    final r = parseTripText(
      'RutaViva\nNeto hoy: \$0.00\n7 \$\nTiempo de recogida: hasta 1 hora\n2.1 km, 13 min\nSolicitud creada hace 30 min',
    );
    expect(r.price, 7);
    expect(r.km, 2.1);
    expect(r.minutes, 13);
  });
  test('Reconoce coma decimal y precio antes de la moneda', () {
    final r = parseTripText('\$ 7,50\n2,1 kilómetros, 13 minutos');
    expect(r.price, 7.5);
    expect(r.km, 2.1);
    expect(r.minutes, 13);
  });
  test('No confunde metas y ratios con la tarifa', () {
    final r = parseTripText(
      'Meta \$25\nGanancia \$5\n\$0.62/km\n7 USD\n2.1 km, 13 min',
    );
    expect(r.price, 7);
  });
  test('No inventa datos si la captura está vacía', () {
    final r = parseTripText('Pantalla vacía');
    expect(r.price, isNull);
    expect(r.km, isNull);
    expect(r.minutes, isNull);
  });
  final vehicle = Vehicle(
    engine: '1.6',
    fuel: 'Especial',
    kmPerGal: 35,
    fuelPrice: 5.13,
    dailyGoal: 25,
  );
  test('El viaje de 7 dólares produce ganancia y desglose, no cero', () {
    final t = calculateOverlayTrip(
      vehicle: vehicle,
      price: 7,
      km: 2.1,
      minutes: 13,
      returnEmpty: true,
    );
    expect(t.fuelCost, closeTo(0.6156, 0.000001));
    expect(t.net, closeTo(5.2084, 0.000001));
    expect(t.perHour, closeTo(12.019384615, 0.000001));
    expect(t.verdict, 'CONVIENE');
  });
  test('Sin regreso vacío reduce kilómetros, tiempo y combustible', () {
    final t = calculateOverlayTrip(
      vehicle: vehicle,
      price: 7,
      km: 2.1,
      minutes: 13,
      returnEmpty: false,
    );
    expect(t.travelKm, 2.1);
    expect(t.fuelCost, closeTo(0.3078, 0.000001));
  });
  test('Rechaza campos cero en lugar de mostrar un falso cálculo', () {
    expect(
      () => calculateOverlayTrip(
        vehicle: vehicle,
        price: 0,
        km: 2.1,
        minutes: 13,
        returnEmpty: true,
      ),
      throwsFormatException,
    );
    expect(
      () => calculateOverlayTrip(
        vehicle: vehicle,
        price: 7,
        km: 0,
        minutes: 13,
        returnEmpty: true,
      ),
      throwsFormatException,
    );
    expect(
      () => calculateOverlayTrip(
        vehicle: vehicle,
        price: 7,
        km: 2.1,
        minutes: 0,
        returnEmpty: true,
      ),
      throwsFormatException,
    );
  });
}
