import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:rutaviva/overlay.dart';
import 'package:rutaviva/overlay_controller.dart';
import 'package:rutaviva/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  testWidgets('Lee imagen y calcula aunque el mensajero antiguo nunca responda', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({
      'vehicle': jsonEncode({
        'engine': '1.6',
        'fuel': 'Especial',
        'kmPerGal': 35.0,
        'fuelPrice': 5.13,
        'dailyGoal': 25.0,
      }),
    });
    await store.load();
    final messenger =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    var oldCalls = 0;
    final commands = <String>[];
    messenger.setMockMessageHandler('x-slayer/overlay_messenger', (_) {
      oldCalls++;
      return Completer<ByteData?>().future; // Simula el fallo real del plugin.
    });
    messenger.setMockMethodCallHandler(
      const MethodChannel('x-slayer/overlay_channel'),
      (call) async {
        if (call.method == 'getScreenSize')
          return {'width': 360.0, 'height': 800.0};
        return true;
      },
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('x-slayer/overlay'),
      (_) async => true,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('rutaviva/overlay_bridge'),
      (call) async {
        commands.add(call.method);
        if (call.method == 'capture') return '/tmp/capture-regression.jpg';
        return OverlayCtrl.handleCommand(call);
      },
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('google_mlkit_text_recognizer'),
      (call) async {
        if (call.method == 'vision#startTextRecognizer')
          return {
            'text':
                '10 \$\nTiempo de recogida de 10 a 20 min\n15.4 km, 23 min\nSolicitud creada hace 36 min',
            'blocks': [],
          };
        return null;
      },
    );
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: SizedBox(width: 330, height: 480, child: OverlayBubble()),
        ),
      ),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.byIcon(Icons.calculate));
    await tester.pumpAndSettle();
    expect(find.byType(TextField), findsNWidgets(4));
    final fields = tester
        .widgetList<TextField>(find.byType(TextField))
        .toList();
    expect(fields[0].controller!.text, '10.0');
    expect(fields[1].controller!.text, '15.4');
    expect(fields[2].controller!.text, '23.0');
    await tester.ensureVisible(find.text('CALCULAR CON ESTOS DATOS'));
    await tester.tap(find.text('CALCULAR CON ESTOS DATOS'));
    await tester.pumpAndSettle();
    expect(find.textContaining('Neto estimado'), findsOneWidget);
    expect(find.text('TARIFA RECOMENDADA'), findsOneWidget);
    expect(find.byKey(const ValueKey('traffic-yellow')), findsOneWidget);
    expect(commands, containsAll(['capture', 'calculate']));
    expect(oldCalls, 0);
    expect(store.calcsToday, 1);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });
}
