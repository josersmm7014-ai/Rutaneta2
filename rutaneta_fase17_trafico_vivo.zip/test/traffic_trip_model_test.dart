import 'package:flutter_test/flutter_test.dart';
import 'package:rutaviva/fare_recommendation.dart';
import 'package:rutaviva/models.dart';
import 'package:rutaviva/overlay_calculation.dart';

Vehicle _vehicle() => Vehicle(
  engine: '1.6',
  fuel: 'Especial',
  kmPerGal: 35,
  fuelPrice: 5.13,
  dailyGoal: 25,
);

Trip _legacyTrip({bool returnEmpty = true}) => Trip(
  id: 'legacy',
  date: DateTime.utc(2026, 1, 2, 3, 4, 5),
  origin: 'A',
  destination: 'B',
  price: 10,
  km: 10,
  minutes: 30,
  returnEmpty: returnEmpty,
  fuelCost: 2,
  finished: true,
);

void main() {
  test('mantiene el viaje legacy en 2x cuando hay regreso vacío', () {
    final trip = _legacyTrip();

    expect(trip.travelKm, 20);
    expect(trip.hours, 1);
    expect(trip.returnKm, isNull);
    expect(trip.returnMinutes, isNull);
    expect(trip.typicalTotalMinutes, isNull);
    expect(trip.trafficDelayMinutes, isNull);
  });

  test('calcula regreso asimétrico y cambia neto y tarifa objetivo', () {
    final trip = calculateOverlayTrip(
      vehicle: _vehicle(),
      price: 10,
      km: 15.4,
      minutes: 23,
      returnEmpty: true,
      returnKm: 18,
      returnMinutes: 45,
    );

    expect(trip.travelKm, closeTo(33.4, 1e-12));
    expect(trip.hours, closeTo(68 / 60, 1e-12));
    expect(trip.fuelCost, closeTo(4.895485714285714, 1e-12));
    expect(trip.net, closeTo(2.6025142857142862, 1e-12));
    expect(trip.perHour, closeTo(2.296336134453782, 1e-12));

    final recommendation = recommendFare(trip, targetNetPerHour: 8);
    expect(recommendation.recommendedFare, 17.61);
    expect(recommendation.requiredIncrease, 7.61);
  });

  test('compara tráfico por sentido sin inventar el típico del regreso', () {
    final trip = calculateOverlayTrip(
      vehicle: _vehicle(),
      price: 10,
      km: 15.4,
      minutes: 23,
      returnEmpty: true,
      returnKm: 18,
      returnMinutes: 45,
      typicalMinutes: 20,
      returnTypicalMinutes: 30,
      trafficCheckedAt: DateTime.utc(2026, 10, 31, 22),
      trafficSource: 'agentgeoTrafficAPI',
    );

    expect(trip.typicalTotalMinutes, 50);
    expect(trip.trafficDelayMinutes, 18);
    expect(trip.trafficCheckedAt, DateTime.utc(2026, 10, 31, 22));
    expect(trip.trafficSource, 'agentgeoTrafficAPI');

    final missingReturnTypical = Trip(
      id: 'missing-baseline',
      date: DateTime.utc(2026),
      origin: 'A',
      destination: 'B',
      price: 10,
      km: 15.4,
      minutes: 23,
      returnEmpty: true,
      fuelCost: 1,
      returnKm: 18,
      returnMinutes: 45,
      typicalMinutes: 20,
    );
    expect(missingReturnTypical.typicalTotalMinutes, isNull);
    expect(missingReturnTypical.trafficDelayMinutes, isNull);

    final fasterThanTypical = Trip(
      id: 'no-delay',
      date: DateTime.utc(2026),
      origin: 'A',
      destination: 'B',
      price: 10,
      km: 1,
      minutes: 10,
      returnEmpty: false,
      fuelCost: 1,
      typicalMinutes: 20,
    );
    expect(fasterThanTypical.trafficDelayMinutes, 0);
  });

  test('JSON legacy roundtrip no agrega claves opcionales nulas', () {
    final json = <String, dynamic>{
      'id': 'legacy',
      'date': '2026-01-02T03:04:05.000Z',
      'origin': 'A',
      'destination': 'B',
      'price': 10.0,
      'km': 10.0,
      'minutes': 30.0,
      'returnEmpty': true,
      'fuelCost': 2.0,
      'finished': true,
    };

    final restored = Trip.fromJson(json);
    expect(restored.toJson(), json);
    expect(restored.returnKm, isNull);
    expect(restored.trafficSource, isNull);
  });

  test('JSON nuevo roundtrip conserva regreso y tráfico', () {
    final trip = Trip(
      id: 'new',
      date: DateTime.utc(2026, 10, 31, 22),
      origin: 'A',
      destination: 'B',
      price: 10,
      km: 15.4,
      minutes: 23,
      returnEmpty: true,
      fuelCost: 4.9,
      returnKm: 18,
      returnMinutes: 45,
      typicalMinutes: 20,
      returnTypicalMinutes: 30,
      trafficCheckedAt: DateTime.utc(2026, 10, 31, 22),
      trafficSource: 'traffic-api',
    );

    final restored = Trip.fromJson(trip.toJson());
    expect(restored.returnKm, 18);
    expect(restored.returnMinutes, 45);
    expect(restored.typicalMinutes, 20);
    expect(restored.returnTypicalMinutes, 30);
    expect(restored.trafficCheckedAt, trip.trafficCheckedAt);
    expect(restored.trafficSource, 'traffic-api');
  });

  test('returnEmpty false ignora regreso en métricas y combustible', () {
    final trip = calculateOverlayTrip(
      vehicle: _vehicle(),
      price: 10,
      km: 15.4,
      minutes: 23,
      returnEmpty: false,
      returnKm: 18,
      returnMinutes: 45,
    );

    expect(trip.travelKm, 15.4);
    expect(trip.hours, closeTo(23 / 60, 1e-12));
    expect(trip.fuelCost, closeTo(15.4 / 35 * 5.13, 1e-12));
  });

  test(
    'acepta retornos nulos y rechaza retornos no positivos o no finitos',
    () {
      expect(
        calculateOverlayTrip(
          vehicle: _vehicle(),
          price: 10,
          km: 15.4,
          minutes: 23,
          returnEmpty: true,
          returnKm: null,
          returnMinutes: null,
        ).travelKm,
        30.8,
      );

      for (final badReturn in <double?>[-1, 0, double.nan, double.infinity]) {
        expect(
          () => calculateOverlayTrip(
            vehicle: _vehicle(),
            price: 10,
            km: 15.4,
            minutes: 23,
            returnEmpty: false,
            returnKm: badReturn,
          ),
          throwsFormatException,
        );
      }

      expect(
        () => calculateOverlayTrip(
          vehicle: _vehicle(),
          price: 10,
          km: 15.4,
          minutes: 23,
          returnEmpty: false,
          returnMinutes: -0.1,
        ),
        throwsFormatException,
      );
    },
  );
}
