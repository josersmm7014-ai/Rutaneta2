import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:latlong2/latlong.dart';
import 'package:rutaviva/geo.dart';

Map<String, dynamic> place(
  String name,
  String key,
  String value,
  double lon, {
  int id = 1,
}) => {
  'properties': {
    'name': name,
    'osm_key': key,
    'osm_value': value,
    'osm_type': 'N',
    'osm_id': id,
  },
  'geometry': {
    'type': 'Point',
    'coordinates': [lon, 13.6929],
  },
};

void main() {
  const center = LatLng(13.6929, -89.2182);
  test('Photon devuelve gasolineras y supermercados con nombres', () async {
    final client = MockClient((request) async {
      expect(request.url.host, 'photon.komoot.io');
      expect(request.url.queryParameters['radius'], '5.0');
      expect(request.url.queryParametersAll['osm_tag'], contains('shop'));
      return http.Response(
        jsonEncode({
          'features': [
            place('Texaco', 'amenity', 'fuel', -89.219),
            place('Súper', 'shop', 'supermarket', -89.22, id: 2),
          ],
        }),
        200,
        headers: {'content-type': 'application/json; charset=utf-8'},
      );
    });
    final results = await nearbyPlaces(center, client: client);
    expect(results.map((p) => p.name), ['Texaco', 'Súper']);
    expect(results.map((p) => p.category), ['Gasolinera', 'Supermercado']);
    client.close();
  });
  test(
    'No muestra duplicados, registros sin nombre ni lugares fuera del radio',
    () async {
      final client = MockClient(
        (_) async => http.Response(
          jsonEncode({
            'features': [
              place('Texaco', 'amenity', 'fuel', -89.219),
              place('Texaco', 'amenity', 'fuel', -89.219),
              place('', 'shop', 'supermarket', -89.22),
              place('Lejos', 'shop', 'convenience', -90.0, id: 4),
              {'properties': {}},
            ],
          }),
          200,
        ),
      );
      expect((await nearbyPlaces(center, client: client)).length, 1);
      client.close();
    },
  );
  test('Usa Overpass si Photon falla', () async {
    final client = MockClient((request) async {
      if (request.url.host == 'photon.komoot.io')
        return http.Response('No disponible', 503);
      expect(request.method, 'POST');
      return http.Response(
        jsonEncode({
          'elements': [
            {
              'type': 'node',
              'id': 1,
              'lat': 13.6929,
              'lon': -89.219,
              'tags': {'name': 'Farmacia', 'amenity': 'pharmacy'},
            },
          ],
        }),
        200,
      );
    });
    expect(
      (await nearbyPlaces(center, client: client)).single.category,
      'Farmacia',
    );
    client.close();
  });
  test('No trata fallos de ambos servidores como cero locales', () async {
    final client = MockClient((_) async => http.Response('No disponible', 503));
    await expectLater(nearbyPlaces(center, client: client), throwsException);
    client.close();
  });
}
