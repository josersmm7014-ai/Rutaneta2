import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:rutaviva/geo.dart';
import 'package:rutaviva/models.dart';
import 'package:rutaviva/screens.dart';
import 'package:rutaviva/store.dart';
import 'package:rutaviva/traffic_trip.dart';

Vehicle _vehicleJson() => Vehicle(
  engine: '1.6',
  fuel: 'Regular',
  kmPerGal: 35,
  fuelPrice: 5,
  dailyGoal: 25,
);

TrafficRouteInfo _route({
  required double km,
  required double minutes,
  required DateTime checkedAt,
  List<String?> congestion = const ['moderate', 'unknown'],
  double? typicalMinutes,
}) => TrafficRouteInfo(
  km: km,
  minutes: minutes,
  // El test verifica el contrato de tráfico, no el renderer de tiles.
  points: const [],
  congestion: congestion,
  typicalMinutes: typicalMinutes,
  checkedAt: checkedAt,
);

Future<void> _loadVehicle() async {
  SharedPreferences.setMockInitialValues({
    'vehicle':
        '{"engine":"1.6","fuel":"Regular","kmPerGal":35.0,"fuelPrice":5.0,"dailyGoal":25.0}',
  });
  await store.load();
  store.vehicle = _vehicleJson();
}

void main() {
  testWidgets('muestra el estado del plan inicial sin perder la ruta', (
    tester,
  ) async {
    await _loadVehicle();
    final checked = DateTime.now();
    final plan = ActiveTrafficTrip(
      origin: const GeoPoint(13.70, -89.20),
      destination: const GeoPoint(13.71, -89.19),
      originLabel: 'Origen de prueba',
      destinationLabel: 'Destino de prueba',
      outbound: _route(
        km: 4.2,
        minutes: 18,
        checkedAt: checked,
        typicalMinutes: 12,
      ),
      returnRoute: _route(
        km: 4.5,
        minutes: 21,
        checkedAt: checked,
        typicalMinutes: 14,
      ),
    );

    await tester.pumpWidget(
      MaterialApp(home: CalcScreen(initialTrafficTrip: plan)),
    );
    await tester.pump();

    expect(find.text('Destino: Destino de prueba'), findsOneWidget);
    expect(find.text('Ida: 4.2 km · 18 min'), findsOneWidget);
    expect(find.text('Vuelta: 4.5 km · 21 min'), findsOneWidget);
    expect(find.textContaining('Baseline habitual ida'), findsOneWidget);
    expect(find.textContaining('Cobertura:'), findsOneWidget);
  });

  testWidgets(
    'consulta ida y vuelta en paralelo mediante funciones inyectadas',
    (tester) async {
      await _loadVehicle();
      final originPoint = const GeoPoint(13.70, -89.20);
      final destinationPoint = const GeoPoint(13.71, -89.19);
      var trafficCalls = 0;

      Future<GeoPoint?> geocoder(String query) async =>
          query == 'A' ? originPoint : destinationPoint;
      Future<TrafficRouteInfo?> router(GeoPoint a, GeoPoint b) async {
        trafficCalls++;
        final reverse = a == destinationPoint;
        return _route(
          km: reverse ? 5.1 : 4.8,
          minutes: reverse ? 24 : 20,
          checkedAt: DateTime.now(),
          congestion: const ['unknown', 'unknown'],
          typicalMinutes: reverse ? 18 : 15,
        );
      }

      await tester.pumpWidget(
        MaterialApp(
          home: CalcScreen(geocodeFn: geocoder, trafficRouteFn: router),
        ),
      );
      await tester.enterText(find.byType(TextField).at(0), 'A');
      await tester.enterText(find.byType(TextField).at(1), 'B');
      await tester.tap(find.text('Distancia automática'));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 50));

      expect(trafficCalls, 2);
      expect(
        find.textContaining('Mapbox sin datos de tráfico'),
        findsOneWidget,
      );
      expect(find.text('Ida: 4.8 km · 20 min'), findsOneWidget);
      expect(find.text('Vuelta: 5.1 km · 24 min'), findsOneWidget);
    },
  );
}
