import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:rutaviva/main.dart';
import 'package:rutaviva/models.dart';
import 'package:rutaviva/store.dart';

void main() {
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    await store.load();
    store.vehicle = Vehicle(
      engine: '1.6',
      fuel: 'Regular',
      kmPerGal: 35,
      fuelPrice: 4.5,
      dailyGoal: 25,
    );
    store.highVisibility = false;
    store.darkTheme = true;
  });

  tearDown(() {
    store.vehicle = null;
    store.highVisibility = false;
    store.darkTheme = true;
  });

  testWidgets('cambiar alta visibilidad no desmonta MaterialApp ni Ajustes', (
    tester,
  ) async {
    await tester.pumpWidget(const RutaNetaApp());
    await tester.pumpAndSettle();

    await tester.tap(find.text('Ajustes').last);
    await tester.pumpAndSettle();
    expect(find.text('Alta visibilidad'), findsOneWidget);

    // Exercise the actual callback used by SettingsScreen.
    await tester.tap(find.byType(SwitchListTile).first);
    await tester.pump();
    await tester.pump(const Duration(milliseconds: 100));

    expect(find.text('Alta visibilidad'), findsOneWidget);
    expect(find.byType(MaterialApp), findsOneWidget);
    expect(
      Theme.of(tester.element(find.text('Ajustes').last)).textTheme,
      isNotNull,
    );
  });

  testWidgets(
    'la página de mapa sobrevive a una notificación global de preferencias',
    (tester) async {
      await tester.pumpWidget(const RutaNetaApp());
      await tester.pumpAndSettle();

      await tester.tap(find.text('Mapa').last);
      await tester.pump();
      expect(find.text('Mapa y tráfico'), findsOneWidget);

      store.highVisibility = true;
      store.notifyListeners();
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 100));

      expect(find.text('Mapa y tráfico'), findsOneWidget);
    },
  );
}
