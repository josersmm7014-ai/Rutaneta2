import 'package:flutter_test/flutter_test.dart';
import 'package:rutaviva/geo.dart';

void main() {
  test(
    'traffic selecciona estilos navigation day/night y conserva raster 512',
    () {
      final day = Uri.parse(mapboxTileTemplate(dark: false, traffic: true));
      final night = Uri.parse(mapboxTileTemplate(dark: true, traffic: true));

      expect(
        day.path,
        contains('/styles/v1/mapbox/navigation-day-v1/tiles/512/'),
      );
      expect(
        night.path,
        contains('/styles/v1/mapbox/navigation-night-v1/tiles/512/'),
      );
      expect(day.queryParameters['access_token'], startsWith('pk.'));
      expect(
        day.queryParameters['access_token'],
        night.queryParameters['access_token'],
      );
      expect(day.queryParameters.keys, ['access_token']);
      expect(night.queryParameters.keys, ['access_token']);
    },
  );

  test('sin traffic preserva estilos dark/light existentes', () {
    final dark = Uri.parse(mapboxTileTemplate(dark: true));
    final light = Uri.parse(mapboxTileTemplate(dark: false, traffic: false));

    expect(dark.path, contains('/styles/v1/mapbox/dark-v11/tiles/512/'));
    expect(light.path, contains('/styles/v1/mapbox/light-v11/tiles/512/'));
    expect(
      dark.queryParameters['access_token'],
      light.queryParameters['access_token'],
    );
  });
}
