import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:latlong2/latlong.dart';
import 'package:rutaviva/geo.dart';
import 'package:rutaviva/store.dart';
import 'package:rutaviva/traffic_trip.dart';
import 'package:rutaviva/overlay_controller.dart';
import 'package:rutaviva/overlay.dart';

ActiveTrafficTrip plan({
  bool stale = false,
  bool unknown = false,
  bool back = true,
}) {
  final time = DateTime.now().subtract(
    stale ? const Duration(minutes: 4) : Duration.zero,
  );
  final outbound = TrafficRouteInfo(
    km: 10,
    minutes: 40,
    typicalMinutes: 20,
    checkedAt: time,
    points: const [LatLng(13.6929, -89.2182), LatLng(13.6769, -89.2797)],
    congestion: [unknown ? 'unknown' : 'heavy'],
  );
  return ActiveTrafficTrip(
    origin: const GeoPoint(13.6929, -89.2182),
    destination: const GeoPoint(13.6769, -89.2797),
    originLabel: 'San Salvador',
    destinationLabel: 'Santa Tecla',
    outbound: outbound,
    returnRoute: back
        ? TrafficRouteInfo(
            km: 12,
            minutes: 50,
            typicalMinutes: 25,
            checkedAt: time,
            points: const [
              LatLng(13.6769, -89.2797),
              LatLng(13.6929, -89.2182),
            ],
            congestion: const ['heavy'],
          )
        : null,
  );
}

Future<Map<String, dynamic>> calculate(
  String id, {
  bool traffic = true,
  String? destinationId,
}) => OverlayCtrl.handleCommand(
  MethodCall('calculate', {
    'id': id,
    'price': 10.0,
    'km': 10.0,
    'minutes': 20.0,
    'returnEmpty': true,
    'targetNetPerHour': 4.0,
    'useTraffic': traffic,
    'confirmTrafficRoute': traffic,
    'trafficDestinationId':
        destinationId ?? store.activeTrafficTrip?.destinationId,
  }),
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() async {
    SharedPreferences.setMockInitialValues({
      'vehicle': jsonEncode({
        'engine': '1.6',
        'fuel': 'Especial',
        'kmPerGal': 35.0,
        'fuelPrice': 5.13,
        'dailyGoal': 25.0,
      }),
    });
    await store.load();
    store.clearActiveTrafficTrip();
  });
  testWidgets('Confirmar la ruta en la burbuja usa tráfico y muestra destino', (
    tester,
  ) async {
    store.setActiveTrafficTrip(plan());
    final messenger =
        TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
    messenger.setMockMethodCallHandler(
      const MethodChannel('x-slayer/overlay_channel'),
      (call) async {
        if (call.method == 'getScreenSize')
          return {'width': 360.0, 'height': 800.0};
        return true;
      },
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('x-slayer/overlay'),
      (_) async => true,
    );
    messenger.setMockMethodCallHandler(
      const MethodChannel('rutaviva/overlay_bridge'),
      OverlayCtrl.handleCommand,
    );
    await tester.pumpWidget(
      const MaterialApp(
        home: Scaffold(
          body: SizedBox(width: 330, height: 480, child: OverlayBubble()),
        ),
      ),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.text('RutaNeta'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('INGRESAR VIAJE MANUALMENTE'));
    await tester.pumpAndSettle();
    await tester.enterText(find.byType(TextField).at(0), '10');
    await tester.enterText(find.byType(TextField).at(1), '10');
    await tester.enterText(find.byType(TextField).at(2), '20');
    await tester.ensureVisible(find.byType(CheckboxListTile));
    await tester.tap(find.byType(CheckboxListTile));
    await tester.pumpAndSettle();
    expect(
      tester.widget<TextField>(find.byType(TextField).at(2)).controller!.text,
      '40.0',
    );
    await tester.ensureVisible(find.text('CALCULAR CON ESTOS DATOS'));
    await tester.tap(find.text('CALCULAR CON ESTOS DATOS'));
    await tester.pumpAndSettle();
    expect(find.text('Destino: Santa Tecla'), findsOneWidget);
    expect(find.text('TARIFA RECOMENDADA'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pumpWidget(const SizedBox());
  });
  test(
    'El tráfico de ida/vuelta cambia ganancia por hora y tarifa y conserva destino',
    () async {
      final manual = await calculate('manual-reference', traffic: false);
      store.setActiveTrafficTrip(plan());
      final live = await calculate('live-reference');
      expect(live['state'], 'result');
      expect(live['minutes'], 40);
      expect(live['returnMinutes'], 50);
      expect(
        live['recommendedFare'] as num,
        greaterThan(manual['recommendedFare'] as num),
      );
      expect(live['perHour'] as num, lessThan(manual['perHour'] as num));
      expect(live['trafficFareIncrease'] as num, greaterThan(0));
      expect(live['trafficUsed'], true);
      await OverlayCtrl.handleCommand(const MethodCall('saveTrip'));
      expect(store.trips.first.destination, 'Santa Tecla');
      expect(store.trips.first.returnMinutes, 50);
    },
  );
  test('Otra ruta o consulta caducada no consume cálculo', () async {
    store.setActiveTrafficTrip(plan());
    expect(
      (await calculate('wrong-route', destinationId: 'another'))['state'],
      'error',
    );
    store.setActiveTrafficTrip(plan(stale: true));
    expect((await calculate('stale-route'))['state'], 'error');
    expect(store.calcsToday, 0);
  });
  test(
    'No identifica como tráfico libre una ruta sin cobertura o sin vuelta',
    () async {
      store.setActiveTrafficTrip(plan(unknown: true));
      expect((await calculate('unknown-route'))['state'], 'error');
      store.setActiveTrafficTrip(plan(back: false));
      expect((await calculate('missing-return'))['state'], 'error');
      expect(store.calcsToday, 0);
    },
  );
}
