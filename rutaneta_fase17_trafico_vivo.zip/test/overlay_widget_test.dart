import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:rutaviva/overlay.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  testWidgets(
    'Burbuja compacta, expandida y revisión editable sin desbordamientos',
    (tester) async {
      final sizes = <Map<dynamic, dynamic>>[];
      final messenger =
          TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
      messenger.setMockMethodCallHandler(
        const MethodChannel('x-slayer/overlay_channel'),
        (call) async {
          if (call.method == 'getScreenSize')
            return {'width': 360.0, 'height': 800.0};
          return true;
        },
      );
      messenger.setMockMethodCallHandler(
        const MethodChannel('x-slayer/overlay'),
        (call) async {
          if (call.method == 'resizeOverlay') sizes.add(call.arguments as Map);
          return true;
        },
      );
      messenger.setMockMessageHandler(
        'x-slayer/overlay_messenger',
        (_) async => const JSONMessageCodec().encodeMessage(null),
      );
      messenger.setMockMethodCallHandler(
        const MethodChannel('rutaviva/overlay_bridge'),
        (_) async => {'net': 0.0, 'perHour': 0.0, 'homeMode': false},
      );
      await tester.pumpWidget(
        const MaterialApp(
          home: Scaffold(
            body: SizedBox(width: 330, height: 480, child: OverlayBubble()),
          ),
        ),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.text('RutaNeta'));
      await tester.pumpAndSettle();
      expect(sizes.last['width'], lessThanOrEqualTo(330));
      expect(find.text('LEER VIAJE DE PANTALLA'), findsOneWidget);
      await tester.tap(find.text('INGRESAR VIAJE MANUALMENTE'));
      await tester.pumpAndSettle();
      expect(find.byType(TextField), findsNWidgets(4));
      await tester.ensureVisible(find.text('CALCULAR CON ESTOS DATOS'));
      await tester.tap(find.text('CALCULAR CON ESTOS DATOS'));
      await tester.pump();
      expect(
        find.text('Completa los tres datos con valores mayores que cero.'),
        findsOneWidget,
      );
      expect(tester.takeException(), isNull);
      await tester.pumpWidget(const SizedBox());
    },
  );
}
