import 'dart:io';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:rutaviva/ocr.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('Prefiere decimal explícito frente a duplicado diez veces mayor', () {
    final r = parseTripText('10 \$\n15.4 km, 23 min\n154 km, 23 min');
    expect(r.km, 15.4);
    expect(r.minutes, 23);
  });
  test('El resultado no depende del orden de las dos lecturas', () {
    final r = parseTripText('10 \$\n154 km, 23 min\n15.4 km, 23 min');
    expect(r.km, 15.4);
    expect(r.minutes, 23);
  });
  test(
    'Acepta separadores decimales explícitos con espacios y punto centrado',
    () {
      for (final value in ['15 . 4', '15 , 4', '15 · 4', '15 • 4']) {
        expect(parseTripText('10 \$\n$value km, 23 min').km, 15.4);
      }
    },
  );
  test('No inventa el decimal cuando solo se reconoce 154 km en 23 min', () {
    final r = parseTripText('10 \$\n154 km, 23 min');
    expect(r.km, isNull);
    expect(r.warnings, isNotEmpty);
    expect(r.text, contains('154 km'));
  });
  test('Un viaje real de 154 km y 154 minutos conserva su distancia', () {
    final r = parseTripText('80 \$\n154 km, 154 min');
    expect(r.km, 154);
    expect(r.minutes, 154);
    expect(r.warnings, isEmpty);
  });
  test('No une dígitos separados cuando falta el punto', () {
    final r = parseTripText('10 \$\n15 4 km, 23 min');
    expect(r.km, isNull);
    expect(r.warnings, isNotEmpty);
  });
  test('Mantiene la pareja de viaje y no el tiempo de recogida', () {
    final r = parseTripText(
      '10 \$\nRecogida 2.1 km, 8 min\nViaje 15.4 km, 23 min',
    );
    expect(r.km, 15.4);
    expect(r.minutes, 23);
  });
  test(
    'La relectura de detalle recupera 15.4 sin modificar la captura original',
    () async {
      final directory = await Directory.systemTemp.createTemp('ocr-decimal-');
      final file = File('${directory.path}/screen.png');
      final bytes = img.encodePng(img.Image(width: 100, height: 200));
      await file.writeAsBytes(bytes);
      var reads = 0;
      final messenger =
          TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
      messenger.setMockMethodCallHandler(
        const MethodChannel('google_mlkit_text_recognizer'),
        (call) async {
          if (call.method == 'vision#startTextRecognizer') {
            reads++;
            return {
              'text': reads == 1 ? '10 \$\n154 km, 23 min' : '15.4 km, 23 min',
              'blocks': [],
            };
          }
          return null;
        },
      );
      try {
        final r = await readScreenshot(file.path);
        expect(reads, 2);
        expect(r.price, 10);
        expect(r.km, 15.4);
        expect(r.minutes, 23);
        expect(await file.readAsBytes(), orderedEquals(bytes));
        expect(File('${file.path}.detail-ocr.png').existsSync(), isFalse);
      } finally {
        messenger.setMockMethodCallHandler(
          const MethodChannel('google_mlkit_text_recognizer'),
          null,
        );
        await directory.delete(recursive: true);
      }
    },
  );
}
