import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:rutaviva/overlay_controller.dart';

void main() {
  testWidgets(
    'Apertura convierte dp a píxeles físicos para una pantalla de alta densidad',
    (tester) async {
      tester.view.devicePixelRatio = 3;
      addTearDown(tester.view.resetDevicePixelRatio);
      Map<dynamic, dynamic>? opened;
      final messenger =
          TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;
      messenger.setMockMethodCallHandler(
        const MethodChannel('x-slayer/overlay_channel'),
        (call) async {
          if (call.method == 'checkPermission') return true;
          if (call.method == 'isOverlayActive') return false;
          if (call.method == 'showOverlay') {
            opened = call.arguments as Map;
            return null;
          }
          return true;
        },
      );
      expect(await OverlayCtrl.start(), isTrue);
      expect(opened!['width'], (180 * tester.view.devicePixelRatio).round());
      expect(opened!['height'], (76 * tester.view.devicePixelRatio).round());
    },
  );
}
