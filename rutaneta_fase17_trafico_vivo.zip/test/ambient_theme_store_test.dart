import 'package:flutter_test/flutter_test.dart';
import 'package:rutaviva/store.dart';

void main() {
  group('Store.updateAmbientLux', () {
    late Store store;

    setUp(() {
      store = Store()
        ..appearanceMode = 'auto'
        ..darkTheme = true;
    });

    test('pasa a claro solo cuando la luz supera 60 lux', () {
      store.updateAmbientLux(60);
      expect(store.darkTheme, isTrue);

      store.updateAmbientLux(61);
      expect(store.darkTheme, isFalse);
    });

    test('pasa a oscuro bajo 25 lux y conserva el estado en la banda intermedia', () {
      store.updateAmbientLux(61);
      expect(store.darkTheme, isFalse);

      store.updateAmbientLux(40);
      expect(store.darkTheme, isFalse);

      store.updateAmbientLux(24);
      expect(store.darkTheme, isTrue);

      store.updateAmbientLux(40);
      expect(store.darkTheme, isTrue);
    });

    test('no cambia el tema si se eligió claro u oscuro manualmente', () {
      store
        ..appearanceMode = 'light'
        ..darkTheme = false;
      store.updateAmbientLux(2);
      expect(store.darkTheme, isFalse);

      store
        ..appearanceMode = 'dark'
        ..darkTheme = true;
      store.updateAmbientLux(1000);
      expect(store.darkTheme, isTrue);
    });

    test('ignora valores negativos, NaN e infinitos', () {
      for (final lux in [-1.0, double.nan, double.infinity]) {
        store.updateAmbientLux(lux);
        expect(store.darkTheme, isTrue);
      }
    });
  });
}
