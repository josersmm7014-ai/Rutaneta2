import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:light_sensor/light_sensor.dart';

import 'store.dart';

/// Escucha el sensor de luz solo cuando RutaNeta está activa y el modo
/// seleccionado es automático. Si el sensor falta o falla, Store conserva
/// el tema oscuro de respaldo.
class AmbientThemeController with WidgetsBindingObserver {
  StreamSubscription<int>? _subscription;
  bool _registered = false;
  int _generation = 0;

  Future<void> initialize() async {
    if (!_registered) {
      WidgetsBinding.instance.addObserver(this);
      _registered = true;
    }
    await refresh();
  }

  Future<void> refresh() async {
    final generation = ++_generation;
    await _stopListening();
    if (store.appearanceMode != 'auto') return;
    if (WidgetsBinding.instance.lifecycleState != AppLifecycleState.resumed) {
      return;
    }

    try {
      final available = await LightSensor.hasSensor();
      if (generation != _generation || !available) return;
      final subscription = LightSensor.luxStream().listen(
        (lux) => store.updateAmbientLux(lux.toDouble()),
        onError: (Object _) {
          if (generation != _generation) return;
          _generation++;
          unawaited(_stopListening());
        },
        cancelOnError: true,
      );
      if (generation != _generation) {
        await subscription.cancel();
      } else {
        _subscription = subscription;
      }
    } catch (_) {
      // Mantener el respaldo oscuro sin impedir el arranque de la app.
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(refresh());
    } else {
      _generation++;
      unawaited(_stopListening());
    }
  }

  Future<void> _stopListening() async {
    final active = _subscription;
    _subscription = null;
    await active?.cancel();
  }

  Future<void> dispose() async {
    _generation++;
    if (_registered) {
      WidgetsBinding.instance.removeObserver(this);
      _registered = false;
    }
    await _stopListening();
  }
}

final AmbientThemeController ambientThemeController = AmbientThemeController();
