/// Lógica aislada para probar transcripciones de voz sin micrófono ni audio.
/// La capa Speech-to-Text futura debe enviar aquí únicamente texto reconocido.
enum VoiceIntent {
  offerReadback,
  dailySummary,
  confirmCalculation,
  cancel,
  repeat,
  stopListening,
  unknown,
}

class VoiceOffer {
  final double price;
  final double km;
  final double minutes;

  VoiceOffer({required this.price, required this.km, required this.minutes}) {
    if (!price.isFinite || price <= 0) {
      throw ArgumentError.value(price, 'price', 'Debe ser un número positivo');
    }
    if (!km.isFinite || km <= 0) {
      throw ArgumentError.value(km, 'km', 'Debe ser un número positivo');
    }
    if (!minutes.isFinite || minutes <= 0) {
      throw ArgumentError.value(
          minutes, 'minutes', 'Debe ser un número positivo');
    }
  }
}

class VoiceReply {
  final VoiceIntent intent;
  final String speech;
  final bool shouldCalculate;
  final bool shouldStopListening;
  final VoiceOffer? offer;

  const VoiceReply({
    required this.intent,
    required this.speech,
    this.shouldCalculate = false,
    this.shouldStopListening = false,
    this.offer,
  });
}

/// Enrutador seguro para comandos concretos en español.
/// No ejecuta acciones de otras apps ni calcula sin una oferta confirmada.
class VoiceCommandRouter {
  final Duration confirmationTimeout;

  VoiceOffer? _pendingOffer;
  DateTime? _pendingUntil;
  String? _lastSpoken;

  VoiceCommandRouter({
    this.confirmationTimeout = const Duration(seconds: 30),
  }) {
    if (confirmationTimeout <= Duration.zero) {
      throw ArgumentError.value(
        confirmationTimeout,
        'confirmationTimeout',
        'Debe ser mayor que cero',
      );
    }
  }

  bool get hasPendingOffer => _pendingOffer != null;

  VoiceReply offerDetected(VoiceOffer offer, {DateTime? now}) {
    final current = now ?? DateTime.now();
    _expire(current);
    if (_pendingOffer != null) {
      return _reply(
        VoiceIntent.unknown,
        'Ya hay una oferta pendiente. Di «calcular» o «cancelar» primero.',
      );
    }
    _pendingOffer = offer;
    _pendingUntil = current.add(confirmationTimeout);
    return _reply(
      VoiceIntent.offerReadback,
      'Detecté ${offer.price.toStringAsFixed(2)} dólares, '
      '${offer.km.toStringAsFixed(1)} kilómetros y '
      '${offer.minutes.toStringAsFixed(0)} minutos. '
      'Di «calcular» o «cancelar».',
      offer: offer,
    );
  }

  VoiceReply handle(String transcript, {DateTime? now}) {
    final current = now ?? DateTime.now();
    final expired = _expire(current);
    final command = _normalize(transcript);

    if (command.isEmpty) {
      return _reply(VoiceIntent.unknown, 'No escuché un comando. Inténtalo de nuevo.');
    }

    if (_matches(command, const [
      'detener voz',
      'para voz',
      'detener escucha',
      'terminar voz',
    ])) {
      _clearPending();
      return _reply(
        VoiceIntent.stopListening,
        'Asistente de voz detenido.',
        shouldStopListening: true,
      );
    }

    if (_matches(command, const [
      'resumen de hoy',
      'cuanto llevo hoy',
      'cuanto llevo',
      'ganancia de hoy',
    ])) {
      return _reply(
        VoiceIntent.dailySummary,
        'Solicitud de resumen diario.',
      );
    }

    if (_matches(command, const ['repetir', 'repite'])) {
      final last = _lastSpoken;
      return VoiceReply(
        intent: VoiceIntent.repeat,
        speech: last ?? 'Todavía no hay un mensaje para repetir.',
      );
    }

    if (_matches(command, const ['cancelar', 'cancela', 'no'])) {
      final hadPending = _pendingOffer != null;
      _clearPending();
      return _reply(
        VoiceIntent.cancel,
        hadPending ? 'Oferta cancelada. No se calculó.' : 'No hay una operación pendiente.',
      );
    }

    if (_matches(command, const [
      'calcular',
      'calcula',
      'confirmar',
      'confirmo',
      'si',
      'si calcular',
    ])) {
      if (expired) {
        return _reply(
          VoiceIntent.cancel,
          'La confirmación venció. Vuelve a leer la oferta para intentarlo otra vez.',
        );
      }
      final offer = _pendingOffer;
      if (offer == null) {
        return _reply(
          VoiceIntent.unknown,
          'No hay una oferta pendiente para calcular.',
        );
      }
      _clearPending(); // Consumir antes de devolver: evita doble confirmación.
      return _reply(
        VoiceIntent.confirmCalculation,
        'Confirmación recibida. Calculando la oferta.',
        shouldCalculate: true,
        offer: offer,
      );
    }

    return _reply(
      VoiceIntent.unknown,
      'No reconocí ese comando. Puedes decir «resumen de hoy», «calcular» o «cancelar».',
    );
  }

  bool _expire(DateTime now) {
    final deadline = _pendingUntil;
    if (_pendingOffer != null && deadline != null && !now.isBefore(deadline)) {
      _clearPending();
      return true;
    }
    return false;
  }

  void _clearPending() {
    _pendingOffer = null;
    _pendingUntil = null;
  }

  VoiceReply _reply(
    VoiceIntent intent,
    String speech, {
    bool shouldCalculate = false,
    bool shouldStopListening = false,
    VoiceOffer? offer,
  }) {
    _lastSpoken = speech;
    return VoiceReply(
      intent: intent,
      speech: speech,
      shouldCalculate: shouldCalculate,
      shouldStopListening: shouldStopListening,
      offer: offer,
    );
  }

  static bool _matches(String command, List<String> options) =>
      options.contains(command);

  static String _normalize(String input) {
    return input
        .toLowerCase()
        .replaceAll('á', 'a')
        .replaceAll('é', 'e')
        .replaceAll('í', 'i')
        .replaceAll('ó', 'o')
        .replaceAll('ú', 'u')
        .replaceAll('ü', 'u')
        .replaceAll(RegExp(r'[¿?¡!.,;:]'), '')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }
}
