import 'package:flutter/material.dart';

String trafficConsultedTime(dynamic raw) {
  final time = DateTime.tryParse('$raw')?.toLocal();
  if (time == null) return 'sin hora';
  return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
}

class TrafficReviewPanel extends StatelessWidget {
  final Map<String, dynamic>? route;
  final bool returnEmpty;
  final bool selected;
  final ValueChanged<bool> onSelected;
  final VoidCallback onRefresh;
  const TrafficReviewPanel({
    super.key,
    required this.route,
    required this.returnEmpty,
    required this.selected,
    required this.onSelected,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    final data = route;
    final available =
        data != null &&
        data['fresh'] == true &&
        data['hasTrafficData'] == true &&
        (!returnEmpty || data['returnMinutes'] != null);
    return Container(
      margin: const EdgeInsets.only(top: 10),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFF202736),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'TRÁFICO POR DESTINO',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
          ),
          if (data == null)
            const Text(
              'Elige el destino en Mapa para usar su tráfico en este viaje.',
              style: TextStyle(fontSize: 12),
            ),
          if (data != null) ...[
            Text(
              '${data['destination']}',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            Text(
              '${(data['km'] as num).toStringAsFixed(1)} km · ${(data['minutes'] as num).toStringAsFixed(0)} min de ida',
              style: const TextStyle(fontSize: 12),
            ),
            Text(
              '${data['status']} · cobertura ${((data['coverageRatio'] as num) * 100).round()}% · consultado ${trafficConsultedTime(data['checkedAt'])}',
              style: const TextStyle(fontSize: 11),
            ),
            if (data['fresh'] != true)
              const Text(
                'La consulta está desactualizada: actualiza la ruta en el mapa.',
                style: TextStyle(color: Colors.amber, fontSize: 12),
              ),
            if (data['hasTrafficData'] != true)
              const Text(
                'Sin datos de congestión para esta ruta.',
                style: TextStyle(color: Colors.amber, fontSize: 12),
              ),
            if (returnEmpty && data['returnMinutes'] == null)
              const Text(
                'Falta consultar el regreso en el mapa.',
                style: TextStyle(color: Colors.amber, fontSize: 12),
              ),
            if (returnEmpty &&
                data['returnMinutes'] != null &&
                data['returnHasTrafficData'] != true)
              const Text(
                'Vuelta estimada: sin cobertura de congestión.',
                style: TextStyle(color: Colors.amber, fontSize: 12),
              ),
            Material(
              color: const Color(0xFF202736),
              child: CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                dense: true,
                controlAffinity: ListTileControlAffinity.leading,
                title: const Text(
                  'Confirmo este destino: usar su tráfico',
                  style: TextStyle(fontSize: 12),
                ),
                value: selected,
                onChanged: available || selected
                    ? (v) => onSelected(v ?? false)
                    : null,
              ),
            ),
            const Text(
              'Al activarlo se usarán los km y tiempos de esta ruta, no los de otra oferta.',
              style: TextStyle(fontSize: 11),
            ),
          ],
          TextButton(
            onPressed: onRefresh,
            child: const Text(
              'ACTUALIZAR RUTA ELEGIDA',
              style: TextStyle(fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }
}
