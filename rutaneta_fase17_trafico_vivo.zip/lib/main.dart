import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'ambient_theme.dart';
import 'overlay.dart';
import 'screens.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.load();
  OverlayCtrl.init();
  runApp(const RutaNetaApp());
  unawaited(ambientThemeController.initialize());
}

/// Punto de entrada de la burbuja flotante (lo llama el plugin de overlay).
@pragma('vm:entry-point')
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    const MaterialApp(debugShowCheckedModeBanner: false, home: OverlayBubble()),
  );
}

class RutaNetaApp extends StatelessWidget {
  const RutaNetaApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Keep MaterialApp and its inherited widgets mounted while preferences
    // change. Replacing MaterialApp from a Store listener can deactivate an
    // InheritedElement before its dependents have detached (framework.dart
    // _dependents.isEmpty).
    return MaterialApp(
      title: 'RutaNeta',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true),
      builder: (context, child) => _StoreTheme(child: child!),
      home: const _AppHome(),
    );
  }
}

class _StoreTheme extends StatelessWidget {
  final Widget child;

  const _StoreTheme({required this.child});

  @override
  Widget build(BuildContext context) =>
      Theme(data: _storeTheme(), child: child);
}

class _AppHome extends StatelessWidget {
  const _AppHome();

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) =>
          store.vehicle == null ? const OnboardingScreen() : const MainShell(),
    );
  }
}

ThemeData _storeTheme() {
  final visible = store.highVisibility;
  final dark = store.darkTheme;
  final onBackground = dark ? Colors.white : const Color(0xFF17231B);
  const green = Color(0xFF00D96A);
  const yellow = Color(0xFFFFD54F);
  const navy = Color(0xFF151621);
  const cardSurface = Color(0xFF20212D);
  final scheme =
      ColorScheme.fromSeed(
        seedColor: visible ? yellow : green,
        brightness: dark ? Brightness.dark : Brightness.light,
      ).copyWith(
        primary: visible ? yellow : green,
        onPrimary: Colors.black,
        secondary: visible ? yellow : green,
        onSecondary: Colors.black,
        surface: dark ? cardSurface : Colors.white,
        onSurface: onBackground,
      );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: dark
        ? (visible ? Colors.black : navy)
        : const Color(0xFFF3F7F4),
    appBarTheme: AppBarTheme(
      backgroundColor: dark ? navy : const Color(0xFFE7EFEA),
      foregroundColor: onBackground,
      toolbarHeight: visible ? 72 : 64,
      centerTitle: true,
      elevation: 0,
      scrolledUnderElevation: 0,
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: dark ? Brightness.light : Brightness.dark,
        systemNavigationBarColor: dark ? navy : const Color(0xFFF3F7F4),
        systemNavigationBarIconBrightness: dark
            ? Brightness.light
            : Brightness.dark,
      ),
    ),
    cardTheme: CardThemeData(
      color: dark ? cardSurface : Colors.white,
      surfaceTintColor: Colors.transparent,
      shadowColor: Colors.black26,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(
          color: dark ? const Color(0xFF30313E) : const Color(0xFFE0E6E2),
        ),
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: dark ? const Color(0xFF191A26) : const Color(0xFFE7EFEA),
      surfaceTintColor: Colors.transparent,
      indicatorColor: Colors.transparent,
      labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
      labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
        (states) => TextStyle(
          color: states.contains(WidgetState.selected)
              ? green
              : (dark ? const Color(0xFF9A9BA8) : const Color(0xFF66736B)),
          fontWeight: states.contains(WidgetState.selected)
              ? FontWeight.w800
              : FontWeight.w500,
          fontSize: 12,
        ),
      ),
      iconTheme: WidgetStateProperty.resolveWith<IconThemeData?>(
        (states) => IconThemeData(
          color: states.contains(WidgetState.selected)
              ? green
              : (dark ? const Color(0xFF9A9BA8) : const Color(0xFF66736B)),
          size: states.contains(WidgetState.selected) ? 30 : 27,
        ),
      ),
    ),
    textTheme: (dark ? ThemeData.dark() : ThemeData.light()).textTheme.apply(
      fontSizeFactor: visible ? 1.14 : 1.0,
      bodyColor: onBackground,
      displayColor: onBackground,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: dark,
      fillColor: dark ? const Color(0xFF262733) : Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(
          color: dark
              ? (visible ? Colors.white70 : Colors.white38)
              : Colors.black54,
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(14),
        borderSide: BorderSide(
          color: visible ? (dark ? yellow : const Color(0xFF705700)) : green,
          width: 2,
        ),
      ),
      contentPadding: EdgeInsets.symmetric(
        horizontal: 18,
        vertical: visible ? 22 : 18,
      ),
      labelStyle: TextStyle(
        fontSize: visible ? 19 : 16,
        color: dark ? Colors.white : const Color(0xFF26352B),
      ),
      helperStyle: TextStyle(
        fontSize: visible ? 15 : 12,
        color: dark ? Colors.white70 : const Color(0xFF53645A),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: Size(0, visible ? 84 : 72),
        backgroundColor: visible ? yellow : const Color(0xFF4ADE80),
        foregroundColor: Colors.black,
        textStyle: TextStyle(
          fontSize: visible ? 23 : 20,
          fontWeight: FontWeight.bold,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        padding: EdgeInsets.symmetric(
          vertical: visible ? 18 : 14,
          horizontal: 20,
        ),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: Size(0, visible ? 76 : 68),
        foregroundColor: visible
            ? (dark ? yellow : const Color(0xFF705700))
            : (dark ? const Color(0xFFC9F7D8) : const Color(0xFF145D35)),
        side: BorderSide(
          color: visible
              ? (dark ? yellow : const Color(0xFF806500))
              : (dark ? const Color(0xFF4ADE80) : const Color(0xFF1B8E5A)),
          width: 2,
        ),
        textStyle: TextStyle(fontSize: visible ? 21 : 19),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        minimumSize: Size(0, visible ? 64 : 56),
        foregroundColor: visible
            ? (dark ? yellow : const Color(0xFF705700))
            : (dark ? const Color(0xFFC9F7D8) : const Color(0xFF145D35)),
        textStyle: TextStyle(fontSize: visible ? 19 : 17),
      ),
    ),
    iconButtonTheme: IconButtonThemeData(
      style: IconButton.styleFrom(
        minimumSize: Size.square(visible ? 64 : 56),
        iconSize: visible ? 32 : 28,
        foregroundColor: visible
            ? (dark ? yellow : const Color(0xFF705700))
            : (dark ? const Color(0xFFC9F7D8) : const Color(0xFF145D35)),
      ),
    ),
    listTileTheme: ListTileThemeData(
      minVerticalPadding: visible ? 16 : 12,
      contentPadding: const EdgeInsets.symmetric(horizontal: 18),
      iconColor: visible
          ? (dark ? yellow : const Color(0xFF705700))
          : (dark ? null : const Color(0xFF145D35)),
    ),
  );
}
