import 'package:flutter/services.dart';

class OverlayBridge {
  static const channel = MethodChannel('rutaviva/overlay_bridge');
  static Future<String> capture() async {
    final path = await channel
        .invokeMethod<String>('capture')
        .timeout(const Duration(seconds: 6));
    if (path == null || path.isEmpty)
      throw PlatformException(
        code: 'NO_FRAME',
        message: 'La captura no entregó una imagen.',
      );
    return path;
  }

  static Future<Map<String, dynamic>> command(
    String name, [
    Map<String, dynamic>? data,
  ]) async {
    final reply = await channel
        .invokeMapMethod<String, dynamic>(name, data)
        .timeout(const Duration(seconds: 7));
    if (reply == null)
      throw PlatformException(
        code: 'EMPTY_REPLY',
        message: 'La app no devolvió respuesta.',
      );
    return reply;
  }
}
