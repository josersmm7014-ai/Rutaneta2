import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

class OcrResult {
  final double? price;
  final double? km;
  final double? minutes;
  final String text;
  final List<String> warnings;
  const OcrResult({
    this.price,
    this.km,
    this.minutes,
    required this.text,
    this.warnings = const [],
  });
}

double? _num(String s) =>
    double.tryParse(s.replaceAll(RegExp(r'\s+'), '').replaceAll(',', '.'));

class _RouteReading {
  final double km;
  final double? minutes;
  final bool decimal;
  final int context;
  final int order;
  const _RouteReading(
    this.km,
    this.minutes,
    this.decimal,
    this.context,
    this.order,
  );
}

/// Analiza las parejas km/min sin escoger el número más grande de la pantalla.
OcrResult parseTripText(String original) {
  final text = original
      .replaceAll('\u00a0', ' ')
      .replaceAllMapped(
        RegExp(r'(\d)\s*[·∙•]\s*(\d)'),
        (m) => '${m[1]}.${m[2]}',
      );
  final lines = text.split('\n');
  final before = RegExp(
    r'(?:\$|USD|MXN)\s*(\d+(?:[.,]\d{1,2})?)',
    caseSensitive: false,
  );
  final after = RegExp(
    r'(\d+(?:[.,]\d{1,2})?)\s*(?:\$|USD|MXN)',
    caseSensitive: false,
  );
  final standalone = RegExp(
    r'^\s*(?:(?:\$|USD|MXN)\s*\d+(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?\s*(?:\$|USD|MXN))\s*$',
    caseSensitive: false,
  );
  final kmPattern = RegExp(
    r'(?<![\d.,])(\d+(?:\s*[.,]\s*\d+)?)\s*(?:kms?|kil[oó]metros?)\b',
    caseSensitive: false,
  );
  final minPattern = RegExp(
    r'(\d+(?:[.,]\d+)?)\s*(?:mins?|minutos?)\b',
    caseSensitive: false,
  );
  double? price;
  double? minutes;
  final readings = <_RouteReading>[];
  final warnings = <String>[];
  for (final line in [
    ...lines.where((l) => standalone.hasMatch(l)),
    ...lines,
  ]) {
    if (RegExp(
      r'neto|meta|por hora|/\s*(?:h|km)|ganancia|combustible',
      caseSensitive: false,
    ).hasMatch(line))
      continue;
    final match = before.firstMatch(line) ?? after.firstMatch(line);
    final value = match == null ? null : _num(match.group(1)!);
    if (value != null && value > 0 && value.isFinite) {
      price = value;
      break;
    }
  }
  for (var i = 0; i < lines.length; i++) {
    final line = lines[i];
    if (RegExp(
      r'solicitud creada|hace\s+\d|neto|vac[ií]os',
      caseSensitive: false,
    ).hasMatch(line))
      continue;
    final pickup = RegExp(
      r'recogida|pickup',
      caseSensitive: false,
    ).hasMatch(line);
    final context =
        RegExp(r'viaje|trayecto|destino', caseSensitive: false).hasMatch(line)
        ? 10
        : pickup ||
              RegExp(r'mapa|navegador', caseSensitive: false).hasMatch(line)
        ? -10
        : 0;
    final timeMatch = minPattern.firstMatch(line);
    final time = timeMatch == null ? null : _num(timeMatch.group(1)!);
    if (!pickup && time != null && time > 0) minutes = time;
    // Un espacio entre dígitos sin separador no demuestra dónde va el decimal.
    if (RegExp(r'\d+\s+\d+\s*km\b', caseSensitive: false).hasMatch(line)) {
      warnings.add('No pude confirmar el separador decimal de los kilómetros.');
      continue;
    }
    for (final match in kmPattern.allMatches(line)) {
      final token = match.group(1)!;
      final value = _num(token);
      if (value != null && value > 0)
        readings.add(
          _RouteReading(
            value,
            time,
            token.contains('.') || token.contains(','),
            context,
            i,
          ),
        );
    }
  }
  readings.sort((a, b) {
    final contextOrder = a.context.compareTo(b.context);
    if (contextOrder != 0) return contextOrder;
    final pairedOrder = (a.minutes == null ? 0 : 1).compareTo(
      b.minutes == null ? 0 : 1,
    );
    return pairedOrder != 0 ? pairedOrder : a.order.compareTo(b.order);
  });
  _RouteReading? selected = readings.isEmpty ? null : readings.last;
  // Solo preferir 15.4 frente a 154 si el decimal existe en otra lectura compatible.
  if (selected != null && !selected.decimal) {
    for (final reading in readings.reversed) {
      if (reading.decimal &&
          reading.context >= selected!.context &&
          reading.minutes != null &&
          selected.minutes != null &&
          (reading.minutes! - selected.minutes!).abs() < 0.1 &&
          (reading.km * 10 - selected.km).abs() < 0.001) {
        selected = reading;
        break;
      }
    }
  }
  double? km = selected?.km;
  minutes = selected?.minutes ?? minutes;
  if (km != null && minutes != null && minutes > 0 && km / minutes * 60 > 180) {
    warnings.add(
      'OCR leyó $km km, pero la distancia y el tiempo no son coherentes. Confirma los kilómetros manualmente.',
    );
    // No dividir por diez ni convertir un viaje dudoso en un cálculo automático.
    km = null;
  }
  return OcrResult(
    price: price,
    km: km,
    minutes: minutes,
    text: original,
    warnings: warnings,
  );
}

/// Recorta y amplía solo para reconocer texto; conserva intacta la captura original.
String? _prepareDetail(String path) {
  final file = File(path);
  if (!file.existsSync()) return null;
  final source = img.decodeImage(file.readAsBytesSync());
  if (source == null || source.width < 10 || source.height < 10) return null;
  final start = (source.height * 0.36).round();
  final detail = img.copyCrop(
    source,
    x: 0,
    y: start,
    width: source.width,
    height: source.height - start,
  );
  final zoomed = img.copyResize(
    detail,
    width: math.min(source.width * 2, 2560),
    interpolation: img.Interpolation.nearest,
  );
  final output = '$path.detail-ocr.png';
  File(output).writeAsBytesSync(img.encodePng(zoomed, level: 1));
  return output;
}

Future<OcrResult> readScreenshot(String path) async {
  final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
  String? detailPath;
  try {
    final result = await recognizer.processImage(InputImage.fromFilePath(path));
    final first = parseTripText(result.text);
    // Los decimales claros no necesitan una segunda pasada.
    if (first.km != null && (first.km! < 10 || first.km! % 1 != 0))
      return first;
    try {
      detailPath = await compute(_prepareDetail, path);
      if (detailPath == null) return first;
      final detail = await recognizer.processImage(
        InputImage.fromFilePath(detailPath),
      );
      final second = parseTripText(detail.text);
      if (second.km == null) return first;
      return OcrResult(
        price: first.price ?? second.price,
        km: second.km,
        minutes: second.minutes ?? first.minutes,
        text: '${result.text}\n${detail.text}',
        warnings: second.warnings,
      );
    } catch (_) {
      return first;
    }
  } finally {
    await recognizer.close();
    if (detailPath != null) {
      try {
        await File(detailPath).delete();
      } catch (_) {}
    }
  }
}
