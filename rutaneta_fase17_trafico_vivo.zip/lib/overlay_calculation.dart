import 'models.dart';

Trip calculateOverlayTrip({
  required Vehicle vehicle,
  required double price,
  required double km,
  required double minutes,
  required bool returnEmpty,
  double? returnKm,
  double? returnMinutes,
  double? typicalMinutes,
  double? returnTypicalMinutes,
  DateTime? trafficCheckedAt,
  String? trafficSource,
  String origin = '',
  String destination = '',
}) {
  if (![
        price,
        km,
        minutes,
        vehicle.kmPerGal,
        vehicle.fuelPrice,
      ].every((v) => v.isFinite) ||
      price <= 0 ||
      km <= 0 ||
      minutes <= 0 ||
      vehicle.kmPerGal <= 0 ||
      vehicle.fuelPrice < 0 ||
      !_isFinitePositiveOrNull(returnKm) ||
      !_isFinitePositiveOrNull(returnMinutes) ||
      !_isFinitePositiveOrNull(typicalMinutes) ||
      !_isFinitePositiveOrNull(returnTypicalMinutes)) {
    throw const FormatException(
      'Escribe precio, km y minutos mayores que cero y revisa tu vehículo.',
    );
  }
  return Trip(
    id: DateTime.now().microsecondsSinceEpoch.toString(),
    date: DateTime.now(),
    origin: origin,
    destination: destination,
    price: price,
    km: km,
    minutes: minutes,
    returnEmpty: returnEmpty,
    fuelCost: vehicle.fuelCostFor(km + (returnEmpty ? (returnKm ?? km) : 0)),
    returnKm: returnKm,
    returnMinutes: returnMinutes,
    typicalMinutes: typicalMinutes,
    returnTypicalMinutes: returnTypicalMinutes,
    trafficCheckedAt: trafficCheckedAt,
    trafficSource: trafficSource,
  );
}

bool _isFinitePositiveOrNull(double? value) =>
    value == null || (value.isFinite && value > 0);
