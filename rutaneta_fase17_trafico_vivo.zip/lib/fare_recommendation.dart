import 'models.dart';

const double _commissionRate = 0.15;
const double _wearPerTravelKm = 0.03;
const double _comparisonTolerance = 1e-9;

/// Resultado de la tarifa necesaria para alcanzar una ganancia neta por hora.
class FareRecommendation {
  final double breakEvenFare;
  final double recommendedFare;
  final double requiredIncrease;
  final double targetNetPerHour;
  final double projectedNet;
  final double projectedPerHour;
  final String signal;
  final String verdict;

  const FareRecommendation({
    required this.breakEvenFare,
    required this.recommendedFare,
    required this.requiredIncrease,
    required this.targetNetPerHour,
    required this.projectedNet,
    required this.projectedPerHour,
    required this.signal,
    required this.verdict,
  });
}

/// Recomienda la tarifa que deja al menos [targetNetPerHour] netos por hora.
FareRecommendation recommendFare(
  Trip trip, {
  required double targetNetPerHour,
}) {
  _requireFinitePositive(targetNetPerHour, 'targetNetPerHour');
  _requireFiniteNonNegative(trip.price, 'trip.price');
  _requireFiniteNonNegative(trip.km, 'trip.km');
  _requireFiniteNonNegative(trip.minutes, 'trip.minutes');
  _requireFiniteNonNegative(trip.fuelCost, 'trip.fuelCost');

  final hours = trip.hours;
  final travelKm = trip.travelKm;
  final fuelCost = trip.fuelCost;
  final wear = travelKm * _wearPerTravelKm;
  _requireFinitePositive(hours, 'trip.hours');
  _requireFiniteNonNegative(travelKm, 'trip.travelKm');
  _requireFiniteNonNegative(wear, 'trip.wear');

  final operatingCosts = fuelCost + wear;
  _requireFiniteNonNegative(operatingCosts, 'operating costs');

  final breakEvenExact = operatingCosts / (1 - _commissionRate);
  final requiredFareExact =
      (operatingCosts + targetNetPerHour * hours) / (1 - _commissionRate);
  _requireFiniteNonNegative(breakEvenExact, 'break-even fare');
  _requireFiniteNonNegative(requiredFareExact, 'recommended fare');

  final breakEvenFare = _ceilCent(breakEvenExact);
  final recommendedFare = _ceilCent(requiredFareExact);
  final increaseBeforeRounding = recommendedFare - trip.price;
  final requiredIncrease = increaseBeforeRounding > 0
      ? _ceilCent(increaseBeforeRounding)
      : 0.0;

  final projectedNet = recommendedFare * (1 - _commissionRate) - operatingCosts;
  final projectedPerHour = projectedNet / hours;
  _requireFinite(projectedNet, 'projectedNet');
  _requireFinite(projectedPerHour, 'projectedPerHour');

  // El semáforo describe la oferta recibida; los campos projected* describen
  // la tarifa recomendada y sirven para comprobar que alcanza el objetivo.
  final currentNet = trip.price * (1 - _commissionRate) - operatingCosts;
  final currentPerHour = currentNet / hours;
  _requireFinite(currentNet, 'current net');
  _requireFinite(currentPerHour, 'current per hour');
  final reachesTarget =
      currentPerHour >= targetNetPerHour - _comparisonTolerance;
  final isGreen = currentNet >= -_comparisonTolerance && reachesTarget;
  final isRed = currentNet < 0 || currentPerHour < targetNetPerHour * 0.5;
  final signal = isGreen
      ? 'green'
      : isRed
      ? 'red'
      : 'yellow';
  final verdict = signal == 'green'
      ? 'CONVIENE'
      : signal == 'red'
      ? 'NO CONVIENE'
      : 'DUDOSO';

  return FareRecommendation(
    breakEvenFare: breakEvenFare,
    recommendedFare: recommendedFare,
    requiredIncrease: requiredIncrease,
    targetNetPerHour: targetNetPerHour,
    projectedNet: projectedNet,
    projectedPerHour: projectedPerHour,
    signal: signal,
    verdict: verdict,
  );
}

double _ceilCent(double value) {
  _requireFinite(value, 'cent value');
  final scaled = value * 100;
  final nearestInteger = scaled.roundToDouble();
  // Avoid promoting a mathematically exact cent because of binary noise.
  final roundedScaled = (scaled - nearestInteger).abs() <= _comparisonTolerance
      ? nearestInteger
      : scaled.ceilToDouble();
  return roundedScaled / 100;
}

void _requireFinite(double value, String name) {
  if (!value.isFinite) {
    throw ArgumentError.value(value, name, 'must be finite');
  }
}

void _requireFinitePositive(double value, String name) {
  _requireFinite(value, name);
  if (value <= 0) {
    throw ArgumentError.value(value, name, 'must be greater than zero');
  }
}

void _requireFiniteNonNegative(double value, String name) {
  _requireFinite(value, name);
  if (value < 0) {
    throw ArgumentError.value(value, name, 'must be non-negative');
  }
}
