import 'geo.dart';

/// Ruta elegida explícitamente por el conductor. Vive solo en memoria local.
class ActiveTrafficTrip {
  final GeoPoint origin;
  final GeoPoint destination;
  final String originLabel;
  final String destinationLabel;
  final TrafficRouteInfo outbound;
  final TrafficRouteInfo? returnRoute;

  const ActiveTrafficTrip({
    required this.origin,
    required this.destination,
    required this.originLabel,
    required this.destinationLabel,
    required this.outbound,
    this.returnRoute,
  });

  String get destinationId =>
      '${destination.lat.toStringAsFixed(6)},${destination.lon.toStringAsFixed(6)}';

  bool get fresh {
    final time = outbound.checkedAt;
    if (time == null) return false;
    final age = DateTime.now().difference(time);
    if (age.isNegative || age > const Duration(minutes: 3)) return false;
    final backTime = returnRoute?.checkedAt;
    return backTime == null ||
        (!DateTime.now().difference(backTime).isNegative &&
            DateTime.now().difference(backTime) <= const Duration(minutes: 3));
  }

  Map<String, dynamic> toOverlaySummary() => {
    'origin': originLabel,
    'destination': destinationLabel,
    'destinationId': destinationId,
    'km': outbound.km,
    'minutes': outbound.minutes,
    'typicalMinutes': outbound.typicalMinutes,
    'returnKm': returnRoute?.km,
    'returnMinutes': returnRoute?.minutes,
    'returnTypicalMinutes': returnRoute?.typicalMinutes,
    'returnHasTrafficData': returnRoute?.hasTrafficData ?? false,
    'returnSource': returnRoute?.source,
    'hasTrafficData': outbound.hasTrafficData,
    'fresh': fresh,
    'status': outbound.status,
    'coverageRatio': outbound.coverageRatio,
    'checkedAt': outbound.checkedAt?.toIso8601String(),
    'source': outbound.source,
  };
}
