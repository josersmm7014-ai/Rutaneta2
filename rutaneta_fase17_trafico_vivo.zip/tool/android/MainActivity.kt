package com.rutaviva.rutaviva

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "rutaviva/capture"
    private val reqCode = 7001
    private var pending: MethodChannel.Result? = null
    private val overlayInstallHandler = Handler(Looper.getMainLooper())
    private var overlayInstallScheduled = false
    private var overlayInstallAttempts = 0

    private val overlayInstallRunnable = object : Runnable {
        override fun run() {
            overlayInstallScheduled = false
            if (OverlayBridge.install()) {
                overlayInstallAttempts = 0
                return
            }
            if (overlayInstallAttempts < 19) {
                overlayInstallAttempts++
                overlayInstallScheduled = true
                overlayInstallHandler.postDelayed(this, 100L)
            }
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        OverlayBridge.bindMain(flutterEngine)
        ensureOverlayBridgeInstalled()

        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "start" -> {
                        if (CaptureService.instance?.active == true) {
                            result.success(true)
                        } else {
                            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                            pending = result
                            val captureIntent = if (Build.VERSION.SDK_INT >= 34) {
                                mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
                            } else {
                                mpm.createScreenCaptureIntent()
                            }
                            startActivityForResult(captureIntent, reqCode)
                        }
                    }
                    "capture" -> result.success(CaptureService.instance?.captureToFile())
                    "isActive" -> result.success(CaptureService.instance?.active == true)
                    "stop" -> {
                        stopService(Intent(this, CaptureService::class.java))
                        result.success(true)
                    }
                    else -> result.notImplemented()
                }
            }
    }

    override fun onStart() {
        super.onStart()
        ensureOverlayBridgeInstalled()
    }

    private fun ensureOverlayBridgeInstalled() {
        if (OverlayBridge.install()) {
            overlayInstallAttempts = 0
            return
        }
        if (!overlayInstallScheduled) {
            overlayInstallAttempts = 0
            overlayInstallScheduled = true
            overlayInstallHandler.postDelayed(overlayInstallRunnable, 100L)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCode) {
            val res = pending
            pending = null
            if (resultCode == Activity.RESULT_OK && data != null) {
                val i = Intent(this, CaptureService::class.java)
                    .putExtra(CaptureService.EXTRA_CODE, resultCode)
                    .putExtra(CaptureService.EXTRA_DATA, data)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                res?.success(true)
            } else {
                res?.success(false)
            }
        }
    }
}
