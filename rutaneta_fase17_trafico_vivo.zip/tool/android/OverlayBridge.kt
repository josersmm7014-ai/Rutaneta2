package com.rutaviva.rutaviva

import android.os.Handler
import android.os.Looper
import flutter.overlay.window.flutter_overlay_window.OverlayService
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.engine.FlutterEngineCache
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.lang.ref.WeakReference
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Puente nativo entre el motor Flutter del overlay y el motor principal.
 *
 * El canal del motor principal no instala un handler: Dart es su propietario.
 * El handler de overlay se instala sobre el motor cacheado por el plugin.
 */
object OverlayBridge {
    private const val OVERLAY_ENGINE_KEY = "myCachedEngine"
    private const val OVERLAY_CHANNEL = "rutaviva/overlay_bridge"
    private const val MAIN_CHANNEL = "rutaviva/overlay_control"

    private const val CAPTURE_DELAY_MS = 650L
    private const val CAPTURE_WATCHDOG_MS = 4500L
    private const val MAIN_TIMEOUT_MS = 5000L

    private val mainHandler = Handler(Looper.getMainLooper())

    // El motor principal vive con la Activity; no se instala aquí ningún handler.
    @Volatile
    private var mainChannel: MethodChannel? = null

    // No conservar una referencia fuerte al motor/MethodChannel del overlay.
    private var overlayEngineRef: WeakReference<FlutterEngine>? = null
    private var overlayInstalled = false

    @Synchronized
    fun bindMain(engine: FlutterEngine) {
        mainChannel = MethodChannel(engine.dartExecutor.binaryMessenger, MAIN_CHANNEL)
    }

    /**
     * Instala (o confirma) el único handler nativo del canal del motor overlay.
     * Devuelve false mientras el plugin aún no ha puesto el motor en FlutterEngineCache.
     */
    @Synchronized
    fun install(): Boolean {
        val engine = FlutterEngineCache.getInstance().get(OVERLAY_ENGINE_KEY) ?: return false
        val previousEngine = overlayEngineRef?.get()

        if (overlayInstalled && previousEngine === engine) {
            if (engine.dartExecutor.isExecutingDart) {
                return true
            }
            // Un FlutterEngine destruido puede quedar temporalmente en la caché
            // del plugin. No dejar su handler como el vigente.
            try {
                MethodChannel(engine.dartExecutor.binaryMessenger, OVERLAY_CHANNEL)
                    .setMethodCallHandler(null)
            } catch (_: Throwable) {
                // El engine ya no acepta operaciones; la referencia débil se libera abajo.
            }
            overlayEngineRef = null
            overlayInstalled = false
            return false
        }

        // Si cambió el motor, retirar el handler del motor anterior cuando aún existe.
        if (previousEngine != null && previousEngine !== engine) {
            try {
                MethodChannel(previousEngine.dartExecutor.binaryMessenger, OVERLAY_CHANNEL)
                    .setMethodCallHandler(null)
            } catch (_: Throwable) {
                // El engine anterior pudo haber sido destruido antes del reemplazo.
            }
        }

        val channel = MethodChannel(engine.dartExecutor.binaryMessenger, OVERLAY_CHANNEL)
        channel.setMethodCallHandler { call, result ->
            // MethodChannel normalmente entrega en main, pero el contrato del puente
            // fuerza todas las operaciones y respuestas a Looper.getMainLooper().
            mainHandler.post { handleOverlayCall(call, result) }
        }

        overlayEngineRef = WeakReference(engine)
        overlayInstalled = true
        return true
    }

    private fun handleOverlayCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "capture" -> capture(result)
            "summary", "calculate", "saveTrip", "toggleHome" -> forwardToMain(call, result)
            else -> result.notImplemented()
        }
    }

    private fun capture(result: MethodChannel.Result) {
        val captureService = CaptureService.instance
        if (captureService?.active != true) {
            // Mantener el estado visible si una llamada llegó mientras el servicio
            // estaba siendo detenido; no hay respuesta antes de este intento.
            restoreOverlayVisibility()
            result.error("CAPTURE_INACTIVE", "La captura de pantalla no está activa", null)
            return
        }

        val request = CaptureRequest(result)
        mainHandler.postDelayed(request.watchdog, CAPTURE_WATCHDOG_MS)

        // Ocultar el overlay evita que su propia ventana entre en el cuadro capturado.
        // El resultado booleano no bloquea la captura: la restauración siempre se intenta.
        try {
            OverlayService.setOverlayVisible(false)
        } catch (_: Throwable) {
            // El servicio puede desaparecer entre la detección del motor y esta llamada.
        }

        mainHandler.postDelayed({
            if (request.isFinished()) return@postDelayed

            val path = try {
                captureService.captureToFile()
            } catch (_: Throwable) {
                null
            }
            if (path.isNullOrEmpty()) {
                request.error("NO_FRAME", "No hay un cuadro de pantalla disponible", null)
            } else {
                request.success(path)
            }
        }, CAPTURE_DELAY_MS)
    }

    private fun forwardToMain(call: MethodCall, overlayResult: MethodChannel.Result) {
        val channel = mainChannel
        if (channel == null) {
            overlayResult.error("MAIN_UNAVAILABLE", "El motor principal no está disponible", null)
            return
        }

        val completed = AtomicBoolean(false)
        val timeout = Runnable {
            if (completed.compareAndSet(false, true)) {
                overlayResult.error("MAIN_TIMEOUT", "El motor principal no respondió a tiempo", null)
            }
        }
        mainHandler.postDelayed(timeout, MAIN_TIMEOUT_MS)

        val callback = object : MethodChannel.Result {
            override fun success(value: Any?) {
                completeMainResult(completed, timeout) { overlayResult.success(value) }
            }

            override fun error(errorCode: String, errorMessage: String?, errorDetails: Any?) {
                completeMainResult(completed, timeout) {
                    overlayResult.error(errorCode, errorMessage, errorDetails)
                }
            }

            override fun notImplemented() {
                completeMainResult(completed, timeout) { overlayResult.notImplemented() }
            }
        }

        try {
            channel.invokeMethod(call.method, call.arguments, callback)
        } catch (_: Throwable) {
            completeMainResult(completed, timeout) {
                overlayResult.error("MAIN_UNAVAILABLE", "No se pudo invocar el motor principal", null)
            }
        }
    }

    private fun completeMainResult(
        completed: AtomicBoolean,
        timeout: Runnable,
        response: () -> Unit
    ) {
        mainHandler.post {
            if (completed.compareAndSet(false, true)) {
                mainHandler.removeCallbacks(timeout)
                response()
            }
        }
    }

    private fun restoreOverlayVisibility() {
        try {
            OverlayService.setOverlayVisible(true)
        } catch (_: Throwable) {
            // No ocultar una respuesta si el servicio overlay ya fue destruido.
        }
    }

    private class CaptureRequest(private val result: MethodChannel.Result) {
        private val completed = AtomicBoolean(false)

        val watchdog = Runnable {
            if (completed.compareAndSet(false, true)) {
                OverlayBridge.restoreOverlayVisibility()
                result.error("CAPTURE_TIMEOUT", "La captura no terminó a tiempo", null)
            }
        }

        fun isFinished(): Boolean = completed.get()

        fun success(path: String) {
            finish { result.success(path) }
        }

        fun error(code: String, message: String?, details: Any?) {
            finish { result.error(code, message, details) }
        }

        private fun finish(response: () -> Unit) {
            if (completed.compareAndSet(false, true)) {
                OverlayBridge.mainHandler.removeCallbacks(watchdog)
                // La visibilidad se restaura antes de cualquier respuesta Dart.
                OverlayBridge.restoreOverlayVisibility()
                response()
            }
        }
    }
}
