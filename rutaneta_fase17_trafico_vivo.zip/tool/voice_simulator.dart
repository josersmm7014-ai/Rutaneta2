import 'dart:io';

import '../lib/voice_command_router.dart';

/// Simulador local de la capa STT/TTS: el teclado sustituye al micrófono y
/// stdout sustituye a la voz. No captura audio ni llama a la app de viajes.
void main() {
  final timeout = const Duration(seconds: 30);
  var router = VoiceCommandRouter(confirmationTimeout: timeout);
  var now = DateTime(2026, 10, 31, 12, 0);
  const testOffer = VoiceOfferForSimulator();

  stdout.writeln('RutaNeta · simulador de comandos de voz (solo desarrollo)');
  stdout.writeln('No usa micrófono, OCR, red ni otras aplicaciones.');
  stdout.writeln('Escribe :ayuda para ver los comandos de prueba.');

  while (true) {
    stdout.write('\ntranscripción> ');
    final line = stdin.readLineSync();
    if (line == null) break;
    final input = line.trim();
    if (input.isEmpty) continue;

    if (input == ':salir') break;
    if (input == ':ayuda') {
      stdout.writeln('Comandos de entorno:');
      stdout.writeln('  :oferta              cargar oferta sintética 8.50 / 12 km / 28 min');
      stdout.writeln('  :ocr-incompleto      simular OCR sin todos los campos');
      stdout.writeln('  :avanzar-tiempo N    adelantar N segundos para probar expiración');
      stdout.writeln('  :reiniciar           borrar estado pendiente');
      stdout.writeln('  :salir               cerrar el simulador');
      stdout.writeln('Transcripciones: resumen de hoy, calcular, cancelar, repetir, detener voz.');
      stdout.writeln('Prueba de seguridad: «acepta el viaje» y «abre inDrive» deben ignorarse.');
      continue;
    }
    if (input == ':reiniciar') {
      router = VoiceCommandRouter(confirmationTimeout: timeout);
      now = DateTime(2026, 10, 31, 12, 0);
      stdout.writeln('Estado reiniciado. Oferta pendiente: ninguna.');
      continue;
    }
    if (input == ':oferta') {
      final reply = router.offerDetected(testOffer.toOffer(), now: now);
      _printReply(reply);
      continue;
    }
    if (input == ':ocr-incompleto') {
      stdout.writeln('OCR simulado: faltan minutos; no se crea una oferta pendiente.');
      continue;
    }
    if (input.startsWith(':avanzar-tiempo')) {
      final parts = input.split(RegExp(r'\s+'));
      final seconds = parts.length == 2 ? int.tryParse(parts[1]) : null;
      if (seconds == null || seconds < 0) {
        stdout.writeln('Uso: :avanzar-tiempo 31');
      } else {
        now = now.add(Duration(seconds: seconds));
        stdout.writeln('Reloj simulado: $now');
      }
      continue;
    }

    final reply = router.handle(input, now: now);
    _printReply(reply);
    if (reply.intent == VoiceIntent.dailySummary) {
      stdout.writeln(
        'Datos ficticios del resumen: neto \$18.40; 3 viajes; \$6.13 por hora.',
      );
    }
    if (reply.shouldCalculate && reply.offer != null) {
      final o = reply.offer!;
      stdout.writeln(
        'ACCIÓN SIMULADA: calcular \$${o.price.toStringAsFixed(2)}, '
        '${o.km.toStringAsFixed(1)} km, ${o.minutes.toStringAsFixed(0)} min.',
      );
      stdout.writeln('No se invoca el cálculo real ni se cambia la cuota.');
    }
    if (reply.shouldStopListening) {
      stdout.writeln('Fin de simulación de escucha; puedes escribir otro caso.');
    }
  }

  stdout.writeln('\nSimulador cerrado.');
}

void _printReply(VoiceReply reply) {
  stdout.writeln('intent=${reply.intent.name}');
  stdout.writeln('asistente> ${reply.speech}');
}

class VoiceOfferForSimulator {
  const VoiceOfferForSimulator();
  VoiceOffer toOffer() => VoiceOffer(price: 8.50, km: 12, minutes: 28);
}
