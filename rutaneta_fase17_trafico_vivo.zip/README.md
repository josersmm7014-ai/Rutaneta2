# RutaNeta (antes RutaViva Driver, fase 7)

Calculadora de rentabilidad para conductores de inDrive/Uber/Yango.

La aplicación se muestra como **RutaNeta** en Android e incluye un icono ilustrado de automóvil, camino ascendente y acento dorado. El identificador Android existente se conserva para no cambiar el paquete de la app.

La versión **4.1.0+10** adapta Inicio a pantallas ultra panorámicas y agrega tema por luz ambiental. En Ajustes puedes elegir **Automático**, **Siempre oscuro** o **Siempre claro**. Automático usa el sensor del dispositivo Android: cambia a oscuro por debajo de 25 lux y a claro por encima de 60 lux, con histéresis para evitar parpadeos; si no hay sensor, inicia y permanece oscuro. El sensor se escucha solo con la app en primer plano y mide la luz donde está el dispositivo; no lee sensores internos del vehículo ni se integra con Android Auto. La interfaz conserva botones grandes y el modo **Alta visibilidad**. Prepara la app antes de salir y manipula el teléfono solo con el vehículo detenido.

Pruebas del filtro de luz: `flutter test test/ambient_theme_store_test.dart`.

## Cómo obtener la APK (sin instalar nada)

1. Crea un repositorio nuevo en GitHub.
2. Sube **todo el contenido de esta carpeta** (incluida la carpeta oculta `.github`).
3. Entra a la pestaña **Actions** → **Build APK** → se ejecuta solo (o pulsa *Run workflow*).
4. Al terminar (5–10 min), abre la ejecución y descarga el artefacto **rutaneta-apk**.
5. Descomprime e instala `app-release.apk` en tu Android (permite "instalar apps desconocidas").

## Qué incluye esta fase

- Onboarding: vehículo, meta diaria
- Calculadora con veredicto CONVIENE / DUDOSO / NO CONVIENE
- Registro de viajes ("Acepté este viaje") y cierre con gasto real
- Dashboard diario y de 7 días con insights básicos
- Pasajeros y zonas marcados (solo en el teléfono) con aviso en la calculadora
- Alertas locales de 2 horas con votación
- Plan gratis (10 cálculos/día) y Premium en modo prueba
- Mapa de calor de ejemplo (datos simulados)

## Novedades de la fase 2

- **Leer captura de inDrive**: eliges la captura de la galería y la app lee precio, km y minutos (ML Kit, funciona sin internet). Siempre revisa los valores: si la captura muestra recogida y viaje, toma el km y los minutos mayores.
- **Distancia automática**: escribe origen y destino (colonia y municipio) y la app calcula km y tiempo por carretera con OpenStreetMap/OSRM (gratis, sin clave). El tiempo se multiplica por el factor de tráfico de Ajustes (por defecto ×1.3).
- **Modo flotante**: interruptor en Inicio. Pide el permiso "Mostrar sobre otras apps" y muestra una burbuja arrastrable con neto de hoy, \$/hora, km con pasajero / vacíos y el botón **Hacia casa**.
- **Hacia casa**: guarda tu casa en Ajustes. Con el botón activo, cada cálculo te dice si el destino queda a 5 km o menos de tu casa (en línea recta). Hace falta usar "Distancia automática" para conocer el destino.

## Novedades de la fase 3

- **Mapa** (pestaña nueva): OpenStreetMap con zonas de ejemplo coloreadas por \$/km, tu casa y el botón "Mi ubicación" (GPS).
- **Ruta en el mapa**: al usar "Distancia automática" se dibuja la ruta en la calculadora y en el resultado.
- **Usar mi ubicación como origen**: icono de GPS en el campo Origen.
- **Diseño más dinámico**: animaciones de entrada, contador de ganancia, anillo de meta diaria, botón que respira, veredicto animado con barra de \$/hora.
- **Pasajeros y zonas** pasó a Ajustes.

## Novedades de la fase 4: botón CALCULAR

- Al activar el **Modo flotante**, Android pide permiso para capturar la pantalla (una vez por sesión).
- La burbuja tiene un botón **CALCULAR**: tócalo con un viaje de inDrive en pantalla y la app captura la pantalla, lee precio, km y minutos con OCR y muestra CONVIENE / DUDOSO / NO CONVIENE con \$/hora (asumiendo regreso vacío).
- El cálculo desde la burbuja comparte el límite diario de 10 cálculos del plan gratis. Solo consume un cálculo cuando se reconocen los tres datos requeridos y se calcula el resultado.
- Revisa siempre precio, km y minutos detectados: el OCR puede confundir números o no reconocer algunos formatos.
- No lee la app de inDrive por dentro: es como si tú tomaras una captura.
- La app RutaNeta debe quedar abierta en segundo plano (no la cierres deslizando desde recientes).

## Pendiente para las siguientes fases

- Mapa de calor real y alertas compartidas (Firebase)
- Pagos de Premium, exportar a Excel, anuncios

## Simulación de comandos de voz (desarrollo)

El asistente de voz todavía no está conectado al micrófono. Para probar únicamente el enrutamiento de transcripciones, ejecuta `flutter test test/voice_command_router_test.dart` y `dart run tool/voice_simulator.dart`. El simulador usa texto escrito y datos ficticios; no graba audio, no calcula viajes reales y no controla otras apps. Consulta `docs/voice_dev_test_scripts.md` para los guiones manuales y resultados esperados.

## Fórmula usada

- Km recorridos = distancia (×2 si cuentas regreso vacío)
- Combustible = km recorridos / km por galón × precio del galón
- Neto = precio − combustible − 15% comisión − \$0.03 × km recorridos
- \$/hora = neto / horas (el tiempo también se duplica con regreso vacío)
- CONVIENE si > \$4/h, NO CONVIENE si < \$2/h (o neto negativo), DUDOSO en medio
