# RutaNeta Fase 16: mapa, tráfico y tarifa objetivo

## Uso

Abre **Mapa** y pulsa **Mi ubicación**. Elige un destino buscándolo por dirección, manteniendo pulsado un punto del mapa o seleccionando un establecimiento. La app consulta la ruta de ida y la ruta inversa. Puedes abrir **Calcular esta ruta**, indicar la oferta y evaluar la tarifa.

En la burbuja, revisa el bloque **Tráfico por destino** y confirma que el destino elegido corresponde a la oferta que estás evaluando. Activarlo sustituye los kilómetros y minutos por los de esa ruta. Editar manualmente esos campos desactiva la aplicación automática del tráfico. No se deduce un destino ambiguo de la captura ni se aplica por defecto a otra oferta.

La burbuja acepta consultas recientes de hasta tres minutos. Para usar una consulta caducada hay que actualizar la ruta en el mapa. El botón **Actualizar ruta elegida** de la burbuja lee la selección que mantiene la app; la actualización de los datos del proveedor se hace en el mapa.

## Mapa y cobertura

El fondo utiliza estilos Mapbox Navigation con capa de tráfico y modo claro por defecto. Puede cambiarse a oscuro, desactivar la capa y ampliar o reducir el zoom. Los controles de establecimientos son colapsables. Se eliminan los círculos de rentabilidad de ejemplo para dejar visibles calles y tráfico.

La ruta seleccionada distingue congestión baja, moderada, alta y severa; los tramos desconocidos aparecen en gris. Una vía sin datos no se considera libre. Se muestran hora de consulta, cobertura y duración. La hora **Consultado** es la de la petición, no la de medición de cada sensor.

La app vuelve a consultar la ruta cada dos minutos mientras el mapa está visible y la aplicación está activa. La capa de velocidades y densidad de Mapbox se actualiza aproximadamente cada ocho minutos. No es una transmisión segundo a segundo. La cobertura puede ser parcial y variar según la carretera; las consultas consumen cuota del servicio Mapbox.

## Cómo cambia la tarifa

Se usan los minutos de Mapbox sin volver a multiplicarlos por el factor manual de tráfico. Si se incluye regreso vacío, su distancia y tiempo se calculan en sentido inverso: no se asume que ambos sentidos tienen la misma congestión. Si un tiempo no cuenta con cobertura de tráfico se identifica como estimación.

La tarifa recomendada cubre combustible configurado, desgaste de $0.03/km y comisión del 15%, más el objetivo neto por hora elegido. Se redondea hacia arriba al centavo. Si aumenta el tiempo total, puede subir la tarifa necesaria para alcanzar el objetivo y cambiar el semáforo de conveniencia. La comparación habitual utiliza `duration_typical` del proveedor: no significa tiempo con calles completamente vacías.

El combustible sigue estimándose por kilómetros y rendimiento del vehículo; no se agrega un consumo de ralentí desconocido. Recogida, esperas adicionales, peajes y otros costos no están incluidos salvo que se incorporen a los datos. La tarifa sugerida no garantiza aceptación de la oferta ni ganancia efectiva. El historial conserva el origen, destino y datos consultados cuando se calcula con una ruta.

## Fuentes

- Mapbox Directions API: https://docs.mapbox.com/api/navigation/directions/
- Mapbox Traffic v1: https://docs.mapbox.com/data/tilesets/reference/mapbox-traffic-v1/
