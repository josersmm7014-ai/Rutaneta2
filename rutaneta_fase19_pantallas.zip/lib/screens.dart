import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:latlong2/latlong.dart' show LatLng;
import 'ambient_theme.dart';
import 'capture.dart';
import 'fare_recommendation.dart';
import 'geo.dart';
import 'map_screen.dart';
import 'models.dart';
import 'ocr.dart';
import 'overlay.dart';
import 'store.dart';
import 'traffic_trip.dart';
import 'ui.dart';

// ---------------------------------------------------------------- helpers

String money(double v) => '\$${v.toStringAsFixed(2)}';

double? parseNum(String s) => double.tryParse(s.trim().replaceAll(',', '.'));

Color verdictColor(String v) {
  if (v == 'CONVIENE') return const Color(0xFF1B8E5A);
  if (v == 'DUDOSO') return const Color(0xFFE0A100);
  return const Color(0xFFC62828);
}

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
}

// ---------------------------------------------------------------- vehículo

class VehicleFields extends StatefulWidget {
  final Vehicle? initial;
  final bool withGoal;
  final String buttonLabel;
  final void Function(Vehicle) onSave;

  const VehicleFields({
    super.key,
    this.initial,
    this.withGoal = false,
    required this.buttonLabel,
    required this.onSave,
  });

  @override
  State<VehicleFields> createState() => _VehicleFieldsState();
}

class _VehicleFieldsState extends State<VehicleFields> {
  String engine = '1.6';
  String fuel = 'Regular';
  final kmCtrl = TextEditingController();
  final priceCtrl = TextEditingController();
  final goalCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    final v = widget.initial;
    if (v != null) {
      engine = v.engine;
      fuel = v.fuel;
      kmCtrl.text = v.kmPerGal.toString();
      priceCtrl.text = v.fuelPrice.toString();
      goalCtrl.text = v.dailyGoal.toString();
    } else {
      goalCtrl.text = '25';
    }
  }

  @override
  void dispose() {
    kmCtrl.dispose();
    priceCtrl.dispose();
    goalCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final km = parseNum(kmCtrl.text);
    final price = parseNum(priceCtrl.text);
    final goal = parseNum(goalCtrl.text) ?? 25;
    if (km == null || km <= 0 || price == null || price <= 0) {
      snack(context, 'Revisa el consumo y el precio del combustible');
      return;
    }
    widget.onSave(
      Vehicle(
        engine: engine,
        fuel: fuel,
        kmPerGal: km,
        fuelPrice: price,
        dailyGoal: goal,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        DropdownButtonFormField<String>(
          value: engine,
          decoration: const InputDecoration(labelText: 'Tipo de motor'),
          items: const [
            '1.2',
            '1.6',
            '2.0',
          ].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: (v) => setState(() => engine = v ?? engine),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: fuel,
          decoration: const InputDecoration(labelText: 'Combustible'),
          items: const [
            'Especial',
            'Regular',
            'Diesel',
          ].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          onChanged: (v) => setState(() => fuel = v ?? fuel),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: kmCtrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Consumo promedio (km por galón)',
            hintText: 'Ej: 35',
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: priceCtrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            labelText: 'Precio actual del galón (\$)',
            helperText: 'Puedes editarlo cuando cambie',
          ),
        ),
        if (widget.withGoal) ...[
          const SizedBox(height: 12),
          TextField(
            controller: goalCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Meta diaria (\$)'),
          ),
        ],
        const SizedBox(height: 20),
        FilledButton(onPressed: _save, child: Text(widget.buttonLabel)),
      ],
    );
  }
}

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  int step = 0;
  Vehicle? draft;
  final goalCtrl = TextEditingController(text: '25');

  @override
  void dispose() {
    goalCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Widget body;
    String title;
    if (step == 0) {
      title = '1. Configura tu carro';
      body = VehicleFields(
        buttonLabel: 'Siguiente',
        onSave: (v) => setState(() {
          draft = v;
          step = 1;
        }),
      );
    } else if (step == 1) {
      title = '2. Pon tu meta diaria';
      body = Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text('¿Cuánto quieres ganar neto por día?'),
          const SizedBox(height: 12),
          TextField(
            controller: goalCtrl,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'Meta diaria (\$)'),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () {
              final g = parseNum(goalCtrl.text);
              if (g == null || g <= 0) {
                snack(context, 'Escribe una meta válida');
                return;
              }
              draft!.dailyGoal = g;
              setState(() => step = 2);
            },
            child: const Text('Siguiente'),
          ),
        ],
      );
    } else {
      title = '3. Todo listo';
      body = Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text(
            'Ya puedes calcular si un viaje conviene. Escribe origen, destino, '
            'precio, distancia y tiempo estimado del pedido de inDrive.',
          ),
          const SizedBox(height: 12),
          const Text(
            'Puedes activar el modo flotante desde Inicio para leer una captura '
            'de pantalla con CALCULAR. Revisa siempre los datos detectados. '
            'El mapa de calor en vivo aún no está disponible.',
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () => store.setVehicle(draft!),
            child: const Text('Empezar'),
          ),
        ],
      );
    }
    return Scaffold(
      appBar: AppBar(title: const Text('RutaNeta')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: Image.asset(
                  'assets/icon/rutaneta.png',
                  width: 52,
                  height: 52,
                  cacheWidth: 160,
                ),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Text(
                  'No trabajes más, trabaja rentable.',
                  style: TextStyle(fontStyle: FontStyle.italic),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          _StepBar(step: step, total: 3),
          const SizedBox(height: 20),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 300),
            switchInCurve: Curves.easeOutCubic,
            switchOutCurve: Curves.easeIn,
            transitionBuilder: (child, animation) => FadeTransition(
              opacity: animation,
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0.06, 0),
                  end: Offset.zero,
                ).animate(animation),
                child: child,
              ),
            ),
            child: KeyedSubtree(
              key: ValueKey<int>(step),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(title, style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 16),
                  body,
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Progreso del onboarding: una barra por paso que se llena al avanzar.
class _StepBar extends StatelessWidget {
  final int step;
  final int total;

  const _StepBar({required this.step, required this.total});

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return Semantics(
      label: 'Paso ${step + 1} de $total',
      child: Row(
        children: [
          for (var i = 0; i < total; i++) ...[
            if (i > 0) const SizedBox(width: 6),
            Expanded(
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 350),
                curve: Curves.easeOutCubic,
                height: 6,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(3),
                  color: i <= step ? color : color.withValues(alpha: 0.2),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- shell

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  late final List<Widget> pages;

  @override
  void initState() {
    super.initState();
    // Keep each page identity stable. The old list was rebuilt by the store
    // listener, which could replace a live MapScreen/route subtree while a
    // dialog or animation was still detaching.
    pages = [
      _StorePage(builder: (_) => const HomeScreen()),
      _StorePage(builder: (_) => const MapScreen()),
      _StorePage(builder: (_) => const HistoryScreen()),
      _StorePage(builder: (_) => const AlertsScreen()),
      _StorePage(builder: (_) => const SettingsScreen()),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return Scaffold(
          body: AnimatedSwitcher(
            duration: const Duration(milliseconds: 240),
            switchInCurve: Curves.easeOutCubic,
            switchOutCurve: Curves.easeIn,
            layoutBuilder: (current, previous) => Stack(
              fit: StackFit.expand,
              children: [...previous, if (current != null) current],
            ),
            transitionBuilder: (child, animation) => FadeTransition(
              opacity: animation,
              child: SlideTransition(
                position: Tween<Offset>(
                  begin: const Offset(0, 0.025),
                  end: Offset.zero,
                ).animate(animation),
                child: child,
              ),
            ),
            child: KeyedSubtree(
              key: ValueKey<int>(index),
              child: pages[index],
            ),
          ),
          bottomNavigationBar: NavigationBar(
            height: store.highVisibility ? 112 : 96,
            labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
            selectedIndex: index,
            onDestinationSelected: (i) => setState(() => index = i),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.home, size: 28),
                label: 'Inicio',
              ),
              NavigationDestination(
                icon: Icon(Icons.map, size: 28),
                label: 'Mapa',
              ),
              NavigationDestination(
                icon: Icon(Icons.bar_chart, size: 28),
                label: 'Historial',
              ),
              NavigationDestination(
                icon: Icon(Icons.warning_amber, size: 28),
                label: 'Alertas',
              ),
              NavigationDestination(
                icon: Icon(Icons.settings, size: 28),
                label: 'Ajustes',
              ),
            ],
          ),
        );
      },
    );
  }
}

/// Rebuilds a page's contents from the Store without changing the page
/// element/controller identity held by [MainShell].
class _StorePage extends StatelessWidget {
  final WidgetBuilder builder;

  const _StorePage({required this.builder});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) => builder(context),
    );
  }
}

// ---------------------------------------------------------------- inicio

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // La entrada escalonada se reproduce solo la primera vez por sesión; al
  // volver de otra pestaña la pantalla aparece sin repetirla.
  static bool _introPlayed = false;
  late final bool _intro;

  @override
  void initState() {
    super.initState();
    _intro = !_introPlayed;
    _introPlayed = true;
  }

  String _greeting() {
    final hour = DateTime.now().hour;
    final part = hour < 12
        ? 'Buenos días'
        : hour < 19
        ? 'Buenas tardes'
        : 'Buenas noches';
    return '$part, conductor';
  }

  @override
  Widget build(BuildContext context) {
    final trips = store.todayTrips;
    final net = trips.fold<double>(0, (sum, trip) => sum + trip.net);
    final hours = trips.fold<double>(0, (sum, trip) => sum + trip.hours);
    final perHour = hours > 0 ? net / hours : 0.0;
    final goal = store.vehicle!.dailyGoal;
    final progress = goal > 0 ? (net / goal).clamp(0.0, 1.0).toDouble() : 0.0;
    final visible = store.highVisibility;
    final dark = store.darkTheme;
    final accent = visible ? const Color(0xFFFFD54F) : const Color(0xFF4ADE80);
    final screen = MediaQuery.sizeOf(context);
    final ultraWide =
        screen.width >= 850 && screen.width / screen.height >= 1.85;

    final header = Row(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Image.asset(
            'assets/icon/rutaneta.png',
            width: visible ? 52 : 46,
            height: visible ? 52 : 46,
            cacheWidth: 160,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                ultraWide ? 'RutaNeta · Panel del conductor' : 'RutaNeta',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w900,
                  fontSize: visible ? 30 : 28,
                ),
              ),
              if (!ultraWide)
                Text(
                  _greeting(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: visible ? 17 : 14,
                    color: dark ? Colors.white70 : const Color(0xFF53645A),
                  ),
                ),
            ],
          ),
        ),
        IconButton(
          tooltip: 'Alertas',
          onPressed: () => Navigator.of(
            context,
          ).push(MaterialPageRoute(builder: (_) => const AlertsScreen())),
          icon: const Icon(Icons.notifications_none_rounded),
        ),
        IconButton(
          tooltip: 'Mi perfil y ajustes',
          onPressed: () => Navigator.of(
            context,
          ).push(MaterialPageRoute(builder: (_) => SettingsScreen())),
          icon: const Icon(Icons.account_circle_outlined),
        ),
      ],
    );

    const onPanel = TextStyle(color: Colors.white, fontWeight: FontWeight.bold);
    final summaryPanel = Container(
      width: double.infinity,
      padding: EdgeInsets.all(ultraWide ? 28 : 22),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: visible
              ? [const Color(0xFF594600), const Color(0xFF171300)]
              : [const Color(0xFF0C9554), const Color(0xFF075335)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: accent, width: visible ? 3 : 2),
        boxShadow: [
          BoxShadow(
            color: accent.withValues(alpha: 0.22),
            blurRadius: 28,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: ultraWide
            ? MainAxisAlignment.center
            : MainAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'GANANCIA NETA HOY',
                      style: onPanel.copyWith(
                        fontSize: visible ? 22 : 20,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 8),
                    FittedBox(
                      fit: BoxFit.scaleDown,
                      alignment: Alignment.centerLeft,
                      child: AnimatedMoney(
                        value: net,
                        style: onPanel.copyWith(
                          fontSize: ultraWide
                              ? (visible ? 72 : 64)
                              : (visible ? 56 : 48),
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              GoalRing(
                progress: progress,
                size: ultraWide ? 116 : 92,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '${(progress * 100).round()}%',
                      style: onPanel.copyWith(
                        fontSize: ultraWide ? 26 : 21,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const Text(
                      'META',
                      style: TextStyle(color: Colors.white70, fontSize: 11),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Wrap(
            spacing: 24,
            runSpacing: 10,
            children: [
              AnimatedMoney(
                value: perHour,
                suffix: ' / HORA',
                style: onPanel.copyWith(fontSize: ultraWide ? 22 : 20),
              ),
              Text(
                '${trips.length} VIAJES',
                style: onPanel.copyWith(fontSize: ultraWide ? 22 : 20),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            progress >= 1
                ? '¡Meta cumplida! Lo que sumes ahora es extra.'
                : 'Meta diaria ${money(goal)} · faltan ${money(math.max(0.0, goal - net))}',
            style: onPanel.copyWith(fontSize: visible ? 18 : 16),
          ),
          const SizedBox(height: 14),
          if (trips.isEmpty)
            Text(
              'Aún no hay viajes hoy. Calcula el primero para empezar.',
              style: TextStyle(
                color: Colors.white70,
                fontSize: visible ? 17 : 15,
              ),
            )
          else
            HourBar(perHour: perHour),
        ],
      ),
    );

    final actionsPanel = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Center(
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 12),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(30),
              color: accent.withValues(alpha: dark ? 0.12 : 0.18),
              border: Border.all(color: accent.withValues(alpha: 0.6)),
            ),
            child: Text(
              store.premium
                  ? 'PREMIUM · CÁLCULOS ILIMITADOS'
                  : 'TE QUEDAN ${store.calcsLeft} CÁLCULOS HOY',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: visible ? 18 : 16,
                fontWeight: FontWeight.bold,
                color: visible
                    ? (dark ? const Color(0xFFFFE082) : const Color(0xFF705700))
                    : (dark ? Colors.white : const Color(0xFF17231B)),
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: ultraWide ? (visible ? 112 : 100) : (visible ? 112 : 96),
          child: FilledButton(
            style: FilledButton.styleFrom(
              textStyle: TextStyle(
                fontSize: visible ? 28 : 24,
                fontWeight: FontWeight.w900,
                letterSpacing: 0.4,
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(24),
              ),
            ),
            onPressed: () => Navigator.of(
              context,
            ).push(MaterialPageRoute(builder: (_) => const CalcScreen())),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.calculate, size: visible ? 42 : 36),
                const SizedBox(width: 12),
                const Flexible(
                  child: Text('CALCULAR VIAJE', textAlign: TextAlign.center),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 14),
        const _FloatingCard(),
        const SizedBox(height: 12),
        SizedBox(
          height: visible ? 84 : 76,
          child: OutlinedButton(
            style: OutlinedButton.styleFrom(
              textStyle: TextStyle(
                fontSize: visible ? 21 : 19,
                fontWeight: FontWeight.bold,
              ),
            ),
            onPressed: () {
              if (store.hasHome) {
                store.toggleHomeMode();
              } else {
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const HomeSetupScreen()),
                );
              }
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  store.homeMode ? Icons.home : Icons.home_outlined,
                  size: visible ? 34 : 30,
                ),
                const SizedBox(width: 10),
                Flexible(
                  child: Text(
                    store.hasHome
                        ? (store.homeMode
                              ? 'HACIA CASA ACTIVA'
                              : 'ACTIVAR HACIA CASA')
                        : 'CONFIGURAR CASA',
                    textAlign: TextAlign.center,
                  ),
                ),
              ],
            ),
          ),
        ),
        if (!ultraWide) ...[
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.pause_circle_outline, size: 30),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'Prepara tus opciones antes de salir. No manipules el teléfono mientras conduces.',
                      style: TextStyle(fontSize: visible ? 18 : 16),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ],
    );

    // Entrada orquestada: cabecera, resumen y acciones aparecen en cascada.
    final headerBlock = FadeSlideIn(index: 0, animate: _intro, child: header);
    final summaryBlock = FadeSlideIn(
      index: 1,
      animate: _intro,
      child: summaryPanel,
    );
    final actionsBlock = FadeSlideIn(
      index: 2,
      animate: _intro,
      child: actionsPanel,
    );

    return Scaffold(
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) {
            if (ultraWide && constraints.maxWidth >= 800) {
              return Padding(
                padding: const EdgeInsets.fromLTRB(24, 12, 24, 18),
                child: Column(
                  children: [
                    headerBlock,
                    const SizedBox(height: 16),
                    Expanded(
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Expanded(
                            flex: 6,
                            child: SingleChildScrollView(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.stretch,
                                children: [
                                  summaryBlock,
                                  const SizedBox(height: 12),
                                  const Card(
                                    child: Padding(
                                      padding: EdgeInsets.all(14),
                                      child: Row(
                                        children: [
                                          Icon(
                                            Icons.pause_circle_outline,
                                            size: 28,
                                          ),
                                          SizedBox(width: 10),
                                          Expanded(
                                            child: Text(
                                              'Prepara tus opciones antes de salir. No manipules el teléfono mientras conduces.',
                                              style: TextStyle(fontSize: 16),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(width: 20),
                          Expanded(
                            flex: 5,
                            child: SingleChildScrollView(
                              padding: const EdgeInsets.only(right: 4),
                              child: actionsBlock,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            }

            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
              children: [
                headerBlock,
                const SizedBox(height: 18),
                summaryBlock,
                actionsBlock,
              ],
            );
          },
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- calculadora

typedef CalcGeocoder = Future<GeoPoint?> Function(String query);
typedef CalcTrafficRouter =
    Future<TrafficRouteInfo?> Function(GeoPoint origin, GeoPoint destination);
typedef CalcRoadRouter =
    Future<RouteInfo?> Function(GeoPoint origin, GeoPoint destination);

TrafficRouteInfo _estimatedTrafficRoute(RouteInfo route) => TrafficRouteInfo(
  km: route.km,
  minutes: route.minutes * store.trafficFactor,
  points: route.points,
  congestion: List<String?>.filled(
    route.points.length > 1 ? route.points.length - 1 : 0,
    'unknown',
  ),
  typicalMinutes: route.minutes,
  checkedAt: DateTime.now(),
  source: 'OSRM estimation ×${store.trafficFactor}',
);

ActiveTrafficTrip? _activeTrafficTripFromStore() {
  try {
    final value = (store as dynamic).activeTrafficTrip;
    return value is ActiveTrafficTrip ? value : null;
  } catch (_) {
    return null;
  }
}

void _setActiveTrafficTripInStore(ActiveTrafficTrip plan) {
  try {
    (store as dynamic).setActiveTrafficTrip(plan);
  } catch (_) {
    // Store de versiones previas no tenía este puente; la pantalla conserva el plan.
  }
}

void _clearActiveTrafficTripInStore() {
  try {
    (store as dynamic).clearActiveTrafficTrip();
  } catch (_) {
    // Compatibilidad con Store legacy.
  }
}

class CalcScreen extends StatefulWidget {
  final ActiveTrafficTrip? initialTrafficTrip;
  final CalcGeocoder? geocodeFn;
  final CalcTrafficRouter? trafficRouteFn;
  final CalcRoadRouter? drivingRouteFn;

  const CalcScreen({
    super.key,
    this.initialTrafficTrip,
    this.geocodeFn,
    this.trafficRouteFn,
    this.drivingRouteFn,
  });

  @override
  State<CalcScreen> createState() => _CalcScreenState();
}

class _CalcScreenState extends State<CalcScreen> {
  final origin = TextEditingController();
  final dest = TextEditingController();
  final price = TextEditingController();
  final km = TextEditingController();
  final mins = TextEditingController();
  bool returnEmpty = true;
  bool busy = false;
  GeoPoint? originPoint;
  GeoPoint? destPoint;
  List<LatLng> routePts = [];
  ActiveTrafficTrip? trafficPlan;
  bool _originEdited = false;
  bool _destEdited = false;
  bool _kmEdited = false;
  bool _minsEdited = false;
  bool _hydrating = false;

  CalcGeocoder get _geocode => widget.geocodeFn ?? geocode;
  CalcTrafficRouter get _trafficRoute => widget.trafficRouteFn ?? trafficRoute;
  CalcRoadRouter get _drivingRoute =>
      widget.drivingRouteFn ?? (GeoPoint a, GeoPoint b) => drivingRoute(a, b);

  @override
  void initState() {
    super.initState();
    trafficPlan = widget.initialTrafficTrip ?? _activeTrafficTripFromStore();
    final plan = trafficPlan;
    if (plan != null) {
      _hydrating = true;
      originPoint = plan.origin;
      destPoint = plan.destination;
      routePts = plan.outbound.points;
      origin.text = plan.originLabel;
      dest.text = plan.destinationLabel;
      km.text = _numberText(plan.outbound.km);
      mins.text = _numberText(plan.outbound.minutes);
      _hydrating = false;
    }
  }

  String _numberText(double value) => value.toString();

  void _invalidatePlan({bool clearPoints = false}) {
    trafficPlan = null;
    _clearActiveTrafficTripInStore();
    if (clearPoints) {
      originPoint = null;
      destPoint = null;
      routePts = [];
    }
  }

  Future<void> _readCapture() async {
    if (busy) return;
    final file = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (file == null) return;
    setState(() => busy = true);
    try {
      final r = await readScreenshot(file.path);
      if (!mounted) return;
      setState(() {
        if (r.price != null) price.text = r.price!.toString();
        if (r.km != null) {
          km.text = _numberText(r.km!);
          _kmEdited = true;
        }
        if (r.minutes != null) {
          mins.text = _numberText(r.minutes!);
          _minsEdited = true;
        }
        _invalidatePlan();
      });
      final found = <String>[
        if (r.price != null) 'precio',
        if (r.km != null) 'km',
        if (r.minutes != null) 'minutos',
      ];
      snack(
        context,
        found.isEmpty
            ? 'No pude leer datos de la captura. Escríbelos a mano'
            : 'Leí: ${found.join(', ')}. Revisa que estén bien',
      );
    } catch (_) {
      if (mounted) snack(context, 'No se pudo leer la captura');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _useMyLocation() async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final p = await currentLatLng();
      if (!mounted) return;
      if (p == null) {
        snack(
          context,
          'Activa la ubicación y da el permiso para usar tu posición',
        );
        return;
      }
      setState(() {
        _hydrating = true;
        originPoint = GeoPoint(p.latitude, p.longitude);
        origin.text = 'Mi ubicación';
        _hydrating = false;
        _originEdited = false;
        _invalidatePlan(clearPoints: false);
        routePts = [];
      });
    } catch (_) {
      if (mounted) snack(context, 'No pude obtener tu ubicación');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<TrafficRouteInfo?> _fallbackRoute(GeoPoint a, GeoPoint b) async {
    final legacy = await _drivingRoute(a, b);
    return legacy == null ? null : _estimatedTrafficRoute(legacy);
  }

  Future<ActiveTrafficTrip?> _queryTrafficPlan(
    GeoPoint a,
    GeoPoint b, {
    bool showMessages = true,
  }) async {
    TrafficRouteInfo? outbound;
    TrafficRouteInfo? back;
    try {
      final mapbox = await Future.wait<TrafficRouteInfo?>([
        _trafficRoute(a, b),
        _trafficRoute(b, a),
      ]);
      outbound = mapbox[0];
      back = mapbox[1];
    } catch (_) {
      outbound = null;
      back = null;
    }

    var usedFallback = false;
    var returnFallback = false;
    if (outbound == null || back == null) {
      final fallback = await Future.wait<TrafficRouteInfo?>([
        outbound == null ? _fallbackRoute(a, b) : Future.value(outbound),
        back == null ? _fallbackRoute(b, a) : Future.value(back),
      ]);
      if (outbound == null) {
        outbound = fallback[0];
        usedFallback = outbound != null;
      }
      if (back == null) {
        back = fallback[1];
        returnFallback = back != null;
      }
    }
    if (outbound == null) return null;

    final plan = ActiveTrafficTrip(
      origin: a,
      destination: b,
      originLabel: origin.text.trim(),
      destinationLabel: dest.text.trim(),
      outbound: outbound,
      returnRoute: back,
    );
    if (mounted) {
      setState(() {
        trafficPlan = plan;
        originPoint = a;
        destPoint = b;
        routePts = outbound!.points;
        if (!_kmEdited) km.text = _numberText(outbound.km);
        if (!_minsEdited) mins.text = _numberText(outbound.minutes);
      });
      _setActiveTrafficTripInStore(plan);
      if (showMessages) {
        final messages = <String>[];
        if (usedFallback)
          messages.add('Estimación OSRM ×${store.trafficFactor}');
        if (outbound.hasTrafficData && outbound.coverageRatio < 0.999) {
          messages.add('cobertura parcial de tráfico');
        } else if (!outbound.hasTrafficData) {
          messages.add('Mapbox sin datos de tráfico');
        }
        if (returnFallback) messages.add('vuelta estimada');
        snack(
          context,
          messages.isEmpty
              ? 'Ruta de ida y vuelta actualizada'
              : 'Ruta actualizada: ${messages.join(' · ')}',
        );
      }
    }
    return plan;
  }

  Future<void> _autoRoute() async {
    if (busy) return;
    if (origin.text.trim().isEmpty || dest.text.trim().isEmpty) {
      snack(context, 'Escribe origen y destino');
      return;
    }
    setState(() => busy = true);
    try {
      final a = originPoint ?? await _geocode(origin.text);
      final b = destPoint ?? await _geocode(dest.text);
      if (!mounted) return;
      if (a == null || b == null) {
        snack(
          context,
          'No encontré una de las direcciones. Prueba con colonia y municipio',
        );
        return;
      }
      final plan = await _queryTrafficPlan(a, b);
      if (!mounted) return;
      if (plan == null) snack(context, 'No pude calcular la ruta');
    } catch (_) {
      if (mounted)
        snack(context, 'Sin conexión o el servicio de mapas no responde');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<bool> _refreshStalePlan() async {
    final plan = trafficPlan;
    if (plan == null || plan.fresh || !_planMatchesFields()) return true;
    if (origin.text.trim().isEmpty || dest.text.trim().isEmpty) return true;
    final a = originPoint ?? await _geocode(origin.text);
    final b = destPoint ?? await _geocode(dest.text);
    if (a == null || b == null) return false;
    final refreshed = await _queryTrafficPlan(a, b, showMessages: false);
    return refreshed != null;
  }

  bool _planMatchesFields() =>
      !_originEdited &&
      !_destEdited &&
      !_kmEdited &&
      !_minsEdited &&
      trafficPlan != null &&
      origin.text.trim() == trafficPlan!.originLabel &&
      dest.text.trim() == trafficPlan!.destinationLabel;

  List<String> _trafficWarnings(ActiveTrafficTrip? plan) {
    if (plan == null) return const [];
    final out = <String>[];
    final route = plan.outbound;
    if (route.source.startsWith('OSRM')) {
      out.add(
        'Tiempo de ida estimado con OSRM ×${store.trafficFactor}; no es tráfico en vivo.',
      );
    } else if (!route.hasTrafficData) {
      out.add(
        'Mapbox devolvió ETA, pero no datos de tráfico: estado sin datos.',
      );
    } else if (route.coverageRatio < 0.999) {
      out.add(
        'Cobertura de tráfico parcial (${(route.coverageRatio * 100).round()}%); la tarifa no es garantía de ingreso.',
      );
    }
    if (plan.returnRoute == null) {
      out.add(
        'No se consultó la vuelta; se usa el doble legacy si se marca regreso vacío.',
      );
    } else if (plan.returnRoute!.source.startsWith('OSRM')) {
      out.add(
        'Vuelta estimada con OSRM; revisa el tiempo real antes de aceptar.',
      );
    }
    return out;
  }

  Future<void> _calculate() async {
    if (busy) return;
    final p = parseNum(price.text);
    final k = parseNum(km.text);
    final m = parseNum(mins.text);
    if (p == null || p <= 0 || k == null || k <= 0 || m == null || m <= 0) {
      snack(context, 'Escribe precio, distancia y tiempo');
      return;
    }
    if (!store.canCalc) {
      snack(context, 'Llegaste al límite de $freeCalcsPerDay cálculos de hoy');
      if (mounted) {
        await Navigator.of(
          context,
        ).push(MaterialPageRoute(builder: (_) => const PremiumScreen()));
      }
      return;
    }

    setState(() => busy = true);
    try {
      if (!await _refreshStalePlan()) {
        if (mounted)
          snack(
            context,
            'No pude actualizar el tráfico; revisa la ruta o calcula manualmente',
          );
        return;
      }
      if (!mounted) return;
      final plan = trafficPlan;
      final returnRoute = plan?.returnRoute;
      final v = store.vehicle!;
      final travel = k + (returnEmpty ? (returnRoute?.km ?? k) : 0);
      final trip = Trip(
        id: DateTime.now().microsecondsSinceEpoch.toString(),
        date: DateTime.now(),
        origin: origin.text.trim(),
        destination: dest.text.trim(),
        price: p,
        km: k,
        minutes: m,
        returnEmpty: returnEmpty,
        fuelCost: v.fuelCostFor(travel),
        returnKm: returnRoute?.km,
        returnMinutes: returnRoute?.minutes,
        typicalMinutes: plan?.outbound.typicalMinutes,
        returnTypicalMinutes: returnRoute?.typicalMinutes,
        trafficCheckedAt: plan?.outbound.checkedAt,
        trafficSource: plan?.outbound.source,
      );
      final warnings = [
        ...store.warningsFor('${origin.text} ${dest.text}'),
        ..._trafficWarnings(plan),
      ];
      String? homeNote;
      if (store.homeMode) {
        if (!store.hasHome) {
          homeNote =
              'Hacia casa está activo, pero no has guardado tu casa en Ajustes.';
        } else if (destPoint == null) {
          homeNote =
              'Hacia casa activo: usa "Distancia automática" para verificar el destino.';
        } else {
          final d = haversineKm(
            GeoPoint(store.homeLat!, store.homeLon!),
            destPoint!,
          );
          homeNote = d <= 5
              ? 'Hacia casa: el destino queda a ${d.toStringAsFixed(1)} km de tu casa (en línea recta). Dentro de tu zona.'
              : 'Fuera de Hacia casa: el destino queda a ${d.toStringAsFixed(1)} km de tu casa (máximo 5 km, en línea recta).';
        }
      }
      store.useCalc();
      if (!mounted) return;
      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ResultScreen(
            trip: trip,
            trafficTrip: plan,
            warnings: warnings,
            homeNote: homeNote,
            route: plan?.outbound.points ?? routePts,
            start: originPoint,
            end: destPoint,
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Widget _trafficStatusCard(BuildContext context) {
    final plan = trafficPlan!;
    final outbound = plan.outbound;
    final back = plan.returnRoute;
    String time(DateTime? value) {
      if (value == null) return '—';
      final local = value.toLocal();
      return '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
    }

    String eta(TrafficRouteInfo? route) => route == null
        ? 'No disponible'
        : '${route.km.toStringAsFixed(1)} km · ${route.minutes.toStringAsFixed(0)} min';
    final coverage = (outbound.coverageRatio * 100).round();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.traffic,
                  color: outbound.hasTrafficData ? Colors.green : Colors.amber,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Estado de tráfico · ${outbound.status}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text('Destino: ${plan.destinationLabel}'),
            Text('Ida: ${eta(outbound)}'),
            Text('Vuelta: ${eta(back)}'),
            Text(
              'Cobertura: ${outbound.hasTrafficData ? '$coverage%' : 'sin datos'}',
            ),
            Text(
              'Consultado: ${time(outbound.checkedAt)} · ${outbound.source}',
            ),
            if (outbound.typicalMinutes != null)
              Text(
                'Baseline habitual ida: ${outbound.typicalMinutes!.toStringAsFixed(0)} min',
              ),
            if (outbound.delayMinutes != null)
              Text(
                'Demora estimada ida: ${outbound.delayMinutes!.toStringAsFixed(0)} min',
              ),
            if (back?.typicalMinutes != null)
              Text(
                'Baseline habitual vuelta: ${back!.typicalMinutes!.toStringAsFixed(0)} min',
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    origin.dispose();
    dest.dispose();
    price.dispose();
    km.dispose();
    mins.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Calcular viaje')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          AnimatedSize(
            duration: const Duration(milliseconds: 200),
            curve: Curves.easeOut,
            child: busy
                ? const Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: LinearProgressIndicator(),
                  )
                : const SizedBox(width: double.infinity),
          ),
          OutlinedButton.icon(
            onPressed: busy ? null : _readCapture,
            icon: const Icon(Icons.image_search),
            label: const Text('Leer captura de inDrive'),
          ),
          const SizedBox(height: 16),
          _FormSection(
            title: 'Ruta',
            icon: Icons.alt_route,
            children: [
          TextField(
            controller: origin,
            onChanged: (_) {
              if (_hydrating) return;
              setState(() {
                _originEdited = true;
                _invalidatePlan(clearPoints: true);
              });
            },
            decoration: InputDecoration(
              labelText: 'Origen',
              suffixIcon: IconButton(
                tooltip: 'Usar mi ubicación',
                icon: const Icon(Icons.my_location),
                onPressed: busy ? null : _useMyLocation,
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: dest,
            onChanged: (_) {
              if (_hydrating) return;
              setState(() {
                _destEdited = true;
                _invalidatePlan(clearPoints: true);
              });
            },
            decoration: const InputDecoration(labelText: 'Destino'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: busy ? null : _autoRoute,
            icon: const Icon(Icons.route),
            label: const Text('Distancia automática'),
          ),
          if (trafficPlan != null) ...[
            const SizedBox(height: 12),
            _trafficStatusCard(context),
          ],
          if (routePts.isNotEmpty) ...[
            const SizedBox(height: 12),
            RouteMap(
              route: routePts,
              start: originPoint?.ll,
              end: destPoint?.ll,
              home: store.hasHome
                  ? LatLng(store.homeLat!, store.homeLon!)
                  : null,
            ),
          ],
            ],
          ),
          const SizedBox(height: 12),
          _FormSection(
            title: 'Oferta',
            icon: Icons.payments_outlined,
            children: [
          TextField(
            controller: price,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'Precio ofertado (\$)',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: km,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            onChanged: (_) {
              if (_hydrating) return;
              setState(() {
                _kmEdited = true;
                _invalidatePlan();
              });
            },
            decoration: const InputDecoration(
              labelText: 'Distancia del viaje (km)',
              helperText:
                  'Automática, de la captura o la que te muestra inDrive',
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: mins,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            onChanged: (_) {
              if (_hydrating) return;
              setState(() {
                _minsEdited = true;
                _invalidatePlan();
              });
            },
            decoration: const InputDecoration(
              labelText: 'Tiempo estimado con tráfico (min)',
            ),
          ),
          const SizedBox(height: 8),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('Posible regreso vacío'),
            subtitle: const Text(
              'Cuenta el trayecto de vuelta; si existe, usa su ruta real.',
            ),
            value: returnEmpty,
            onChanged: busy ? null : (v) => setState(() => returnEmpty = v),
          ),
            ],
          ),
          const SizedBox(height: 16),
          FilledButton(
            onPressed: busy ? null : _calculate,
            child: const Text('Calcular'),
          ),
        ],
      ),
    );
  }
}

/// Agrupa campos de un formulario en una tarjeta con título e icono.
class _FormSection extends StatelessWidget {
  final String title;
  final IconData icon;
  final List<Widget> children;

  const _FormSection({
    required this.title,
    required this.icon,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(icon, color: color),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),
            ...children,
          ],
        ),
      ),
    );
  }
}

class ResultScreen extends StatelessWidget {
  final Trip trip;
  final ActiveTrafficTrip? trafficTrip;
  final List<String> warnings;
  final String? homeNote;
  final List<LatLng> route;
  final GeoPoint? start;
  final GeoPoint? end;

  const ResultScreen({
    super.key,
    required this.trip,
    required this.warnings,
    this.trafficTrip,
    this.homeNote,
    this.route = const [],
    this.start,
    this.end,
  });

  Widget _row(String a, String b, {bool bold = false}) {
    final style = TextStyle(
      fontWeight: bold ? FontWeight.bold : FontWeight.normal,
    );
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(child: Text(a, style: style)),
          const SizedBox(width: 12),
          Flexible(
            child: Text(b, style: style, textAlign: TextAlign.right),
          ),
        ],
      ),
    );
  }

  Widget _heroChip(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(
      color: Colors.black26,
      borderRadius: BorderRadius.circular(20),
    ),
    child: Text(
      text,
      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
    ),
  );

  /// Barra que reparte el precio ofertado entre neto, combustible, comisión y
  /// desgaste, para ver de un vistazo a dónde se va el dinero.
  Widget _splitBar() {
    final parts = [
      ('Neto', trip.net > 0 ? trip.net : 0.0, const Color(0xFF1B8E5A)),
      ('Combustible', trip.fuelCost, const Color(0xFFE0A100)),
      ('Comisión', trip.commission, const Color(0xFF356AE6)),
      ('Desgaste', trip.wear, const Color(0xFF8A8F98)),
    ].where((p) => p.$2.isFinite && p.$2 > 0).toList();
    final total = parts.fold<double>(0, (sum, p) => sum + p.$2);
    if (total <= 0) return const SizedBox.shrink();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: SizedBox(
            height: 14,
            child: Row(
              children: [
                for (final p in parts)
                  Expanded(
                    flex: math.max(1, (p.$2 / total * 1000).round()),
                    child: ColoredBox(color: p.$3),
                  ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 14,
          runSpacing: 6,
          children: [
            for (final p in parts)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(color: p.$3, shape: BoxShape.circle),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    '${p.$1} ${(p.$2 / total * 100).round()}%',
                    style: const TextStyle(fontSize: 13),
                  ),
                ],
              ),
          ],
        ),
      ],
    );
  }

  Widget _recommendationCard(
    BuildContext context,
    FareRecommendation recommendation,
  ) {
    final signalColor = recommendation.signal == 'green'
        ? const Color(0xFF1B8E5A)
        : recommendation.signal == 'yellow'
        ? const Color(0xFFE0A100)
        : const Color(0xFFC62828);
    final signalIcon = recommendation.signal == 'green'
        ? Icons.check
        : recommendation.signal == 'yellow'
        ? Icons.priority_high
        : Icons.close;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: signalColor,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(signalIcon, color: Colors.white, size: 28),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'RECOMENDACIÓN DE TARIFA',
                        style: Theme.of(context).textTheme.titleMedium
                            ?.copyWith(fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        recommendation.verdict,
                        style: TextStyle(
                          color: signalColor,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            _row(
              'Mínimo para cubrir costos',
              money(recommendation.breakEvenFare),
            ),
            _row(
              'Sugerida para ${money(recommendation.targetNetPerHour)}/h',
              money(recommendation.recommendedFare),
              bold: true,
            ),
            const SizedBox(height: 4),
            Text(
              recommendation.requiredIncrease > 0
                  ? 'Si la oferta es menor, súbela al menos ${money(recommendation.requiredIncrease)}.'
                  : 'Tu oferta ya alcanza el objetivo',
              style: TextStyle(color: signalColor, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'Proyección con la tarifa sugerida: ${money(recommendation.projectedNet)} netos · ${money(recommendation.projectedPerHour)}/h',
            ),
          ],
        ),
      ),
    );
  }

  Widget _trafficResultCard(BuildContext context) {
    final plan = trafficTrip;
    final source = trip.trafficSource;
    if (plan == null && source == null) return const SizedBox.shrink();
    final outbound = plan?.outbound;
    final typical = trip.typicalTotalMinutes;
    final checked = trip.trafficCheckedAt?.toLocal();
    final checkedText = checked == null
        ? '—'
        : '${checked.hour.toString().padLeft(2, '0')}:${checked.minute.toString().padLeft(2, '0')}';
    final live =
        outbound?.hasTrafficData == true && !(source ?? '').startsWith('OSRM');
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  live ? Icons.traffic : Icons.info_outline,
                  color: live ? Colors.green : Colors.amber,
                ),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text(
                    'TRÁFICO Y TARIFA',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            _row(
              'Ida',
              '${trip.km.toStringAsFixed(1)} km · ${trip.minutes.toStringAsFixed(0)} min',
            ),
            if (trip.returnEmpty)
              _row(
                'Regreso',
                '${(trip.returnKm ?? trip.km).toStringAsFixed(1)} km · ${(trip.returnMinutes ?? trip.minutes).toStringAsFixed(0)} min',
              ),
            _row(
              'Total calculado',
              '${trip.travelKm.toStringAsFixed(1)} km · ${(trip.hours * 60).toStringAsFixed(0)} min',
            ),
            _row(
              'Resultado automático',
              '${money(trip.perHour)}/h · objetivo ${money(store.targetNetPerHour)}/h',
            ),
            if (typical != null)
              _row(
                'Baseline habitual',
                '${typical.toStringAsFixed(0)} min · demora ${trip.trafficDelayMinutes!.toStringAsFixed(0)} min',
              ),
            _row('Fuente / consulta', '${source ?? 'manual'} · $checkedText'),
            if (outbound != null)
              Text(
                'Cobertura ida: ${outbound.hasTrafficData ? '${(outbound.coverageRatio * 100).round()}%' : 'sin datos'}',
              ),
            const SizedBox(height: 8),
            const Text(
              'El tráfico y la tarifa son estimaciones; no garantizan ingresos.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final recommendation = recommendFare(
      trip,
      targetNetPerHour: store.targetNetPerHour,
    );
    final color = verdictColor(recommendation.verdict);
    return Scaffold(
      appBar: AppBar(title: const Text('Resultado')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0.85, end: 1),
            duration: const Duration(milliseconds: 600),
            curve: Curves.elasticOut,
            builder: (context, sc, child) =>
                Transform.scale(scale: sc, child: child),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [color, color.withAlpha(170)],
                ),
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(
                    color: color.withAlpha(110),
                    blurRadius: 24,
                    offset: const Offset(0, 10),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Icon(
                    recommendation.verdict == 'CONVIENE'
                        ? Icons.check_circle
                        : recommendation.verdict == 'DUDOSO'
                        ? Icons.help
                        : Icons.cancel,
                    color: Colors.white,
                    size: 48,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    recommendation.verdict,
                    style: const TextStyle(
                      fontSize: 34,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  AnimatedMoney(
                    value: trip.perHour,
                    suffix: ' por hora',
                    style: const TextStyle(fontSize: 22, color: Colors.white),
                  ),
                  Text(
                    'Ganancia neta ${money(trip.net)}',
                    style: const TextStyle(fontSize: 16, color: Colors.white),
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _heroChip('Oferta ${money(trip.price)}'),
                      _heroChip(
                        'Sugerida ${money(recommendation.recommendedFare)}',
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(8),
                    child: TweenAnimationBuilder<double>(
                      tween: Tween<double>(
                        begin: 0,
                        end: (trip.perHour / recommendation.targetNetPerHour)
                            .clamp(0.0, 1.0)
                            .toDouble(),
                      ),
                      duration: const Duration(milliseconds: 900),
                      curve: Curves.easeOutCubic,
                      builder: (context, v, _) => LinearProgressIndicator(
                        value: v,
                        minHeight: 10,
                        backgroundColor: Colors.white24,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Objetivo: ${money(recommendation.targetNetPerHour)} netos/h',
                    style: const TextStyle(color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
          if (warnings.isNotEmpty) ...[
            const SizedBox(height: 16),
            for (final w in warnings)
              Card(
                color: const Color(0xFF5D4037),
                child: ListTile(
                  leading: const Icon(Icons.warning_amber),
                  title: Text(w),
                ),
              ),
          ],
          if (homeNote != null)
            Card(
              child: ListTile(
                leading: const Icon(Icons.home),
                title: Text(homeNote!),
              ),
            ),
          const SizedBox(height: 16),
          FadeSlideIn(
            index: 1,
            child: _recommendationCard(context, recommendation),
          ),
          const SizedBox(height: 12),
          FadeSlideIn(index: 2, child: _trafficResultCard(context)),
          if (route.isNotEmpty) ...[
            const SizedBox(height: 16),
            RouteMap(
              route: route,
              start: start?.ll,
              end: end?.ll,
              home: store.hasHome
                  ? LatLng(store.homeLat!, store.homeLon!)
                  : null,
            ),
          ],
          const SizedBox(height: 16),
          FadeSlideIn(
            index: 3,
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Desglose del viaje',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _splitBar(),
                    const SizedBox(height: 12),
                    _row('Precio ofertado', money(trip.price)),
                    _row('Combustible', '- ${money(trip.fuelCost)}'),
                    _row(
                      'Comisión inDrive (15%)',
                      '- ${money(trip.commission)}',
                    ),
                    _row('Desgaste (\$0.03/km)', '- ${money(trip.wear)}'),
                    const Divider(),
                    _row('Ganancia neta', money(trip.net), bold: true),
                    _row(
                      'Km recorridos',
                      '${trip.travelKm.toStringAsFixed(1)} km',
                    ),
                    _row(
                      'Tiempo',
                      '${(trip.hours * 60).toStringAsFixed(0)} min',
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () {
              final messenger = ScaffoldMessenger.of(context);
              store.addTrip(trip);
              Navigator.of(context).popUntil((r) => r.isFirst);
              messenger.showSnackBar(
                const SnackBar(
                  content: Text('Viaje guardado. Ciérralo desde Historial'),
                ),
              );
            },
            child: const Text('Acepté este viaje'),
          ),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Volver'),
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- historial

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  int period = 0; // 0 hoy, 1 semana

  Future<void> _finish(Trip t) async {
    final fuelCtrl = TextEditingController(text: t.fuelCost.toStringAsFixed(2));
    bool empty = t.returnEmpty;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Finalizar viaje'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: fuelCtrl,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: '¿Cuánto gastaste real? (\$)',
                ),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('¿Regresaste vacío?'),
                value: empty,
                onChanged: (v) => setD(() => empty = v),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () {
                final f = parseNum(fuelCtrl.text);
                if (f == null || f < 0) return;
                store.finishTrip(t, f, empty);
                Navigator.pop(ctx);
              },
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
    fuelCtrl.dispose();
  }

  Future<void> _confirmDelete(Trip t) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('¿Borrar este viaje?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('No'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Borrar'),
          ),
        ],
      ),
    );
    if (ok == true) store.deleteTrip(t);
  }

  List<_ChartPoint> _chartPoints(List<Trip> trips, DateTime now) {
    if (period == 0) {
      final points = List.generate(
        24,
        (hour) => _ChartPoint(
          '${hour.toString().padLeft(2, '0')}:00',
          'De ${hour.toString().padLeft(2, '0')}:00 a ${(hour + 1).toString().padLeft(2, '0')}:00',
        ),
      );
      for (final t in trips) {
        final p = points[t.date.hour];
        p.gross += t.price;
        p.net += t.net;
        p.passengerKm += t.km;
        p.emptyKm += t.returnEmpty ? t.km : 0;
      }
      return points;
    }
    final start = DateTime(
      now.year,
      now.month,
      now.day,
    ).subtract(const Duration(days: 6));
    const weekdays = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
    final points = List.generate(7, (i) {
      final date = start.add(Duration(days: i));
      final weekday = weekdays[date.weekday - 1];
      final day = date.day.toString().padLeft(2, '0');
      final month = date.month.toString().padLeft(2, '0');
      return _ChartPoint(
        '$weekday ${date.day}',
        '$weekday $day/$month/${date.year}',
      );
    });
    for (final t in trips) {
      final index = DateTime(
        t.date.year,
        t.date.month,
        t.date.day,
      ).difference(start).inDays;
      if (index >= 0 && index < 7) {
        final p = points[index];
        p.gross += t.price;
        p.net += t.net;
        p.passengerKm += t.km;
        p.emptyKm += t.returnEmpty ? t.km : 0;
      }
    }
    return points;
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final startToday = DateTime(now.year, now.month, now.day);
    final from = period == 0
        ? startToday
        : startToday.subtract(const Duration(days: 6));
    final trips = store.tripsSince(from);

    final gross = trips.fold<double>(0, (s, t) => s + t.price);
    final net = trips.fold<double>(0, (s, t) => s + t.net);
    final hours = trips.fold<double>(0, (s, t) => s + t.hours);
    final km = trips.fold<double>(0, (s, t) => s + t.travelKm);
    final emptyKm = trips.fold<double>(
      0,
      (s, t) => s + (t.returnEmpty ? t.km : 0),
    );
    final perHour = hours > 0 ? net / hours : 0.0;
    final emptyPct = km > 0 ? emptyKm / km * 100 : 0.0;
    final lost = trips.fold<double>(0, (s, t) => s + (t.net < 0 ? -t.net : 0));
    final chartPoints = _chartPoints(trips, now);

    // Zona y hora más rentables
    final byZone = <String, List<double>>{};
    final byHour = <int, List<double>>{};
    for (final t in trips) {
      if (t.origin.isNotEmpty)
        byZone.putIfAbsent(t.origin, () => []).add(t.perHour);
      byHour.putIfAbsent(t.date.hour, () => []).add(t.perHour);
    }
    double avg(List<double> l) => l.fold<double>(0, (a, b) => a + b) / l.length;
    String? bestZone;
    double bestZoneVal = -1e9;
    byZone.forEach((k, v) {
      if (avg(v) > bestZoneVal) {
        bestZoneVal = avg(v);
        bestZone = k;
      }
    });
    int? bestHour;
    double bestHourVal = -1e9;
    byHour.forEach((k, v) {
      if (avg(v) > bestHourVal) {
        bestHourVal = avg(v);
        bestHour = k;
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('Historial')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 0, label: Text('Hoy')),
              ButtonSegment(value: 1, label: Text('7 días')),
            ],
            selected: {period},
            onSelectionChanged: (s) => setState(() => period = s.first),
          ),
          const SizedBox(height: 12),
          _historyHero(net, perHour, trips.length),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final tileWidth = (constraints.maxWidth - 10) / 2;
                  return Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      SizedBox(
                        width: tileWidth,
                        child: _metricTile(
                          context,
                          'Total bruto',
                          money(gross),
                        ),
                      ),
                      SizedBox(
                        width: tileWidth,
                        child: _metricTile(
                          context,
                          'Horas trabajadas',
                          hours.toStringAsFixed(1),
                        ),
                      ),
                      SizedBox(
                        width: tileWidth,
                        child: _metricTile(
                          context,
                          'Km totales',
                          km.toStringAsFixed(1),
                        ),
                      ),
                      SizedBox(
                        width: tileWidth,
                        child: _metricTile(
                          context,
                          'Km vacíos',
                          '${emptyPct.toStringAsFixed(0)}%',
                        ),
                      ),
                      SizedBox(
                        width: constraints.maxWidth,
                        child: _metricTile(
                          context,
                          'Perdido en viajes malos',
                          money(lost),
                        ),
                      ),
                      if (bestZone != null)
                        SizedBox(
                          width: tileWidth,
                          child: _metricTile(
                            context,
                            'Zona más rentable',
                            bestZone!,
                          ),
                        ),
                      if (bestHour != null)
                        SizedBox(
                          width: tileWidth,
                          child: _metricTile(
                            context,
                            'Hora más rentable',
                            '$bestHour:00',
                          ),
                        ),
                    ],
                  );
                },
              ),
            ),
          ),
          if (trips.isNotEmpty) ...[
            const SizedBox(height: 12),
            _AnalyticsCard(
              title: period == 0 ? 'Ganancias por hora' : 'Ganancias por día',
              subtitle: 'Elige bruto o neto y toca una barra',
              points: chartPoints,
              series: [
                _ChartSeries('Neto', (p) => p.net),
                _ChartSeries('Bruto', (p) => p.gross),
              ],
              valueLabel: (v) => money(v),
              color: const Color(0xFF1B8E5A),
            ),
            const SizedBox(height: 12),
            _AnalyticsCard(
              title: period == 0 ? 'Kilómetros por hora' : 'Kilómetros por día',
              subtitle: 'Cambia la vista y toca una barra para ver detalle',
              points: chartPoints,
              series: [
                _ChartSeries('Total', (p) => p.passengerKm + p.emptyKm),
                _ChartSeries('Pasajero', (p) => p.passengerKm),
                _ChartSeries('Vacíos', (p) => p.emptyKm),
              ],
              valueLabel: (v) => '${v.toStringAsFixed(1)} km',
              color: const Color(0xFF356AE6),
            ),
          ],
          if (emptyPct >= 40)
            const Card(
              child: ListTile(
                leading: Icon(Icons.lightbulb_outline),
                title: Text(
                  'Más del 40% de tus km van vacíos. Prefiere viajes que te dejen '
                  'cerca de zonas con demanda.',
                ),
              ),
            ),
          const SizedBox(height: 8),
          if (trips.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 44, horizontal: 18),
              child: Column(
                children: [
                  Icon(
                    Icons.assignment_outlined,
                    size: 76,
                    color: Theme.of(context).colorScheme.primary.withAlpha(170),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'Todavía no hay viajes en este periodo',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Cuando guardes viajes, aquí verás tus ganancias y kilómetros.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Theme.of(
                        context,
                      ).colorScheme.onSurface.withAlpha(170),
                    ),
                  ),
                ],
              ),
            ),
          for (final t in trips)
            FadeSlideIn(
              index: trips.indexOf(t).clamp(0, 5).toInt(),
              child: Card(
              child: ListTile(
                onTap: t.finished ? null : () => _finish(t),
                onLongPress: () => _confirmDelete(t),
                leading: CircleAvatar(
                  backgroundColor: verdictColor(t.verdict),
                  child: Icon(
                    t.finished ? Icons.check : Icons.hourglass_bottom,
                    color: Colors.white,
                  ),
                ),
                title: Text(
                  t.origin.isEmpty && t.destination.isEmpty
                      ? 'Viaje ${money(t.price)}'
                      : '${t.origin.isEmpty ? '?' : t.origin} → ${t.destination.isEmpty ? '?' : t.destination}',
                ),
                subtitle: Text(
                  'Neto ${money(t.net)} · ${money(t.perHour)}/h · ${t.km.toStringAsFixed(1)} km'
                  '${t.finished ? '' : '\nToca para finalizar'}',
                ),
                isThreeLine: !t.finished,
              ),
            ),
            ),
          const SizedBox(height: 8),
          const Text(
            'Mantén presionado un viaje para borrarlo.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _historyHero(double net, double perHour, int count) {
    final visible = store.highVisibility;
    final accent = visible ? const Color(0xFFFFD54F) : const Color(0xFF4ADE80);
    const onPanel = TextStyle(color: Colors.white, fontWeight: FontWeight.bold);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: visible
              ? [const Color(0xFF594600), const Color(0xFF171300)]
              : [const Color(0xFF0C9554), const Color(0xFF075335)],
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: accent, width: visible ? 3 : 2),
        boxShadow: [
          BoxShadow(
            color: accent.withValues(alpha: 0.22),
            blurRadius: 28,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            period == 0 ? 'NETO DE HOY' : 'NETO DE 7 DÍAS',
            style: onPanel.copyWith(fontSize: visible ? 20 : 18),
          ),
          const SizedBox(height: 8),
          FittedBox(
            fit: BoxFit.scaleDown,
            alignment: Alignment.centerLeft,
            child: AnimatedMoney(
              value: net,
              style: onPanel.copyWith(
                fontSize: visible ? 52 : 46,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 24,
            runSpacing: 8,
            children: [
              AnimatedMoney(
                value: perHour,
                suffix: ' / HORA',
                style: onPanel.copyWith(fontSize: 19),
              ),
              Text('$count VIAJES', style: onPanel.copyWith(fontSize: 19)),
            ],
          ),
          if (count > 0) ...[
            const SizedBox(height: 14),
            HourBar(perHour: perHour),
          ],
        ],
      ),
    );
  }

  Widget _metricTile(
    BuildContext context,
    String label,
    String value, {
    bool accent = false,
  }) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
    decoration: BoxDecoration(
      color: Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFF282935)
          : const Color(0xFFF0F4F1),
      borderRadius: BorderRadius.circular(16),
    ),
    child: Column(
      children: [
        Text(
          label,
          textAlign: TextAlign.center,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: Theme.of(context).colorScheme.onSurface.withAlpha(185),
          ),
        ),
        const SizedBox(height: 6),
        FittedBox(
          fit: BoxFit.scaleDown,
          child: Text(
            value,
            style: TextStyle(
              fontSize: 29,
              fontWeight: FontWeight.w900,
              color: accent
                  ? Theme.of(context).colorScheme.primary
                  : Theme.of(context).colorScheme.onSurface,
            ),
          ),
        ),
      ],
    ),
  );
}

class _ChartPoint {
  final String label;
  final String detail;
  double gross = 0;
  double net = 0;
  double passengerKm = 0;
  double emptyKm = 0;
  _ChartPoint(this.label, this.detail);
}

class _ChartSeries {
  final String label;
  final double Function(_ChartPoint) value;
  const _ChartSeries(this.label, this.value);
}

class _AnalyticsCard extends StatefulWidget {
  final String title;
  final String subtitle;
  final List<_ChartPoint> points;
  final List<_ChartSeries> series;
  final String Function(double) valueLabel;
  final Color color;

  const _AnalyticsCard({
    required this.title,
    required this.subtitle,
    required this.points,
    required this.series,
    required this.valueLabel,
    required this.color,
  });

  @override
  State<_AnalyticsCard> createState() => _AnalyticsCardState();
}

class _AnalyticsCardState extends State<_AnalyticsCard> {
  int? selected;
  int seriesIndex = 0;

  @override
  Widget build(BuildContext context) {
    final activeSeries = widget.series[seriesIndex];
    final point = selected == null || selected! >= widget.points.length
        ? null
        : widget.points[selected!];
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.title,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 2),
            Text(widget.subtitle, style: Theme.of(context).textTheme.bodySmall),
            const SizedBox(height: 4),
            Wrap(
              spacing: 6,
              children: [
                for (var i = 0; i < widget.series.length; i++)
                  ChoiceChip(
                    label: Text(widget.series[i].label),
                    selected: seriesIndex == i,
                    onSelected: (value) {
                      if (!value) return;
                      setState(() {
                        seriesIndex = i;
                        selected = null;
                      });
                    },
                  ),
              ],
            ),
            if (point != null)
              Text(
                '${point.detail} · ${activeSeries.label}: ${widget.valueLabel(activeSeries.value(point))}',
                style: TextStyle(
                  color: widget.color,
                  fontWeight: FontWeight.bold,
                ),
              ),
            SizedBox(
              height: 170,
              child: LayoutBuilder(
                builder: (context, constraints) => GestureDetector(
                  onTapDown: (details) {
                    final width = constraints.maxWidth;
                    final index =
                        ((details.localPosition.dx / width) *
                                widget.points.length)
                            .floor();
                    if (index >= 0 && index < widget.points.length)
                      setState(() => selected = index);
                  },
                  child: CustomPaint(
                    painter: _BarsPainter(
                      points: widget.points,
                      value: activeSeries.value,
                      color: widget.color,
                      selected: selected,
                    ),
                    child: const SizedBox.expand(),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _BarsPainter extends CustomPainter {
  final List<_ChartPoint> points;
  final double Function(_ChartPoint) value;
  final Color color;
  final int? selected;

  const _BarsPainter({
    required this.points,
    required this.value,
    required this.color,
    this.selected,
  });

  @override
  void paint(Canvas canvas, Size size) {
    const left = 8.0;
    const bottom = 24.0;
    final chartHeight = size.height - bottom - 8;
    final minValue = math
        .min(0.0, points.map(value).fold<double>(0, math.min))
        .toDouble();
    final maxValue = math
        .max(0.0, points.map(value).fold<double>(0, math.max))
        .toDouble();
    final span = math.max(1.0, maxValue - minValue).toDouble();
    final baseline = 8 + chartHeight * maxValue / span;
    final slot = (size.width - left * 2) / points.length;
    final barWidth = math.max(3.0, slot * 0.58);
    final grid = Paint()
      ..color = Colors.grey.withAlpha(55)
      ..strokeWidth = 1;
    for (var i = 0; i < 4; i++) {
      final y = 8 + chartHeight * i / 3;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final labelStyle = const TextStyle(fontSize: 10, color: Colors.grey);
    for (var i = 0; i < points.length; i++) {
      final v = value(points[i]);
      final h = v == 0 ? 2.0 : chartHeight * v.abs() / span;
      final x = left + i * slot + (slot - barWidth) / 2;
      final paint = Paint()
        ..color = i == selected ? color : color.withAlpha(150);
      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(x, v >= 0 ? baseline - h : baseline, barWidth, h),
          const Radius.circular(4),
        ),
        paint,
      );
      if (points.length <= 8 || i % 3 == 0) {
        final tp = TextPainter(
          text: TextSpan(text: points[i].label, style: labelStyle),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(
          canvas,
          Offset(x + (barWidth - tp.width) / 2, size.height - 19),
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _BarsPainter oldDelegate) =>
      oldDelegate.points != points ||
      oldDelegate.selected != selected ||
      oldDelegate.color != color;
}

// ---------------------------------------------------------------- alertas

class AlertsScreen extends StatelessWidget {
  const AlertsScreen({super.key});

  Future<void> _add(BuildContext context) async {
    String type = alertTypes.first;
    final zoneCtrl = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Nueva alerta'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: type,
                items: alertTypes
                    .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                    .toList(),
                onChanged: (v) => setD(() => type = v ?? type),
              ),
              TextField(
                controller: zoneCtrl,
                decoration: const InputDecoration(labelText: 'Zona o lugar'),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () {
                if (zoneCtrl.text.trim().isEmpty) return;
                store.addAlert(
                  AlertItem(
                    id: DateTime.now().microsecondsSinceEpoch.toString(),
                    type: type,
                    zone: zoneCtrl.text.trim(),
                    created: DateTime.now(),
                  ),
                );
                Navigator.pop(ctx);
              },
              child: const Text('Publicar'),
            ),
          ],
        ),
      ),
    );
    zoneCtrl.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final list = store.activeAlerts;
    return Scaffold(
      appBar: AppBar(title: const Text('Alertas')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _add(context),
        icon: const Icon(Icons.add_alert),
        label: const Text('Nueva'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Cada alerta dura 2 horas. En esta versión las alertas se guardan solo '
            'en tu teléfono; compartirlas entre conductores llegará con el servidor.',
            style: TextStyle(fontSize: 12),
          ),
          const SizedBox(height: 8),
          if (list.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 54),
              child: Column(
                children: [
                  Icon(
                    Icons.notifications_off_outlined,
                    size: 82,
                    color: Theme.of(context).colorScheme.primary.withAlpha(170),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'No hay alertas activas',
                    style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Cuando publiques una alerta aparecerá aquí.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Theme.of(
                        context,
                      ).colorScheme.onSurface.withAlpha(170),
                    ),
                  ),
                ],
              ),
            ),
          for (final a in list)
            Card(
              child: ListTile(
                title: Text(a.type),
                subtitle: Text(
                  '${a.zone} · hace ${DateTime.now().difference(a.created).inMinutes} min\n'
                  '${a.yes} siguen vigente · ${a.no} ya no',
                ),
                isThreeLine: true,
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.thumb_up_alt_outlined),
                      onPressed: () => store.voteAlert(a, true),
                    ),
                    IconButton(
                      icon: const Icon(Icons.thumb_down_alt_outlined),
                      onPressed: () => store.voteAlert(a, false),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- pasajeros y zonas

class PassengersScreen extends StatelessWidget {
  const PassengersScreen({super.key});

  Future<void> _add(BuildContext context) async {
    final nameCtrl = TextEditingController();
    String kind = 'zona';
    final tags = <String>{};
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: const Text('Marcar pasajero o zona'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SegmentedButton<String>(
                  segments: const [
                    ButtonSegment(value: 'zona', label: Text('Zona')),
                    ButtonSegment(value: 'persona', label: Text('Pasajero')),
                  ],
                  selected: {kind},
                  onSelectionChanged: (s) => setD(() => kind = s.first),
                ),
                TextField(
                  controller: nameCtrl,
                  decoration: InputDecoration(
                    labelText: kind == 'zona'
                        ? 'Nombre de la colonia'
                        : 'Nombre o teléfono',
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 6,
                  children: [
                    for (final t in passengerTags)
                      FilterChip(
                        label: Text(t),
                        selected: tags.contains(t),
                        onSelected: (v) => setD(() {
                          if (v) {
                            tags.add(t);
                          } else {
                            tags.remove(t);
                          }
                        }),
                      ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Cancelar'),
            ),
            FilledButton(
              onPressed: () {
                if (nameCtrl.text.trim().isEmpty || tags.isEmpty) return;
                store.addPassenger(
                  Passenger(
                    id: DateTime.now().microsecondsSinceEpoch.toString(),
                    name: nameCtrl.text.trim(),
                    kind: kind,
                    tags: tags.toList(),
                  ),
                );
                Navigator.pop(ctx);
              },
              child: const Text('Guardar'),
            ),
          ],
        ),
      ),
    );
    nameCtrl.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final list = store.passengers;
        return Scaffold(
          appBar: AppBar(title: const Text('Pasajeros y zonas')),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _add(context),
            icon: const Icon(Icons.add),
            label: const Text('Marcar'),
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const Text(
                'Privado: esta lista vive solo en tu teléfono, no se sube a ningún servidor. '
                'Si el origen o destino de un cálculo coincide con un nombre de aquí, te avisamos.',
                style: TextStyle(fontSize: 12),
              ),
              const SizedBox(height: 8),
              if (list.isEmpty)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: Text('Aún no has marcado a nadie')),
                ),
              for (final p in list)
                Card(
                  child: ListTile(
                    leading: Icon(
                      p.kind == 'zona' ? Icons.place : Icons.person,
                    ),
                    title: Text(p.name),
                    subtitle: Text(p.tags.join(' · ')),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => store.deletePassenger(p),
                    ),
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------- ajustes

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _editTraffic(BuildContext context) async {
    final ctrl = TextEditingController(text: store.trafficFactor.toString());
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Factor de tráfico'),
        content: TextField(
          controller: ctrl,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(
            helperText: 'Entre 1.0 y 3.0. Ej: 1.3 suma 30% al tiempo',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () {
              final v = parseNum(ctrl.text);
              if (v == null || v < 1 || v > 3) return;
              store.setTrafficFactor(v);
              Navigator.pop(ctx);
            },
            child: const Text('Guardar'),
          ),
        ],
      ),
    );
    ctrl.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final v = store.vehicle!;
    return Scaffold(
      appBar: AppBar(title: const Text('Ajustes')),
      body: ListView(
        children: [
          Card(
            child: SwitchListTile(
              secondary: const Icon(Icons.visibility),
              title: const Text('Alta visibilidad'),
              subtitle: const Text(
                'Más contraste, texto y botones grandes. Actívala antes de salir; '
                'usa o configura la app solo con el vehículo detenido.',
              ),
              value: store.highVisibility,
              onChanged: store.setHighVisibility,
            ),
          ),
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 12, 16, 4),
                    child: Text(
                      'Tema según la luz ambiental',
                      style: TextStyle(
                        fontSize: 19,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 0, 16, 8),
                    child: Text(
                      'Automático: oscuro bajo 25 lux y claro sobre 60 lux. Si el sensor no está disponible, se conserva el tema oscuro.',
                    ),
                  ),
                  RadioListTile<String>(
                    value: 'auto',
                    groupValue: store.appearanceMode,
                    onChanged: (value) {
                      if (value == null) return;
                      store.setAppearanceMode(value);
                      unawaited(ambientThemeController.refresh());
                    },
                    title: const Text('Automático'),
                    secondary: const Icon(Icons.sensors),
                  ),
                  RadioListTile<String>(
                    value: 'dark',
                    groupValue: store.appearanceMode,
                    onChanged: (value) {
                      if (value == null) return;
                      store.setAppearanceMode(value);
                      unawaited(ambientThemeController.refresh());
                    },
                    title: const Text('Siempre oscuro'),
                    secondary: const Icon(Icons.dark_mode_outlined),
                  ),
                  RadioListTile<String>(
                    value: 'light',
                    groupValue: store.appearanceMode,
                    onChanged: (value) {
                      if (value == null) return;
                      store.setAppearanceMode(value);
                      unawaited(ambientThemeController.refresh());
                    },
                    title: const Text('Siempre claro'),
                    secondary: const Icon(Icons.light_mode_outlined),
                  ),
                ],
              ),
            ),
          ),
          ListTile(
            leading: const Icon(Icons.directions_car),
            title: const Text('Mi vehículo'),
            subtitle: Text(
              'Motor ${v.engine} · ${v.fuel} · ${v.kmPerGal} km/gal · ${money(v.fuelPrice)}/gal',
            ),
            onTap: () => Navigator.of(
              context,
            ).push(MaterialPageRoute(builder: (_) => const VehicleScreen())),
          ),
          ListTile(
            leading: const Icon(Icons.traffic),
            title: const Text('Factor de tráfico'),
            subtitle: Text(
              '×${store.trafficFactor} sobre el tiempo de ruta (1.0 = sin tráfico)',
            ),
            onTap: () => _editTraffic(context),
          ),
          ListTile(
            leading: const Icon(Icons.home),
            title: const Text('Mi casa (para Hacia casa)'),
            subtitle: Text(store.hasHome ? store.homeAddress : 'Sin guardar'),
            onTap: () => Navigator.of(
              context,
            ).push(MaterialPageRoute(builder: (_) => const HomeSetupScreen())),
          ),
          ListTile(
            leading: const Icon(Icons.people),
            title: const Text('Pasajeros y zonas'),
            subtitle: Text(
              '${store.passengers.length} marcados, solo en tu teléfono',
            ),
            onTap: () => Navigator.of(
              context,
            ).push(MaterialPageRoute(builder: (_) => const PassengersScreen())),
          ),
          ListTile(
            leading: const Icon(Icons.workspace_premium),
            title: const Text('Premium'),
            subtitle: Text(
              store.premium ? 'Activo (modo prueba)' : 'Plan gratis',
            ),
            onTap: () => Navigator.of(
              context,
            ).push(MaterialPageRoute(builder: (_) => const PremiumScreen())),
          ),
          ListTile(
            leading: const Icon(Icons.delete_forever),
            title: const Text('Borrar todos mis datos'),
            onTap: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('¿Borrar todo?'),
                  content: const Text(
                    'Se borrarán vehículo, viajes, alertas y marcas.',
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(ctx, false),
                      child: const Text('Cancelar'),
                    ),
                    FilledButton(
                      onPressed: () => Navigator.pop(ctx, true),
                      child: const Text('Borrar'),
                    ),
                  ],
                ),
              );
              if (ok == true) await store.resetAll();
            },
          ),
        ],
      ),
    );
  }
}

class VehicleScreen extends StatelessWidget {
  const VehicleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mi vehículo')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          VehicleFields(
            initial: store.vehicle,
            withGoal: true,
            buttonLabel: 'Guardar',
            onSave: (v) {
              store.setVehicle(v);
              Navigator.of(context).pop();
            },
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- mapa de calor (ejemplo)

class HeatMapScreen extends StatelessWidget {
  const HeatMapScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Datos simulados de ejemplo (\$ por km).
    const zones = <String, double>{
      'San Salvador': 0.45,
      'Santa Tecla': 0.62,
      'Soyapango': 0.30,
      'Apopa': 0.22,
    };
    Color c(double v) {
      if (v >= 0.60) return const Color(0xFF0B5D36);
      if (v >= 0.40) return const Color(0xFF6BBF59);
      if (v >= 0.25) return const Color(0xFFE0A100);
      return const Color(0xFFC62828);
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Mapa de calor')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: ListTile(
              leading: Icon(Icons.info_outline),
              title: Text(
                'Datos simulados de ejemplo. El mapa real con precios por km y '
                'pedidos en vivo llegará en la siguiente fase.',
              ),
            ),
          ),
          const SizedBox(height: 8),
          for (final e in zones.entries)
            Card(
              child: ListTile(
                leading: CircleAvatar(backgroundColor: c(e.value)),
                title: Text(e.key),
                trailing: Text('${money(e.value)}/km'),
              ),
            ),
          const SizedBox(height: 12),
          const Text(
            'Verde oscuro: \$0.60+/km · Verde claro: \$0.40 · '
            'Amarillo: \$0.25 · Rojo: menos de \$0.25 o mucho tráfico',
          ),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------- premium

class PremiumScreen extends StatelessWidget {
  const PremiumScreen({super.key});

  Widget _item(String t, {bool ok = true}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      children: [
        Icon(ok ? Icons.check_circle : Icons.circle_outlined, size: 18),
        const SizedBox(width: 8),
        Expanded(child: Text(t)),
      ],
    ),
  );

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Premium')),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Text('Gratis', style: Theme.of(context).textTheme.titleLarge),
            _item('$freeCalcsPerDay cálculos por día'),
            _item('Historial, pasajeros y alertas locales'),
            const SizedBox(height: 20),
            Text(
              'Premium  ·  \$2.99/mes o \$19.99/año',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            _item('Cálculos ilimitados'),
            _item('Mapa en tiempo real (próximamente)'),
            _item('Predicción de demanda (próximamente)'),
            _item('Exportar reporte a Excel (próximamente)'),
            _item('Sin anuncios'),
            const SizedBox(height: 20),
            const Text(
              'Los pagos todavía no están conectados. Mientras tanto puedes probar '
              'Premium con este interruptor.',
              style: TextStyle(fontSize: 12),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Activar Premium (modo prueba)'),
              value: store.premium,
              onChanged: store.setPremium,
            ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- modo flotante

class _FloatingCard extends StatefulWidget {
  const _FloatingCard();

  @override
  State<_FloatingCard> createState() => _FloatingCardState();
}

class _FloatingCardState extends State<_FloatingCard> {
  bool active = false;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    OverlayCtrl.isActive().then((value) {
      if (mounted) setState(() => active = value);
    });
  }

  Future<void> _toggle(bool on) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      if (on) {
        final capOk = await Capture.start();
        final ok = await OverlayCtrl.start();
        if (!mounted) return;
        if (!ok) {
          await Capture.stop();
          snack(context, 'Necesito el permiso «Mostrar sobre otras apps».');
        } else if (!capOk) {
          snack(
            context,
            'Sin permiso de captura, CALCULAR no podrá leer la pantalla.',
          );
        }
        setState(() => active = ok);
      } else {
        await OverlayCtrl.stop();
        await Capture.stop();
        if (mounted) setState(() => active = false);
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = store.highVisibility;
    final height = visible ? 88.0 : 80.0;
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(Icons.bubble_chart, size: visible ? 32 : 28),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'MODO FLOTANTE',
                    style: TextStyle(
                      fontSize: visible ? 21 : 19,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: height,
              child: active
                  ? OutlinedButton(
                      onPressed: busy ? null : () => _toggle(false),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.stop_circle_outlined,
                            size: visible ? 34 : 30,
                          ),
                          const SizedBox(width: 10),
                          const Flexible(
                            child: Text(
                              'DETENER BURBUJA',
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                      style: OutlinedButton.styleFrom(
                        textStyle: TextStyle(
                          fontSize: visible ? 20 : 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    )
                  : FilledButton(
                      onPressed: busy ? null : () => _toggle(true),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.play_circle_outline,
                            size: visible ? 34 : 30,
                          ),
                          const SizedBox(width: 10),
                          const Flexible(
                            child: Text(
                              'ACTIVAR BURBUJA',
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                      style: FilledButton.styleFrom(
                        textStyle: TextStyle(
                          fontSize: visible ? 20 : 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
            ),
            const SizedBox(height: 8),
            Text(
              active
                  ? 'La burbuja CALCULAR está disponible sobre otras apps.'
                  : 'Muestra el botón CALCULAR sobre otras apps.',
              style: TextStyle(fontSize: visible ? 16 : 14),
              textAlign: TextAlign.center,
            ),
            if (busy) ...[
              const SizedBox(height: 8),
              const LinearProgressIndicator(minHeight: 6),
            ],
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------- mi casa

class HomeSetupScreen extends StatefulWidget {
  const HomeSetupScreen({super.key});

  @override
  State<HomeSetupScreen> createState() => _HomeSetupScreenState();
}

class _HomeSetupScreenState extends State<HomeSetupScreen> {
  final ctrl = TextEditingController(text: store.homeAddress);
  bool busy = false;

  @override
  void dispose() {
    ctrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (ctrl.text.trim().isEmpty) return;
    setState(() => busy = true);
    try {
      final p = await geocode(ctrl.text);
      if (!mounted) return;
      if (p == null) {
        snack(
          context,
          'No encontré esa dirección. Prueba con colonia y municipio',
        );
        return;
      }
      store.setHome(ctrl.text.trim(), p.lat, p.lon);
      Navigator.of(context).pop();
    } catch (_) {
      if (mounted)
        snack(context, 'Sin conexión o el servicio de mapas no responde');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mi casa')),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'Con "Hacia casa" activo te aviso si el destino de un viaje queda a más de 5 km de tu casa. '
            'La dirección se guarda solo en tu teléfono.',
          ),
          const SizedBox(height: 16),
          TextField(
            controller: ctrl,
            decoration: const InputDecoration(
              labelText: 'Colonia y municipio',
              hintText: 'Ej: Colonia Escalón, San Salvador',
            ),
          ),
          const SizedBox(height: 16),
          if (busy) const LinearProgressIndicator(),
          FilledButton(
            onPressed: busy ? null : _save,
            child: const Text('Guardar'),
          ),
        ],
      ),
    );
  }
}
