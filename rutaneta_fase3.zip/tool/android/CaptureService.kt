package com.rutaviva.rutaviva

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.io.FileOutputStream

class CaptureService : Service() {
    companion object {
        var instance: CaptureService? = null
        const val CHANNEL_ID = "rutaviva_capture"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
    }

    var active = false
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var held: Image? = null
    private var width = 0
    private var height = 0
    private val handler = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForegroundWithNotification()
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data != null && code != 0) {
            try {
                startProjection(code, data)
            } catch (e: Exception) {
                release()
            }
        }
        return START_NOT_STICKY
    }

    private fun startForegroundWithNotification() {
        val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val builder: Notification.Builder
        if (Build.VERSION.SDK_INT >= 26) {
            mgr.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Captura RutaNeta", NotificationManager.IMPORTANCE_LOW)
            )
            builder = Notification.Builder(this, CHANNEL_ID)
        } else {
            @Suppress("DEPRECATION")
            builder = Notification.Builder(this)
        }
        val n = builder
            .setContentTitle("RutaNeta")
            .setContentText("Listo para calcular viajes")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun startProjection(code: Int, data: Intent) {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val p = mpm.getMediaProjection(code, data)!!
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                release()
            }
        }, handler)
        projection = p

        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.maximumWindowMetrics.bounds
            width = b.width()
            height = b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            width = dm.widthPixels
            height = dm.heightPixels
        }
        val dpi = resources.configuration.densityDpi

        val r = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ rd ->
            val img = try {
                rd.acquireLatestImage()
            } catch (e: Exception) {
                null
            }
            if (img != null) {
                held?.close()
                held = img
            }
        }, handler)

        display = p.createVirtualDisplay(
            "rutaviva-capture", width, height, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler
        )
        instance = this
        active = true
    }

    /** Guarda el último cuadro de la pantalla como JPG y devuelve la ruta. */
    fun captureToFile(): String? {
        val img = held ?: return null
        return try {
            val plane = img.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * width
            val full = Bitmap.createBitmap(
                width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
            )
            buffer.rewind()
            full.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(full, 0, 0, width, height)
            val file = File(cacheDir, "capture.jpg")
            FileOutputStream(file).use { cropped.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            if (cropped !== full) full.recycle()
            cropped.recycle()
            file.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    private fun release() {
        active = false
        try { held?.close() } catch (e: Exception) {}
        held = null
        try { display?.release() } catch (e: Exception) {}
        display = null
        try { reader?.close() } catch (e: Exception) {}
        reader = null
        try { projection?.stop() } catch (e: Exception) {}
        projection = null
        instance = null
        stopSelf()
    }

    override fun onDestroy() {
        release()
        super.onDestroy()
    }
}
