import 'dart:convert';
import 'dart:math';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart' show Distance, LatLng, LengthUnit;

class GeoPoint {
  final double lat;
  final double lon;
  const GeoPoint(this.lat, this.lon);

  LatLng get ll => LatLng(lat, lon);
}

class RouteInfo {
  final double km;
  final double minutes; // sin tráfico
  final List<LatLng> points;
  const RouteInfo(this.km, this.minutes, this.points);
}

class NearbyPlace {
  final String name;
  final String category;
  final LatLng point;
  final double distanceKm;

  const NearbyPlace({
    required this.name,
    required this.category,
    required this.point,
    required this.distanceKm,
  });
}

class TrafficRouteInfo {
  final double km;
  final double minutes;
  final List<LatLng> points;
  final List<String?> congestion;

  const TrafficRouteInfo({
    required this.km,
    required this.minutes,
    required this.points,
    required this.congestion,
  });
}

const _mapboxPublicToken =
    'pk.eyJ1Ijoiam9zZXJzNzAiLCJhIjoiY212eDZiaTAxMDEzYzJ5b285YnU5NmpwNiJ9.4w4YP1VUXmVLqVgx-s4EVw';

String _placeCategory(Map<String, dynamic> tags) {
  final amenity = '${tags['amenity'] ?? ''}';
  final shop = '${tags['shop'] ?? ''}';
  final highway = '${tags['highway'] ?? ''}';
  if (amenity == 'fuel') return 'Gasolinera';
  if (amenity == 'restaurant' || amenity == 'fast_food' || amenity == 'cafe') {
    return 'Comida';
  }
  if (amenity == 'pharmacy') return 'Farmacia';
  if (shop.isNotEmpty) return 'Tienda';
  if (highway == 'traffic_signals') return 'Semáforo';
  return 'Lugar';
}

/// Obtiene locales y servicios desde OpenStreetMap/Overpass alrededor de un punto.
Future<List<NearbyPlace>> nearbyPlaces(
  LatLng center, {
  int radiusMeters = 5000,
}) async {
  final query =
      '''[out:json][timeout:15];
(
  nwr(around:$radiusMeters,${center.latitude},${center.longitude})[name];
);
out center tags;''';
  final res = await http
      .post(
        Uri.parse('https://overpass-api.de/api/interpreter'),
        body: {'data': query},
      )
      .timeout(const Duration(seconds: 20));
  if (res.statusCode != 200) return const [];
  final body = jsonDecode(res.body) as Map<String, dynamic>;
  final elements = body['elements'] as List? ?? const [];
  final distance = Distance();
  final places = <NearbyPlace>[];
  for (final raw in elements) {
    final e = raw as Map<String, dynamic>;
    final tags = (e['tags'] as Map?)?.cast<String, dynamic>() ?? const {};
    final lat =
        (e['lat'] as num?)?.toDouble() ??
        ((e['center'] as Map?)?['lat'] as num?)?.toDouble();
    final lon =
        (e['lon'] as num?)?.toDouble() ??
        ((e['center'] as Map?)?['lon'] as num?)?.toDouble();
    final name = '${tags['name'] ?? ''}'.trim();
    if (lat == null || lon == null || name.isEmpty) continue;
    final point = LatLng(lat, lon);
    places.add(
      NearbyPlace(
        name: name,
        category: _placeCategory(tags),
        point: point,
        distanceKm: distance.as(LengthUnit.Kilometer, center, point),
      ),
    );
  }
  places.sort((a, b) => a.distanceKm.compareTo(b.distanceKm));
  return places.take(100).toList();
}

/// Ruta con tráfico de Mapbox. La ruta requiere un token público de Mapbox.
Future<TrafficRouteInfo?> trafficRoute(GeoPoint a, GeoPoint b) async {
  final uri = Uri.parse(
    'https://api.mapbox.com/directions/v5/mapbox/driving-traffic/'
    '${a.lon},${a.lat};${b.lon},${b.lat}'
    '?alternatives=false&overview=full&geometries=geojson'
    '&annotations=congestion,duration&access_token=$_mapboxPublicToken',
  );
  final res = await http.get(uri).timeout(const Duration(seconds: 20));
  if (res.statusCode != 200) return null;
  final body = jsonDecode(res.body) as Map<String, dynamic>;
  final routes = body['routes'] as List?;
  if (routes == null || routes.isEmpty) return null;
  final route = routes.first as Map<String, dynamic>;
  final geometry = route['geometry'] as Map<String, dynamic>?;
  final coords = geometry?['coordinates'] as List? ?? const [];
  final points = [
    for (final c in coords)
      LatLng(((c as List)[1] as num).toDouble(), (c[0] as num).toDouble()),
  ];
  final legs = route['legs'] as List? ?? const [];
  final annotation = legs.isNotEmpty
      ? (legs.first as Map<String, dynamic>)['annotation'] as Map?
      : null;
  final congestion = [
    for (final c in (annotation?['congestion'] as List? ?? const []))
      c?.toString(),
  ];
  return TrafficRouteInfo(
    km: ((route['distance'] as num?)?.toDouble() ?? 0) / 1000,
    minutes: ((route['duration'] as num?)?.toDouble() ?? 0) / 60,
    points: points,
    congestion: congestion,
  );
}

/// Busca una dirección en El Salvador con Nominatim (OpenStreetMap).
Future<GeoPoint?> geocode(String query) async {
  final q = query.trim();
  if (q.isEmpty) return null;
  final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
    'q': '$q, El Salvador',
    'format': 'json',
    'limit': '1',
    'countrycodes': 'sv',
  });
  final res = await http
      .get(uri, headers: {'User-Agent': 'RutaNeta/1.0'})
      .timeout(const Duration(seconds: 12));
  if (res.statusCode != 200) return null;
  final list = jsonDecode(res.body) as List;
  if (list.isEmpty) return null;
  final m = list.first as Map<String, dynamic>;
  final lat = double.tryParse('${m['lat']}');
  final lon = double.tryParse('${m['lon']}');
  if (lat == null || lon == null) return null;
  return GeoPoint(lat, lon);
}

/// Distancia, tiempo y trazo de la ruta por carretera con OSRM (sin tráfico).
Future<RouteInfo?> drivingRoute(GeoPoint a, GeoPoint b) async {
  final uri = Uri.parse(
    'https://router.project-osrm.org/route/v1/driving/'
    '${a.lon},${a.lat};${b.lon},${b.lat}?overview=full&geometries=geojson',
  );
  final res = await http.get(uri).timeout(const Duration(seconds: 15));
  if (res.statusCode != 200) return null;
  final j = jsonDecode(res.body) as Map<String, dynamic>;
  final routes = j['routes'] as List?;
  if (routes == null || routes.isEmpty) return null;
  final r = routes.first as Map<String, dynamic>;
  final meters = (r['distance'] as num).toDouble();
  final seconds = (r['duration'] as num).toDouble();
  final points = <LatLng>[];
  final geometry = r['geometry'] as Map<String, dynamic>?;
  final coords = geometry?['coordinates'] as List?;
  if (coords != null) {
    for (final c in coords) {
      final pair = c as List;
      points.add(
        LatLng((pair[1] as num).toDouble(), (pair[0] as num).toDouble()),
      );
    }
  }
  return RouteInfo(meters / 1000, seconds / 60, points);
}

/// Posición actual del teléfono, o null si no hay permiso o GPS apagado.
Future<LatLng?> currentLatLng() async {
  if (!await Geolocator.isLocationServiceEnabled()) return null;
  var perm = await Geolocator.checkPermission();
  if (perm == LocationPermission.denied) {
    perm = await Geolocator.requestPermission();
  }
  if (perm == LocationPermission.denied ||
      perm == LocationPermission.deniedForever) {
    return null;
  }
  final pos = await Geolocator.getCurrentPosition();
  return LatLng(pos.latitude, pos.longitude);
}

double haversineKm(GeoPoint a, GeoPoint b) {
  const r = 6371.0;
  double rad(double d) => d * pi / 180;
  final dLat = rad(b.lat - a.lat);
  final dLon = rad(b.lon - a.lon);
  final h =
      pow(sin(dLat / 2), 2) +
      cos(rad(a.lat)) * cos(rad(b.lat)) * pow(sin(dLon / 2), 2);
  return 2 * r * asin(sqrt(h));
}
