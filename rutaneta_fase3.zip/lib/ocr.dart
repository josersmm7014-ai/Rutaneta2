import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

class OcrResult {
  final double? price;
  final double? km;
  final double? minutes;
  final String text;
  const OcrResult({this.price, this.km, this.minutes, required this.text});
}

double? _num(String s) => double.tryParse(s.replaceAll(',', '.'));

/// Lee una captura y trata de encontrar precio, km y minutos.
/// Si hay varios km o minutos (recogida y viaje), toma el mayor, que
/// normalmente es el del viaje. Siempre hay que revisar los valores.
Future<OcrResult> readScreenshot(String path) async {
  final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
  try {
    final input = InputImage.fromFilePath(path);
    final result = await recognizer.processImage(input);
    final text = result.text;

    double? price;
    // inDrive puede mostrar el importe como "$7" o como "7 $".
    final priceBeforeCurrency = RegExp(
      r'(?:\$|USD|MXN)\s*(\d+(?:[.,]\d{1,2})?)',
      caseSensitive: false,
    ).firstMatch(text);
    final priceAfterCurrency = RegExp(
      r'(\d+(?:[.,]\d{1,2})?)\s*(?:\$|USD|MXN)',
      caseSensitive: false,
    ).firstMatch(text);
    final priceMatch = priceBeforeCurrency ?? priceAfterCurrency;
    if (priceMatch != null) {
      // En ambos patrones el importe es el primer grupo capturado.
      price = _num(priceMatch.group(1)!);
    }

    double? km;
    for (final m in RegExp(
      r'(\d+(?:[.,]\d+)?)\s*(?:km|kms|kil[oó]metros?)',
      caseSensitive: false,
    ).allMatches(text)) {
      final v = _num(m.group(1)!);
      if (v != null && (km == null || v > km)) km = v;
    }

    double? minutes;
    for (final m in RegExp(
      r'(\d+(?:[.,]\d+)?)\s*(?:min|mins|minutos?)',
      caseSensitive: false,
    ).allMatches(text)) {
      final v = _num(m.group(1)!);
      if (v != null && (minutes == null || v > minutes)) minutes = v;
    }

    return OcrResult(price: price, km: km, minutes: minutes, text: text);
  } finally {
    await recognizer.close();
  }
}
