import 'dart:async';

import 'package:flutter/material.dart';
import 'ambient_theme.dart';
import 'overlay.dart';
import 'screens.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.load();
  OverlayCtrl.init();
  runApp(const RutaNetaApp());
  unawaited(ambientThemeController.initialize());
}

/// Punto de entrada de la burbuja flotante (lo llama el plugin de overlay).
@pragma('vm:entry-point')
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: OverlayBubble(),
  ));
}

class RutaNetaApp extends StatelessWidget {
  const RutaNetaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final visible = store.highVisibility;
        final dark = store.darkTheme;
        final onBackground = dark ? Colors.white : const Color(0xFF17231B);
        const green = Color(0xFF1B8E5A);
        const yellow = Color(0xFFFFD54F);
        final scheme = ColorScheme.fromSeed(
          seedColor: visible ? yellow : green,
          brightness: dark ? Brightness.dark : Brightness.light,
        ).copyWith(
          primary: visible ? yellow : green,
          onPrimary: Colors.black,
          secondary: visible ? yellow : green,
          onSecondary: Colors.black,
          surface: dark ? Colors.black : Colors.white,
          onSurface: onBackground,
        );

        return MaterialApp(
          title: 'RutaNeta',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            useMaterial3: true,
            colorScheme: scheme,
            scaffoldBackgroundColor: dark
                ? (visible ? Colors.black : const Color(0xFF0B1210))
                : const Color(0xFFF3F7F4),
            appBarTheme: AppBarTheme(
              backgroundColor: dark ? Colors.black : const Color(0xFFE7EFEA),
              foregroundColor: onBackground,
              toolbarHeight: visible ? 72 : 64,
            ),
            textTheme: (dark ? ThemeData.dark() : ThemeData.light()).textTheme.apply(
              fontSizeFactor: visible ? 1.14 : 1.0,
              bodyColor: onBackground,
              displayColor: onBackground,
            ),
            inputDecorationTheme: InputDecorationTheme(
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(
                  color: dark ? (visible ? Colors.white70 : Colors.white38) : Colors.black54,
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide(
                  color: visible ? (dark ? yellow : const Color(0xFF705700)) : green,
                  width: 2,
                ),
              ),
              contentPadding: EdgeInsets.symmetric(
                horizontal: 18,
                vertical: visible ? 22 : 18,
              ),
              labelStyle: TextStyle(
                fontSize: visible ? 19 : 16,
                color: dark ? Colors.white : const Color(0xFF26352B),
              ),
              helperStyle: TextStyle(
                fontSize: visible ? 15 : 12,
                color: dark ? Colors.white70 : const Color(0xFF53645A),
              ),
            ),
            filledButtonTheme: FilledButtonThemeData(
              style: FilledButton.styleFrom(
                minimumSize: Size(0, visible ? 84 : 72),
                backgroundColor:
                    visible ? yellow : const Color(0xFF4ADE80),
                foregroundColor: Colors.black,
                textStyle: TextStyle(
                  fontSize: visible ? 23 : 20,
                  fontWeight: FontWeight.bold,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                padding: EdgeInsets.symmetric(
                  vertical: visible ? 18 : 14,
                  horizontal: 20,
                ),
              ),
            ),
            outlinedButtonTheme: OutlinedButtonThemeData(
              style: OutlinedButton.styleFrom(
                minimumSize: Size(0, visible ? 76 : 68),
                foregroundColor: visible
                    ? (dark ? yellow : const Color(0xFF705700))
                    : (dark ? const Color(0xFFC9F7D8) : const Color(0xFF145D35)),
                side: BorderSide(
                  color: visible
                      ? (dark ? yellow : const Color(0xFF806500))
                      : (dark ? const Color(0xFF4ADE80) : const Color(0xFF1B8E5A)),
                  width: 2,
                ),
                textStyle: TextStyle(fontSize: visible ? 21 : 19),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
              ),
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                minimumSize: Size(0, visible ? 64 : 56),
                foregroundColor: visible
                    ? (dark ? yellow : const Color(0xFF705700))
                    : (dark ? const Color(0xFFC9F7D8) : const Color(0xFF145D35)),
                textStyle: TextStyle(fontSize: visible ? 19 : 17),
              ),
            ),
            iconButtonTheme: IconButtonThemeData(
              style: IconButton.styleFrom(
                minimumSize: Size.square(visible ? 64 : 56),
                iconSize: visible ? 32 : 28,
                foregroundColor: visible
                    ? (dark ? yellow : const Color(0xFF705700))
                    : (dark ? const Color(0xFFC9F7D8) : const Color(0xFF145D35)),
              ),
            ),
            listTileTheme: ListTileThemeData(
              minVerticalPadding: visible ? 16 : 12,
              contentPadding: const EdgeInsets.symmetric(horizontal: 18),
              iconColor: visible
                  ? (dark ? yellow : const Color(0xFF705700))
                  : (dark ? null : const Color(0xFF145D35)),
            ),
          ),
          home: AnimatedBuilder(
            animation: store,
            builder: (context, _) => store.vehicle == null
                ? const OnboardingScreen()
                : const MainShell(),
          ),
        );
      },
    );
  }
}
