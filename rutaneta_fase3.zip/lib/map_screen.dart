import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' show LatLng;
import 'geo.dart';
import 'store.dart';

class _Zone {
  final String name;
  final LatLng center;
  final double perKm;
  final double radius;
  const _Zone(this.name, this.center, this.perKm, this.radius);
}

const List<_Zone> _zones = [
  _Zone('San Salvador', LatLng(13.6929, -89.2182), 0.45, 4500),
  _Zone('Santa Tecla', LatLng(13.6769, -89.2797), 0.62, 3500),
  _Zone('Soyapango', LatLng(13.7102, -89.1394), 0.30, 3500),
  _Zone('Apopa', LatLng(13.8069, -89.1792), 0.22, 3500),
];

Color _zoneColor(double v) {
  if (v >= 0.60) return const Color(0xFF0B5D36);
  if (v >= 0.40) return const Color(0xFF6BBF59);
  if (v >= 0.25) return const Color(0xFFE0A100);
  return const Color(0xFFC62828);
}

IconData _placeIcon(String category) {
  switch (category) {
    case 'Gasolinera':
      return Icons.local_gas_station;
    case 'Comida':
      return Icons.restaurant;
    case 'Farmacia':
      return Icons.local_pharmacy;
    case 'Tienda':
      return Icons.storefront;
    case 'Semáforo':
      return Icons.traffic;
    default:
      return Icons.place;
  }
}

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});
  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  final MapController controller = MapController();
  LatLng? me;
  List<NearbyPlace> places = [];
  TrafficRouteInfo? traffic;
  String category = 'Todos';
  bool loading = false;
  bool placesLoading = false;
  bool trafficLoading = false;

  Future<void> _locate() async {
    setState(() => loading = true);
    try {
      final p = await currentLatLng();
      if (!mounted) return;
      if (p == null) {
        _message('Activa la ubicación y da el permiso');
        return;
      }
      setState(() => me = p);
      controller.move(p, 14);
      await _loadPlaces(p);
    } catch (_) {
      if (mounted) _message('No pude obtener tu ubicación');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _loadPlaces(LatLng point) async {
    setState(() => placesLoading = true);
    try {
      final result = await nearbyPlaces(point);
      if (mounted) setState(() => places = result);
    } catch (_) {
      if (mounted) _message('No se pudieron cargar los locales cercanos');
    } finally {
      if (mounted) setState(() => placesLoading = false);
    }
  }

  Future<void> _trafficToHome() async {
    if (me == null) {
      await _locate();
    }
    if (me == null || !store.hasHome) {
      _message('Activa Mi ubicación y guarda tu casa en Ajustes');
      return;
    }
    setState(() => trafficLoading = true);
    try {
      final result = await trafficRoute(
        GeoPoint(me!.latitude, me!.longitude),
        GeoPoint(store.homeLat!, store.homeLon!),
      );
      if (!mounted) return;
      if (result == null) {
        _message('Mapbox no pudo calcular el tráfico en este momento');
      } else {
        setState(() => traffic = result);
        if (result.points.isNotEmpty) {
          controller.fitCamera(
            CameraFit.coordinates(
              coordinates: result.points,
              padding: const EdgeInsets.all(70),
            ),
          );
        }
      }
    } catch (_) {
      if (mounted) _message('No se pudo consultar el tráfico');
    } finally {
      if (mounted) setState(() => trafficLoading = false);
    }
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final home = store.hasHome ? LatLng(store.homeLat!, store.homeLon!) : null;
    final visiblePlaces = category == 'Todos'
        ? places
        : places.where((p) => p.category == category).toList();
    final categories = <String>{
      'Todos',
      ...places.map((p) => p.category),
    }.toList();
    final trafficColor = traffic?.congestion.any((c) => c == 'severe') == true
        ? Colors.red
        : traffic?.congestion.any((c) => c == 'heavy') == true
        ? Colors.orange
        : Colors.green;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Mapa y tráfico'),
        actions: [
          IconButton(
            tooltip: 'Cargar locales',
            onPressed: me == null || placesLoading
                ? null
                : () => _loadPlaces(me!),
            icon: placesLoading
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: controller,
            options: const MapOptions(
              initialCenter: LatLng(13.72, -89.2),
              initialZoom: 11,
              interactionOptions: InteractionOptions(
                flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
              ),
            ),
            children: [
              TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.rutaviva.rutaviva',
              ),
              CircleLayer(
                circles: [
                  for (final z in _zones)
                    CircleMarker(
                      point: z.center,
                      radius: z.radius,
                      useRadiusInMeter: true,
                      color: _zoneColor(z.perKm).withAlpha(70),
                      borderColor: _zoneColor(z.perKm),
                      borderStrokeWidth: 2,
                    ),
                ],
              ),
              if (traffic != null && traffic!.points.length > 1)
                PolylineLayer(
                  polylines: [
                    Polyline(
                      points: traffic!.points,
                      strokeWidth: 7,
                      color: trafficColor,
                    ),
                  ],
                ),
              MarkerLayer(
                markers: [
                  for (final p in visiblePlaces)
                    Marker(
                      point: p.point,
                      width: 44,
                      height: 44,
                      child: GestureDetector(
                        onTap: () => _message(
                          '${p.name} · ${p.distanceKm.toStringAsFixed(1)} km',
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.indigo, width: 2),
                            boxShadow: const [
                              BoxShadow(blurRadius: 4, color: Colors.black38),
                            ],
                          ),
                          child: Icon(
                            _placeIcon(p.category),
                            color: Colors.indigo,
                            size: 24,
                          ),
                        ),
                      ),
                    ),
                  for (final z in _zones)
                    Marker(
                      point: z.center,
                      width: 110,
                      height: 44,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: Colors.black87,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '${z.name}\n\$${z.perKm.toStringAsFixed(2)}/km',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                          ),
                        ),
                      ),
                    ),
                  if (home != null)
                    Marker(
                      point: home,
                      width: 40,
                      height: 40,
                      child: const Icon(
                        Icons.home,
                        color: Colors.orange,
                        size: 34,
                      ),
                    ),
                  if (me != null)
                    Marker(
                      point: me!,
                      width: 40,
                      height: 40,
                      child: const Icon(
                        Icons.my_location,
                        color: Colors.blue,
                        size: 34,
                      ),
                    ),
                ],
              ),
            ],
          ),
          Positioned(
            top: 8,
            left: 8,
            right: 8,
            child: SafeArea(
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Locales y zonas rentables',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 6),
                      SizedBox(
                        height: 38,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: categories.length,
                          separatorBuilder: (_, __) => const SizedBox(width: 6),
                          itemBuilder: (_, i) => ChoiceChip(
                            label: Text(categories[i]),
                            selected: category == categories[i],
                            onSelected: (_) =>
                                setState(() => category = categories[i]),
                          ),
                        ),
                      ),
                      if (traffic != null) ...[
                        const SizedBox(height: 6),
                        Text(
                          'Tráfico a casa: ${traffic!.km.toStringAsFixed(1)} km · ${traffic!.minutes.toStringAsFixed(0)} min',
                          style: TextStyle(
                            color: trafficColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          FloatingActionButton.extended(
            heroTag: 'traffic',
            onPressed: trafficLoading ? null : _trafficToHome,
            icon: trafficLoading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.traffic),
            label: const Text('Tráfico a casa'),
          ),
          const SizedBox(height: 10),
          FloatingActionButton.extended(
            heroTag: 'location',
            onPressed: loading ? null : _locate,
            icon: loading
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.my_location),
            label: const Text('Mi ubicación'),
          ),
        ],
      ),
    );
  }
}
