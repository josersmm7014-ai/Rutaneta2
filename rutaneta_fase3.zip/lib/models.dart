class Vehicle {
  String engine;
  String fuel;
  double kmPerGal;
  double fuelPrice;
  double dailyGoal;

  Vehicle({
    required this.engine,
    required this.fuel,
    required this.kmPerGal,
    required this.fuelPrice,
    required this.dailyGoal,
  });

  Map<String, dynamic> toJson() => {
        'engine': engine,
        'fuel': fuel,
        'kmPerGal': kmPerGal,
        'fuelPrice': fuelPrice,
        'dailyGoal': dailyGoal,
      };

  factory Vehicle.fromJson(Map<String, dynamic> j) => Vehicle(
        engine: j['engine'] as String,
        fuel: j['fuel'] as String,
        kmPerGal: (j['kmPerGal'] as num).toDouble(),
        fuelPrice: (j['fuelPrice'] as num).toDouble(),
        dailyGoal: (j['dailyGoal'] as num).toDouble(),
      );

  double fuelCostFor(double travelKm) => travelKm / kmPerGal * fuelPrice;
}

String verdictFor(double perHour) {
  if (perHour > 4) return 'CONVIENE';
  if (perHour < 2) return 'NO CONVIENE';
  return 'DUDOSO';
}

class Trip {
  final String id;
  final DateTime date;
  final String origin;
  final String destination;
  final double price;
  final double km;
  final double minutes;
  bool returnEmpty;
  double fuelCost;
  bool finished;

  Trip({
    required this.id,
    required this.date,
    required this.origin,
    required this.destination,
    required this.price,
    required this.km,
    required this.minutes,
    required this.returnEmpty,
    required this.fuelCost,
    this.finished = false,
  });

  double get travelKm => returnEmpty ? km * 2 : km;
  double get commission => price * 0.15;
  double get wear => travelKm * 0.03;
  double get net => price - fuelCost - commission - wear;
  double get hours => (returnEmpty ? minutes * 2 : minutes) / 60;
  double get perHour => hours > 0 ? net / hours : 0;
  String get verdict => net < 0 ? 'NO CONVIENE' : verdictFor(perHour);

  Map<String, dynamic> toJson() => {
        'id': id,
        'date': date.toIso8601String(),
        'origin': origin,
        'destination': destination,
        'price': price,
        'km': km,
        'minutes': minutes,
        'returnEmpty': returnEmpty,
        'fuelCost': fuelCost,
        'finished': finished,
      };

  factory Trip.fromJson(Map<String, dynamic> j) => Trip(
        id: j['id'] as String,
        date: DateTime.parse(j['date'] as String),
        origin: j['origin'] as String,
        destination: j['destination'] as String,
        price: (j['price'] as num).toDouble(),
        km: (j['km'] as num).toDouble(),
        minutes: (j['minutes'] as num).toDouble(),
        returnEmpty: j['returnEmpty'] as bool,
        fuelCost: (j['fuelCost'] as num).toDouble(),
        finished: j['finished'] as bool? ?? false,
      );
}

const List<String> passengerTags = [
  'Buen pagador',
  'Tardón',
  'Peligroso',
  'No recomienda',
  'Dirección exacta mala',
];

class Passenger {
  final String id;
  String name;
  String kind; // 'persona' o 'zona'
  List<String> tags;

  Passenger({
    required this.id,
    required this.name,
    required this.kind,
    required this.tags,
  });

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'kind': kind, 'tags': tags};

  factory Passenger.fromJson(Map<String, dynamic> j) => Passenger(
        id: j['id'] as String,
        name: j['name'] as String,
        kind: j['kind'] as String,
        tags: (j['tags'] as List).cast<String>(),
      );
}

const List<String> alertTypes = [
  'Tráfico pesado',
  'Retén',
  'Accidente',
  'Gasolinera con oferta',
  'Evento masivo',
];

class AlertItem {
  final String id;
  final String type;
  final String zone;
  final DateTime created;
  int yes;
  int no;

  AlertItem({
    required this.id,
    required this.type,
    required this.zone,
    required this.created,
    this.yes = 1,
    this.no = 0,
  });

  bool get active =>
      DateTime.now().difference(created).inMinutes < 120 && !(no >= 3 && no > yes);

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type,
        'zone': zone,
        'created': created.toIso8601String(),
        'yes': yes,
        'no': no,
      };

  factory AlertItem.fromJson(Map<String, dynamic> j) => AlertItem(
        id: j['id'] as String,
        type: j['type'] as String,
        zone: j['zone'] as String,
        created: DateTime.parse(j['created'] as String),
        yes: j['yes'] as int,
        no: j['no'] as int,
      );
}
