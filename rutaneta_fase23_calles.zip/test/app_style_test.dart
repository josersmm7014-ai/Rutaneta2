import 'package:flutter_test/flutter_test.dart';
import 'package:rutaviva/app_style.dart';
import 'package:rutaviva/overlay_controller.dart';
import 'package:rutaviva/store.dart';

void main() {
  group('Temas de la app', () {
    test('hay cuatro temas con ids únicos y Neta es el primero', () {
      expect(appStyles.length, 4);
      expect(appStyles.map((s) => s.id).toSet().length, appStyles.length);
      expect(appStyles.first.id, 'neta');
    });

    test('un id desconocido usa el tema Neta', () {
      expect(styleById('no-existe').id, 'neta');
      expect(styleById('carretera').id, 'carretera');
    });

    test('cada tema tiene degradado de dos colores y formas válidas', () {
      for (final s in appStyles) {
        expect(s.panel.length, 2, reason: s.id);
        expect(s.radiusPanel, greaterThan(0), reason: s.id);
        expect(s.radiusButton, greaterThan(0), reason: s.id);
      }
    });

    test('Alta visibilidad fuerza el acento amarillo en todos los temas', () {
      for (final s in appStyles) {
        expect(s.accentFor(true).toARGB32(), 0xFFFFD54F, reason: s.id);
        expect(s.accentFor(false), s.glow, reason: s.id);
      }
    });

    test('el resumen de la burbuja incluye el tema elegido', () {
      final summary = OverlayCtrl.summary();
      expect(summary['styleId'], store.styleId);
      expect(summary['highVisibility'], store.highVisibility);
    });

    test('el tema por defecto del store es Neta', () {
      expect(Store().styleId, 'neta');
      expect(currentStyle().id, 'neta');
    });
  });
}
