import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'ambient_theme.dart';
import 'app_style.dart';
import 'overlay.dart';
import 'screens.dart';
import 'store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await store.load();
  OverlayCtrl.init();
  runApp(const RutaNetaApp());
  unawaited(ambientThemeController.initialize());
}

/// Punto de entrada de la burbuja flotante (lo llama el plugin de overlay).
@pragma('vm:entry-point')
void overlayMain() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    const MaterialApp(debugShowCheckedModeBanner: false, home: OverlayBubble()),
  );
}

class RutaNetaApp extends StatelessWidget {
  const RutaNetaApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Keep MaterialApp and its inherited widgets mounted while preferences
    // change. Replacing MaterialApp from a Store listener can deactivate an
    // InheritedElement before its dependents have detached (framework.dart
    // _dependents.isEmpty).
    return MaterialApp(
      title: 'RutaNeta',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true),
      builder: (context, child) => _StoreTheme(child: child!),
      home: const _SplashGate(),
    );
  }
}

/// Entrada de la app: logo, anillo de carga y lema, una sola vez por arranque.
/// Toda la secuencia la maneja un AnimationController; al terminar (o al tocar
/// la pantalla) hace un fundido hacia la app.
class _SplashGate extends StatefulWidget {
  const _SplashGate();

  @override
  State<_SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<_SplashGate>
    with SingleTickerProviderStateMixin {
  static bool _shown = false;
  late final AnimationController _c;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );
    if (_shown) {
      _done = true;
      return;
    }
    _shown = true;
    _c.addStatusListener((status) {
      if (status == AnimationStatus.completed && mounted) {
        setState(() => _done = true);
      }
    });
    _c.forward();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (MediaQuery.disableAnimationsOf(context)) _done = true;
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 420),
      switchInCurve: Curves.easeOut,
      switchOutCurve: Curves.easeIn,
      child: _done
          ? const _AppHome(key: ValueKey('app'))
          : GestureDetector(
              key: const ValueKey('splash'),
              behavior: HitTestBehavior.opaque,
              onTap: () => setState(() => _done = true),
              child: _Splash(animation: _c),
            ),
    );
  }
}

class _Splash extends StatelessWidget {
  final Animation<double> animation;

  const _Splash({required this.animation});

  double _t(double begin, double end, [Curve curve = Curves.easeOutCubic]) =>
      Interval(begin, end, curve: curve).transform(animation.value);

  @override
  Widget build(BuildContext context) {
    final green = currentStyle().primary;
    return Scaffold(
      backgroundColor: const Color(0xFF0B1210),
      body: AnimatedBuilder(
        animation: animation,
        builder: (context, _) {
          final logo = _t(0.0, 0.5, Curves.easeOutBack);
          final logoOpacity = _t(0.0, 0.3);
          final ring = _t(0.1, 0.8, Curves.easeInOut);
          final title = _t(0.4, 0.75);
          final tagline = _t(0.6, 0.95);
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 150,
                  height: 150,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      SizedBox(
                        width: 150,
                        height: 150,
                        child: CircularProgressIndicator(
                          value: ring,
                          strokeWidth: 4,
                          strokeCap: StrokeCap.round,
                          color: green,
                          backgroundColor: Colors.white10,
                        ),
                      ),
                      Opacity(
                        opacity: logoOpacity.clamp(0.0, 1.0),
                        child: Transform.scale(
                          scale: 0.78 + 0.22 * logo,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(28),
                            child: Image.asset(
                              'assets/icon/rutaneta.png',
                              width: 104,
                              height: 104,
                              cacheWidth: 256,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 28),
                Opacity(
                  opacity: title,
                  child: Transform.translate(
                    offset: Offset(0, (1 - title) * 14),
                    child: const Text(
                      'RutaNeta',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 34,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 0.6,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Opacity(
                  opacity: tagline,
                  child: const Text(
                    'No trabajes más, trabaja rentable.',
                    style: TextStyle(
                      color: Color(0xFFB7C7BD),
                      fontSize: 15,
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _StoreTheme extends StatelessWidget {
  final Widget child;

  const _StoreTheme({required this.child});

  @override
  Widget build(BuildContext context) => AnimatedTheme(
    data: _storeTheme(),
    duration: const Duration(milliseconds: 250),
    child: child,
  );
}

class _AppHome extends StatelessWidget {
  const _AppHome({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) =>
          store.vehicle == null ? const OnboardingScreen() : const MainShell(),
    );
  }
}

ThemeData _storeTheme() {
  final visible = store.highVisibility;
  final dark = store.darkTheme;
  final onBackground = dark ? Colors.white : const Color(0xFF17231B);
  final style = currentStyle();
  final green = dark ? style.primary : style.primaryLight;
  const yellow = Color(0xFFFFD54F);
  final navy = style.bgDark;
  final cardSurface = style.surfaceDark;
  final titleStyle = style.customTitle
      ? TextStyle(
          color: onBackground,
          fontSize: 22,
          fontWeight: style.titleWeight,
          letterSpacing: style.titleSpacing,
        )
      : null;
  InputBorder fieldBorder([BorderSide side = const BorderSide()]) =>
      style.underlineFields
      ? UnderlineInputBorder(borderSide: side)
      : OutlineInputBorder(
          borderRadius: BorderRadius.circular(style.radiusField),
          borderSide: side,
        );
  final navShape = switch (style.navIndicator) {
    NavIndicator.none => null,
    NavIndicator.box => RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(4),
    ),
    NavIndicator.pill => const StadiumBorder(),
    NavIndicator.outline => RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(14),
      side: BorderSide(color: green, width: 1.5),
    ),
  };
  final scheme =
      ColorScheme.fromSeed(
        seedColor: visible ? yellow : green,
        brightness: dark ? Brightness.dark : Brightness.light,
      ).copyWith(
        primary: visible ? yellow : green,
        onPrimary: Colors.black,
        secondary: visible ? yellow : green,
        onSecondary: Colors.black,
        surface: dark ? cardSurface : Colors.white,
        onSurface: onBackground,
      );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: dark
        ? (visible ? Colors.black : navy)
        : style.bgLight,
    appBarTheme: AppBarTheme(
      backgroundColor: dark ? navy : style.navLight,
      foregroundColor: onBackground,
      titleTextStyle: titleStyle,
      toolbarHeight: visible ? 72 : 64,
      centerTitle: true,
      elevation: 0,
      scrolledUnderElevation: 0,
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: dark ? Brightness.light : Brightness.dark,
        systemNavigationBarColor: dark ? navy : style.bgLight,
        systemNavigationBarIconBrightness: dark
            ? Brightness.light
            : Brightness.dark,
      ),
    ),
    cardTheme: CardThemeData(
      color: dark ? cardSurface : Colors.white,
      surfaceTintColor: Colors.transparent,
      shadowColor: style.bordered
          ? Colors.black26
          : style.glow.withValues(alpha: dark ? 0.35 : 0.30),
      elevation: style.bordered ? 0 : 6,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(style.radiusCard),
        side: style.bordered
            ? BorderSide(
                color: dark ? style.outlineDark : style.outlineLight,
                width: style.borderWidth,
              )
            : BorderSide.none,
      ),
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: dark ? style.navDark : style.navLight,
      surfaceTintColor: Colors.transparent,
      indicatorColor: style.navIndicator == NavIndicator.none
          ? Colors.transparent
          : green.withValues(alpha: dark ? 0.20 : 0.16),
      indicatorShape: navShape,
      labelBehavior: style.navLabelsAlways
          ? NavigationDestinationLabelBehavior.alwaysShow
          : NavigationDestinationLabelBehavior.onlyShowSelected,
      labelTextStyle: WidgetStateProperty.resolveWith<TextStyle?>(
        (states) => TextStyle(
          color: states.contains(WidgetState.selected)
              ? green
              : (dark ? const Color(0xFF9A9BA8) : const Color(0xFF66736B)),
          fontWeight: states.contains(WidgetState.selected)
              ? FontWeight.w800
              : FontWeight.w500,
          fontSize: 12,
        ),
      ),
      iconTheme: WidgetStateProperty.resolveWith<IconThemeData?>(
        (states) => IconThemeData(
          color: states.contains(WidgetState.selected)
              ? green
              : (dark ? const Color(0xFF9A9BA8) : const Color(0xFF66736B)),
          size: states.contains(WidgetState.selected) ? 30 : 27,
        ),
      ),
    ),
    textTheme: (dark ? ThemeData.dark() : ThemeData.light()).textTheme.apply(
      fontFamily: style.fontFamily,
      fontSizeFactor: visible ? 1.14 : 1.0,
      bodyColor: onBackground,
      displayColor: onBackground,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: dark,
      fillColor: dark ? const Color(0xFF262733) : Colors.white,
      border: fieldBorder(),
      enabledBorder: fieldBorder(
        BorderSide(
          color: dark
              ? (visible ? Colors.white70 : Colors.white38)
              : Colors.black54,
        ),
      ),
      focusedBorder: fieldBorder(
        BorderSide(
          color: visible ? (dark ? yellow : const Color(0xFF705700)) : green,
          width: 2,
        ),
      ),
      contentPadding: EdgeInsets.symmetric(
        horizontal: 18,
        vertical: visible ? 22 : 18,
      ),
      labelStyle: TextStyle(
        fontSize: visible ? 19 : 16,
        color: dark ? Colors.white : const Color(0xFF26352B),
      ),
      helperStyle: TextStyle(
        fontSize: visible ? 15 : 12,
        color: dark ? Colors.white70 : const Color(0xFF53645A),
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: Size(0, visible ? 84 : 72),
        backgroundColor: visible ? yellow : style.buttonColor,
        foregroundColor: Colors.black,
        textStyle: TextStyle(
          fontSize: visible ? 23 : 20,
          fontWeight: FontWeight.bold,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(style.radiusButton),
        ),
        padding: EdgeInsets.symmetric(
          vertical: visible ? 18 : 14,
          horizontal: 20,
        ),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: Size(0, visible ? 76 : 68),
        foregroundColor: visible
            ? (dark ? yellow : const Color(0xFF705700))
            : (dark ? style.tintDark : style.tintLight),
        side: BorderSide(
          color: visible
              ? (dark ? yellow : const Color(0xFF806500))
              : (dark ? style.buttonColor : style.strongLight),
          width: 2,
        ),
        textStyle: TextStyle(fontSize: visible ? 21 : 19),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(style.radiusButton),
        ),
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
      ),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        minimumSize: Size(0, visible ? 64 : 56),
        foregroundColor: visible
            ? (dark ? yellow : const Color(0xFF705700))
            : (dark ? style.tintDark : style.tintLight),
        textStyle: TextStyle(fontSize: visible ? 19 : 17),
      ),
    ),
    iconButtonTheme: IconButtonThemeData(
      style: IconButton.styleFrom(
        minimumSize: Size.square(visible ? 64 : 56),
        iconSize: visible ? 32 : 28,
        foregroundColor: visible
            ? (dark ? yellow : const Color(0xFF705700))
            : (dark ? style.tintDark : style.tintLight),
      ),
    ),
    listTileTheme: ListTileThemeData(
      minVerticalPadding: visible ? 16 : 12,
      contentPadding: const EdgeInsets.symmetric(horizontal: 18),
      iconColor: visible
          ? (dark ? yellow : const Color(0xFF705700))
          : (dark ? null : style.tintLight),
    ),
  );
}
