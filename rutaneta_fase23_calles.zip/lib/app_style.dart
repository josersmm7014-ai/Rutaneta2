import 'package:flutter/material.dart';

import 'store.dart';

/// Conjunto de iconos de un tema. Cada tema usa una familia distinta
/// (rellena, angular, redondeada o de línea) para cambiar el carácter de la app.
class AppIcons {
  final IconData home;
  final IconData map;
  final IconData history;
  final IconData alerts;
  final IconData settings;
  final IconData calculate;
  final IconData notifications;
  final IconData account;
  final IconData route;
  final IconData payments;
  final IconData good;
  final IconData doubtful;
  final IconData bad;
  final IconData homeOn;
  final IconData homeOff;

  const AppIcons({
    required this.home,
    required this.map,
    required this.history,
    required this.alerts,
    required this.settings,
    required this.calculate,
    required this.notifications,
    required this.account,
    required this.route,
    required this.payments,
    required this.good,
    required this.doubtful,
    required this.bad,
    required this.homeOn,
    required this.homeOff,
  });
}

/// Forma del indicador de la opción activa en la barra de navegación.
enum NavIndicator { none, box, pill, outline }

class AppStyle {
  final String id;
  final String name;
  final String tagline;

  // Colores
  final Color primary; // acento en modo oscuro
  final Color primaryLight; // acento en modo claro
  final Color buttonColor;
  final Color glow; // bordes y brillo de los paneles
  final List<Color> panel; // degradado del panel de resumen
  final Color tintDark; // texto/iconos de botones secundarios (oscuro)
  final Color tintLight; // idem (claro)
  final Color strongLight; // bordes de botones secundarios (claro)
  final Color bgDark;
  final Color surfaceDark;
  final Color navDark;
  final Color bgLight;
  final Color navLight;
  final Color outlineDark;
  final Color outlineLight;

  // Formas
  final double radiusPanel;
  final double radiusCard;
  final double radiusButton;
  final double radiusField;
  final bool bordered; // tarjetas con borde (true) o con sombra suave (false)
  final double borderWidth;
  final bool underlineFields; // campos con línea inferior en vez de recuadro

  // Navegación
  final NavIndicator navIndicator;
  final bool navLabelsAlways;

  // Tipografía
  final String? fontFamily;
  final bool customTitle;
  final FontWeight titleWeight;
  final double titleSpacing;

  final AppIcons icons;

  const AppStyle({
    required this.id,
    required this.name,
    required this.tagline,
    required this.primary,
    required this.primaryLight,
    required this.buttonColor,
    required this.glow,
    required this.panel,
    required this.tintDark,
    required this.tintLight,
    required this.strongLight,
    required this.bgDark,
    required this.surfaceDark,
    required this.navDark,
    required this.bgLight,
    required this.navLight,
    required this.outlineDark,
    required this.outlineLight,
    required this.radiusPanel,
    required this.radiusCard,
    required this.radiusButton,
    required this.radiusField,
    required this.bordered,
    required this.borderWidth,
    required this.underlineFields,
    required this.navIndicator,
    required this.navLabelsAlways,
    required this.fontFamily,
    required this.customTitle,
    required this.titleWeight,
    required this.titleSpacing,
    required this.icons,
  });

  /// Con Alta visibilidad el acento siempre es amarillo, sea cual sea el tema.
  Color accentFor(bool highVisibility) =>
      highVisibility ? const Color(0xFFFFD54F) : glow;

  List<Color> panelFor(bool highVisibility) => highVisibility
      ? const [Color(0xFF594600), Color(0xFF171300)]
      : panel;
}

// ---------------------------------------------------------------- iconos

const _iconsFilled = AppIcons(
  home: Icons.home,
  map: Icons.map,
  history: Icons.bar_chart,
  alerts: Icons.warning_amber,
  settings: Icons.settings,
  calculate: Icons.calculate,
  notifications: Icons.notifications_none_rounded,
  account: Icons.account_circle_outlined,
  route: Icons.alt_route,
  payments: Icons.payments_outlined,
  good: Icons.check_circle,
  doubtful: Icons.help,
  bad: Icons.cancel,
  homeOn: Icons.home,
  homeOff: Icons.home_outlined,
);

const _iconsSharp = AppIcons(
  home: Icons.home_sharp,
  map: Icons.map_sharp,
  history: Icons.bar_chart_sharp,
  alerts: Icons.warning_amber_sharp,
  settings: Icons.settings_sharp,
  calculate: Icons.calculate_sharp,
  notifications: Icons.notifications_none_sharp,
  account: Icons.account_circle_sharp,
  route: Icons.alt_route_sharp,
  payments: Icons.payments_sharp,
  good: Icons.check_circle_sharp,
  doubtful: Icons.help_sharp,
  bad: Icons.cancel_sharp,
  homeOn: Icons.home_sharp,
  homeOff: Icons.home_outlined,
);

const _iconsRounded = AppIcons(
  home: Icons.home_rounded,
  map: Icons.map_rounded,
  history: Icons.bar_chart_rounded,
  alerts: Icons.warning_amber_rounded,
  settings: Icons.settings_rounded,
  calculate: Icons.calculate_rounded,
  notifications: Icons.notifications_none_rounded,
  account: Icons.account_circle_rounded,
  route: Icons.alt_route_rounded,
  payments: Icons.payments_rounded,
  good: Icons.check_circle_rounded,
  doubtful: Icons.help_rounded,
  bad: Icons.cancel_rounded,
  homeOn: Icons.home_rounded,
  homeOff: Icons.home_outlined,
);

const _iconsOutlined = AppIcons(
  home: Icons.home_outlined,
  map: Icons.map_outlined,
  history: Icons.bar_chart_outlined,
  alerts: Icons.warning_amber_outlined,
  settings: Icons.settings_outlined,
  calculate: Icons.calculate_outlined,
  notifications: Icons.notifications_none_outlined,
  account: Icons.account_circle_outlined,
  route: Icons.alt_route_outlined,
  payments: Icons.payments_outlined,
  good: Icons.check_circle_outlined,
  doubtful: Icons.help_outlined,
  bad: Icons.cancel_outlined,
  homeOn: Icons.home,
  homeOff: Icons.home_outlined,
);

// ---------------------------------------------------------------- temas

const List<AppStyle> appStyles = [
  // El aspecto original de RutaNeta.
  AppStyle(
    id: 'neta',
    name: 'Neta',
    tagline: 'Verde limpio, formas suaves e iconos rellenos',
    primary: Color(0xFF00D96A),
    primaryLight: Color(0xFF00D96A),
    buttonColor: Color(0xFF4ADE80),
    glow: Color(0xFF4ADE80),
    panel: [Color(0xFF0C9554), Color(0xFF075335)],
    tintDark: Color(0xFFC9F7D8),
    tintLight: Color(0xFF145D35),
    strongLight: Color(0xFF1B8E5A),
    bgDark: Color(0xFF151621),
    surfaceDark: Color(0xFF20212D),
    navDark: Color(0xFF191A26),
    bgLight: Color(0xFFF3F7F4),
    navLight: Color(0xFFE7EFEA),
    outlineDark: Color(0xFF30313E),
    outlineLight: Color(0xFFE0E6E2),
    radiusPanel: 24,
    radiusCard: 20,
    radiusButton: 16,
    radiusField: 14,
    bordered: true,
    borderWidth: 1,
    underlineFields: false,
    navIndicator: NavIndicator.none,
    navLabelsAlways: true,
    fontFamily: null,
    customTitle: false,
    titleWeight: FontWeight.w400,
    titleSpacing: 0,
    icons: _iconsFilled,
  ),
  // Señalización de obra: naranja, esquinas rectas, letra condensada.
  AppStyle(
    id: 'carretera',
    name: 'Carretera',
    tagline: 'Naranja de señal, esquinas rectas e iconos angulares',
    primary: Color(0xFFFF6D00),
    primaryLight: Color(0xFFC43E00),
    buttonColor: Color(0xFFFF7A1A),
    glow: Color(0xFFFF7A1A),
    panel: [Color(0xFF9A3B00), Color(0xFF2B1100)],
    tintDark: Color(0xFFFFD9BF),
    tintLight: Color(0xFF8F2D00),
    strongLight: Color(0xFFC43E00),
    bgDark: Color(0xFF12100E),
    surfaceDark: Color(0xFF201B17),
    navDark: Color(0xFF1A1613),
    bgLight: Color(0xFFF7F3EE),
    navLight: Color(0xFFEFE7DD),
    outlineDark: Color(0xFF4A3A2E),
    outlineLight: Color(0xFFD9CBB8),
    radiusPanel: 8,
    radiusCard: 6,
    radiusButton: 6,
    radiusField: 6,
    bordered: true,
    borderWidth: 2,
    underlineFields: false,
    navIndicator: NavIndicator.box,
    navLabelsAlways: true,
    fontFamily: 'sans-serif-condensed',
    customTitle: true,
    titleWeight: FontWeight.w900,
    titleSpacing: 1.0,
    icons: _iconsSharp,
  ),
  // Azul agua: muy redondeado, tarjetas con sombra e iconos suaves.
  AppStyle(
    id: 'oceano',
    name: 'Océano',
    tagline: 'Azul agua, formas muy redondeadas e iconos suaves',
    primary: Color(0xFF22D3EE),
    primaryLight: Color(0xFF0E7490),
    buttonColor: Color(0xFF22D3EE),
    glow: Color(0xFF22D3EE),
    panel: [Color(0xFF0E7490), Color(0xFF0B3B66)],
    tintDark: Color(0xFFCFF7FF),
    tintLight: Color(0xFF0B5568),
    strongLight: Color(0xFF0E7490),
    bgDark: Color(0xFF0B1622),
    surfaceDark: Color(0xFF12263A),
    navDark: Color(0xFF0F2033),
    bgLight: Color(0xFFEEF6FA),
    navLight: Color(0xFFE1EEF5),
    outlineDark: Color(0xFF1F3A55),
    outlineLight: Color(0xFFCFE2EC),
    radiusPanel: 32,
    radiusCard: 28,
    radiusButton: 28,
    radiusField: 24,
    bordered: false,
    borderWidth: 0,
    underlineFields: false,
    navIndicator: NavIndicator.pill,
    navLabelsAlways: false,
    fontFamily: null,
    customTitle: true,
    titleWeight: FontWeight.w700,
    titleSpacing: 0.2,
    icons: _iconsRounded,
  ),
  // Noche urbana: violeta, bordes con brillo, campos de línea e iconos finos.
  AppStyle(
    id: 'neon',
    name: 'Neón',
    tagline: 'Violeta nocturno, bordes con brillo e iconos de línea',
    primary: Color(0xFFB388FF),
    primaryLight: Color(0xFF6D28D9),
    buttonColor: Color(0xFFC4A1FF),
    glow: Color(0xFFB388FF),
    panel: [Color(0xFF6D28D9), Color(0xFF1E1B4B)],
    tintDark: Color(0xFFEAD9FF),
    tintLight: Color(0xFF4C1D95),
    strongLight: Color(0xFF6D28D9),
    bgDark: Color(0xFF0D0A1A),
    surfaceDark: Color(0xFF1A1530),
    navDark: Color(0xFF140F26),
    bgLight: Color(0xFFF5F1FB),
    navLight: Color(0xFFEBE4F7),
    outlineDark: Color(0xFF5B3FA0),
    outlineLight: Color(0xFFCDBDEB),
    radiusPanel: 16,
    radiusCard: 14,
    radiusButton: 12,
    radiusField: 12,
    bordered: true,
    borderWidth: 1.5,
    underlineFields: true,
    navIndicator: NavIndicator.outline,
    navLabelsAlways: true,
    fontFamily: null,
    customTitle: true,
    titleWeight: FontWeight.w800,
    titleSpacing: 0.8,
    icons: _iconsOutlined,
  ),
];

AppStyle styleById(String id) =>
    appStyles.firstWhere((s) => s.id == id, orElse: () => appStyles.first);

/// Tema elegido por el conductor.
AppStyle currentStyle() => styleById(store.styleId);
