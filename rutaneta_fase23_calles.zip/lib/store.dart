import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';
import 'traffic_trip.dart';

const int freeCalcsPerDay = 10;

class Store extends ChangeNotifier {
  late SharedPreferences _p;
  Vehicle? vehicle;
  List<Trip> trips = [];
  List<Passenger> passengers = [];
  List<AlertItem> alerts = [];
  bool premium = false;
  int calcsToday = 0;
  String _calcDay = '';
  double trafficFactor = 1.3;
  double targetNetPerHour = 4.0;
  ActiveTrafficTrip? activeTrafficTrip;
  String homeAddress = '';
  double? homeLat;
  double? homeLon;
  bool homeMode = false;
  bool highVisibility = false;
  String appearanceMode = 'auto';
  String styleId = 'neta';
  bool darkTheme = true;

  String _today() => DateTime.now().toIso8601String().substring(0, 10);

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    final v = _p.getString('vehicle');
    if (v != null) {
      vehicle = Vehicle.fromJson(jsonDecode(v) as Map<String, dynamic>);
    }
    trips = _list('trips').map(Trip.fromJson).toList();
    passengers = _list('passengers').map(Passenger.fromJson).toList();
    alerts = _list('alerts').map(AlertItem.fromJson).toList();
    premium = _p.getBool('premium') ?? false;
    _calcDay = _p.getString('calcDay') ?? '';
    calcsToday = _p.getInt('calcsToday') ?? 0;
    trafficFactor = _p.getDouble('trafficFactor') ?? 1.3;
    final target = _p.getDouble('targetNetPerHour') ?? 4.0;
    targetNetPerHour = target.isFinite && target > 0 ? target : 4.0;
    homeAddress = _p.getString('homeAddress') ?? '';
    homeLat = _p.getDouble('homeLat');
    homeLon = _p.getDouble('homeLon');
    homeMode = _p.getBool('homeMode') ?? false;
    highVisibility = _p.getBool('highVisibility') ?? false;
    final savedAppearance = _p.getString('appearanceMode') ?? 'auto';
    appearanceMode = const ['auto', 'dark', 'light'].contains(savedAppearance)
        ? savedAppearance
        : 'auto';
    darkTheme = appearanceMode != 'light';
    styleId = _p.getString('styleId') ?? 'neta';
    _rollDay();
  }

  List<Map<String, dynamic>> _list(String key) {
    final s = _p.getString(key);
    if (s == null) return [];
    return (jsonDecode(s) as List).cast<Map<String, dynamic>>();
  }

  void _rollDay() {
    if (_calcDay != _today()) {
      _calcDay = _today();
      calcsToday = 0;
    }
  }

  Future<void> _save() async {
    if (vehicle != null) {
      await _p.setString('vehicle', jsonEncode(vehicle!.toJson()));
    }
    await _p.setString(
      'trips',
      jsonEncode(trips.map((e) => e.toJson()).toList()),
    );
    await _p.setString(
      'passengers',
      jsonEncode(passengers.map((e) => e.toJson()).toList()),
    );
    await _p.setString(
      'alerts',
      jsonEncode(alerts.map((e) => e.toJson()).toList()),
    );
    await _p.setBool('premium', premium);
    await _p.setString('calcDay', _calcDay);
    await _p.setInt('calcsToday', calcsToday);
    await _p.setDouble('trafficFactor', trafficFactor);
    await _p.setDouble('targetNetPerHour', targetNetPerHour);
    await _p.setString('homeAddress', homeAddress);
    if (homeLat != null && homeLon != null) {
      await _p.setDouble('homeLat', homeLat!);
      await _p.setDouble('homeLon', homeLon!);
    } else {
      await _p.remove('homeLat');
      await _p.remove('homeLon');
    }
    await _p.setBool('homeMode', homeMode);
    await _p.setBool('highVisibility', highVisibility);
    await _p.setString('appearanceMode', appearanceMode);
    await _p.setString('styleId', styleId);
  }

  void _commit() {
    _save();
    notifyListeners();
  }

  // Vehículo
  void setVehicle(Vehicle v) {
    vehicle = v;
    _commit();
  }

  // Cálculos diarios (plan gratis)
  bool get canCalc {
    _rollDay();
    return premium || calcsToday < freeCalcsPerDay;
  }

  int get calcsLeft {
    _rollDay();
    return freeCalcsPerDay - calcsToday;
  }

  void useCalc() {
    _rollDay();
    if (!premium) calcsToday++;
    _commit();
  }

  void setPremium(bool v) {
    premium = v;
    _commit();
  }

  void setTargetNetPerHour(double value) {
    if (!value.isFinite || value <= 0) {
      throw const FormatException(
        'El objetivo por hora debe ser mayor que cero.',
      );
    }
    targetNetPerHour = value;
    _commit();
  }

  void setActiveTrafficTrip(ActiveTrafficTrip trip) {
    activeTrafficTrip = trip;
    notifyListeners();
  }

  void clearActiveTrafficTrip() {
    activeTrafficTrip = null;
    notifyListeners();
  }

  // Tráfico, casa y modo "Hacia casa"
  void setTrafficFactor(double v) {
    trafficFactor = v;
    _commit();
  }

  void setHome(String address, double lat, double lon) {
    homeAddress = address;
    homeLat = lat;
    homeLon = lon;
    _commit();
  }

  bool get hasHome => homeLat != null && homeLon != null;

  void toggleHomeMode() {
    homeMode = !homeMode;
    _commit();
  }

  void setHighVisibility(bool value) {
    highVisibility = value;
    _commit();
  }

  void setStyle(String id) {
    if (id == styleId) return;
    styleId = id;
    _commit();
  }

  void setAppearanceMode(String mode) {
    if (mode != 'auto' && mode != 'dark' && mode != 'light') return;
    appearanceMode = mode;
    if (mode == 'dark') darkTheme = true;
    if (mode == 'light') darkTheme = false;
    if (mode == 'auto') darkTheme = true;
    _commit();
  }

  /// Hysteresis: enter dark below 25 lux, return to light above 60 lux.
  /// Values in between preserve the current theme to avoid flicker.
  void updateAmbientLux(double lux) {
    if (appearanceMode != 'auto' || !lux.isFinite || lux < 0) return;
    final nextDark = darkTheme ? lux <= 60 : lux < 25;
    if (nextDark == darkTheme) return;
    darkTheme = nextDark;
    notifyListeners();
  }

  // Viajes
  void addTrip(Trip t) {
    trips.insert(0, t);
    _commit();
  }

  void finishTrip(Trip t, double realFuel, bool returnedEmpty) {
    t.fuelCost = realFuel;
    t.returnEmpty = returnedEmpty;
    t.finished = true;
    _commit();
  }

  void deleteTrip(Trip t) {
    trips.remove(t);
    _commit();
  }

  List<Trip> tripsSince(DateTime from) =>
      trips.where((t) => !t.date.isBefore(from)).toList();

  List<Trip> get todayTrips {
    final now = DateTime.now();
    return tripsSince(DateTime(now.year, now.month, now.day));
  }

  // Pasajeros y zonas
  void addPassenger(Passenger p) {
    passengers.insert(0, p);
    _commit();
  }

  void deletePassenger(Passenger p) {
    passengers.remove(p);
    _commit();
  }

  /// Devuelve avisos si el texto menciona una zona/persona marcada con etiquetas negativas.
  List<String> warningsFor(String text) {
    final t = text.toLowerCase();
    final out = <String>[];
    if (t.trim().isEmpty) return out;
    for (final p in passengers) {
      final n = p.name.toLowerCase().trim();
      if (n.isEmpty || !t.contains(n)) continue;
      final bad = p.tags.where((x) => x != 'Buen pagador').toList();
      if (bad.isEmpty) continue;
      final what = p.kind == 'zona' ? 'esta colonia' : 'a este pasajero';
      out.add('Cuidado, marcaste $what («${p.name}»): ${bad.join(', ')}');
    }
    return out;
  }

  // Alertas
  List<AlertItem> get activeAlerts {
    final list = alerts.where((a) => a.active).toList();
    list.sort((a, b) => b.created.compareTo(a.created));
    return list;
  }

  void addAlert(AlertItem a) {
    alerts.insert(0, a);
    alerts.removeWhere(
      (x) => DateTime.now().difference(x.created).inHours > 24,
    );
    _commit();
  }

  void voteAlert(AlertItem a, bool stillThere) {
    if (stillThere) {
      a.yes++;
    } else {
      a.no++;
    }
    _commit();
  }

  Future<void> resetAll() async {
    vehicle = null;
    trips = [];
    passengers = [];
    alerts = [];
    premium = false;
    calcsToday = 0;
    trafficFactor = 1.3;
    targetNetPerHour = 4.0;
    activeTrafficTrip = null;
    homeAddress = '';
    homeLat = null;
    homeLon = null;
    homeMode = false;
    highVisibility = false;
    appearanceMode = 'auto';
    styleId = 'neta';
    darkTheme = true;
    await _p.clear();
    notifyListeners();
  }
}

final Store store = Store();
