import 'dart:async';
import 'dart:ui' as ui;
import 'package:flutter/services.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'models.dart';
import 'overlay_calculation.dart';
import 'fare_recommendation.dart';
import 'store.dart';

class OverlayCtrl {
  static const _control = MethodChannel('rutaviva/overlay_control');
  static bool _initialized = false;
  static Trip? _lastTrip;
  static String? _lastId;
  static Map<String, dynamic>? _lastResult;

  static void init() {
    if (_initialized) return;
    _initialized = true;
    _control.setMethodCallHandler(handleCommand);
  }

  static Future<Map<String, dynamic>> handleCommand(MethodCall call) async {
    switch (call.method) {
      case 'summary':
        return summary();
      case 'toggleHome':
        store.toggleHomeMode();
        return summary();
      case 'saveTrip':
        final trip = _lastTrip;
        if (trip == null)
          return {'state': 'saved', 'msg': 'El viaje ya fue guardado'};
        _lastTrip = null;
        store.addTrip(trip);
        return {'state': 'saved', 'msg': 'Viaje guardado en el historial'};
      case 'calculate':
        try {
          final data = Map<String, dynamic>.from(call.arguments as Map);
          if (data['id'] == _lastId && _lastResult != null) return _lastResult!;
          final vehicle = store.vehicle;
          if (vehicle == null)
            throw const FormatException('Configura tu vehículo en Inicio.');
          if (!store.canCalc)
            throw FormatException(
              'Llegaste al límite de $freeCalcsPerDay cálculos de hoy.',
            );
          final useTraffic = data['useTraffic'] == true;
          final active = store.activeTrafficTrip;
          final returnEmpty = data['returnEmpty'] == true;
          if (useTraffic) {
            if (active == null || !active.fresh) {
              throw const FormatException(
                'Actualiza la ruta en el mapa antes de usar su tráfico.',
              );
            }
            if (!active.outbound.hasTrafficData) {
              throw const FormatException(
                'Esta ruta no tiene datos de congestión disponibles. Usa el tiempo manual.',
              );
            }
            if (data['trafficDestinationId'] != active.destinationId ||
                data['confirmTrafficRoute'] != true) {
              throw const FormatException(
                'Confirma que el destino elegido en el mapa corresponde a este viaje.',
              );
            }
            if (returnEmpty && active.returnRoute == null) {
              throw const FormatException(
                'Falta consultar la vuelta. Actualiza el mapa o desactiva regreso vacío.',
              );
            }
          }
          final plan = useTraffic ? active : null;
          final trip = calculateOverlayTrip(
            vehicle: vehicle,
            price: (data['price'] as num).toDouble(),
            km: plan?.outbound.km ?? (data['km'] as num).toDouble(),
            minutes:
                plan?.outbound.minutes ?? (data['minutes'] as num).toDouble(),
            returnEmpty: returnEmpty,
            returnKm: plan?.returnRoute?.km,
            returnMinutes: plan?.returnRoute?.minutes,
            typicalMinutes: plan?.outbound.typicalMinutes,
            returnTypicalMinutes: plan?.returnRoute?.typicalMinutes,
            trafficCheckedAt: plan?.outbound.checkedAt,
            trafficSource: plan?.outbound.source,
            origin: plan?.originLabel ?? '',
            destination: plan?.destinationLabel ?? '',
          );
          final target =
              (data['targetNetPerHour'] as num?)?.toDouble() ??
              store.targetNetPerHour;
          final recommendation = recommendFare(trip, targetNetPerHour: target);
          double? trafficFareIncrease;
          if (plan != null && trip.typicalTotalMinutes != null) {
            final baseline = calculateOverlayTrip(
              vehicle: vehicle,
              price: trip.price,
              km: trip.km,
              minutes: plan.outbound.typicalMinutes!,
              returnEmpty: returnEmpty,
              returnKm: plan.returnRoute?.km,
              returnMinutes: plan.returnRoute?.typicalMinutes,
            );
            final usual = recommendFare(baseline, targetNetPerHour: target);
            final difference =
                recommendation.recommendedFare - usual.recommendedFare;
            trafficFareIncrease = difference > 0 ? difference : 0;
          }
          if (target != store.targetNetPerHour)
            store.setTargetNetPerHour(target);
          _lastId = data['id']?.toString();
          _lastTrip = trip;
          store.useCalc();
          _lastResult = {
            'state': 'result',
            'verdict': recommendation.verdict,
            'signal': recommendation.signal,
            'recommendedFare': recommendation.recommendedFare,
            'breakEvenFare': recommendation.breakEvenFare,
            'requiredIncrease': recommendation.requiredIncrease,
            'targetNetPerHour': recommendation.targetNetPerHour,
            'projectedNet': recommendation.projectedNet,
            'projectedPerHour': recommendation.projectedPerHour,
            'perHour': trip.perHour,
            'net': trip.net,
            'price': trip.price,
            'km': trip.km,
            'minutes': trip.minutes,
            'fuel': trip.fuelCost,
            'commission': trip.commission,
            'wear': trip.wear,
            'returnEmpty': trip.returnEmpty,
            'returnKm': trip.returnKm,
            'returnMinutes': trip.returnMinutes,
            'trafficUsed': useTraffic,
            'traffic': plan?.toOverlaySummary(),
            'trafficDelayMinutes': trip.trafficDelayMinutes,
            'trafficFareIncrease': trafficFareIncrease,
          };
          return _lastResult!;
        } catch (e) {
          return {
            'state': 'error',
            'msg': e is FormatException
                ? e.message
                : 'Revisa los datos del viaje.',
          };
        }
      default:
        throw MissingPluginException(
          'Comando de burbuja desconocido: ${call.method}',
        );
    }
  }

  static Map<String, dynamic> summary() {
    final trips = store.todayTrips;
    final hours = trips.fold<double>(0, (s, t) => s + t.hours);
    final net = trips.fold<double>(0, (s, t) => s + t.net);
    return {
      'net': net,
      'perHour': hours > 0 ? net / hours : 0.0,
      'homeMode': store.homeMode,
      'targetNetPerHour': store.targetNetPerHour,
      'trafficTrip': store.activeTrafficTrip?.toOverlaySummary(),
      'styleId': store.styleId,
      'highVisibility': store.highVisibility,
    };
  }

  static Future<bool> isActive() => FlutterOverlayWindow.isActive();
  static Future<bool> start() async {
    var ok = await FlutterOverlayWindow.isPermissionGranted();
    if (!ok) ok = (await FlutterOverlayWindow.requestPermission()) ?? false;
    if (!ok) return false;
    final views = ui.PlatformDispatcher.instance.views;
    final density = views.isEmpty ? 1.0 : views.first.devicePixelRatio;
    // showOverlay espera píxeles físicos; resizeOverlay espera dp.
    if (!await isActive())
      await FlutterOverlayWindow.showOverlay(
        enableDrag: true,
        overlayTitle: 'RutaNeta',
        overlayContent: 'Burbuja activa',
        flag: OverlayFlag.defaultFlag,
        visibility: NotificationVisibility.visibilityPublic,
        positionGravity: PositionGravity.auto,
        width: (180 * density).round(),
        height: (76 * density).round(),
      );
    return true;
  }

  static Future<void> stop() async {
    if (await isActive()) await FlutterOverlayWindow.closeOverlay();
  }

  static Future<void>
  push() async {} // Compatibilidad con las pantallas existentes.
}
