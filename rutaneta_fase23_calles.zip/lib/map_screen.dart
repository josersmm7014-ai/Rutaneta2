import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart'
    show Geolocator, LocationAccuracy, LocationSettings, Position;
import 'package:latlong2/latlong.dart' show Distance, LatLng, LengthUnit;
import 'package:url_launcher/url_launcher.dart';

import 'app_style.dart';
import 'geo.dart';
import 'screens.dart';
import 'store.dart';
import 'traffic_trip.dart';

Color _trafficColor(String? value) {
  switch (value?.trim().toLowerCase()) {
    case 'low':
      return const Color(0xFF20C878);
    case 'moderate':
      return const Color(0xFFFFD23F);
    case 'heavy':
      return const Color(0xFFFF8C32);
    case 'severe':
      return const Color(0xFFE53935);
    default:
      return const Color(0xFF9AA0AA);
  }
}

IconData _placeIcon(String category) {
  switch (category) {
    case 'Gasolinera':
      return Icons.local_gas_station;
    case 'Comida':
      return Icons.restaurant;
    case 'Farmacia':
    case 'Salud':
      return Icons.local_pharmacy;
    case 'Supermercado':
    case 'Minisúper':
    case 'Tienda':
      return Icons.storefront;
    case 'Mercado':
      return Icons.store_mall_directory;
    case 'Finanzas':
      return Icons.account_balance;
    case 'Automotriz':
      return Icons.car_repair;
    case 'Transporte':
      return Icons.directions_bus;
    case 'Alimentos':
      return Icons.bakery_dining;
    case 'Ropa y belleza':
      return Icons.checkroom;
    case 'Tecnología':
      return Icons.devices_other;
    case 'Turismo':
      return Icons.hotel;
    case 'Recreación':
      return Icons.park;
    case 'Servicios':
      return Icons.miscellaneous_services;
    case 'Oficina':
      return Icons.business_center;
    case 'Educación':
      return Icons.school;
    case 'Taller':
      return Icons.handyman;
    case 'Semáforo':
      return Icons.traffic;
    default:
      return Icons.place;
  }
}

/// El mapa no consulta nada al construirse: la primera acción del conductor
/// (ubicación, búsqueda o destino) es la que puede pedir permisos/conexión.
class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> with WidgetsBindingObserver {
  final MapController controller = MapController();
  final TextEditingController searchController = TextEditingController();

  LatLng? me;
  LatLng? selectedDestination;
  String selectedDestinationLabel = '';
  List<NearbyPlace> places = [];
  String category = 'Todos';
  int radiusKm = 5;
  double zoom = 11;
  bool showNames = true;
  bool brightMap = true;
  bool trafficLayer = true;
  bool sharpMap = true;
  bool controlsOpen = false;
  bool loading = false;
  bool placesLoading = false;
  bool trafficLoading = false;
  bool mapError = false;
  bool placesError = false;
  bool trafficStale = false;
  String? trafficError;
  int placesRequest = 0;
  int tileRevision = 0;
  bool mapReady = false;
  bool appResumed = true;
  Timer? _refreshTimer;
  Timer? _tileTimer;
  StreamSubscription<Position>? _positionSub;
  LatLng? _lastQueryOrigin;
  DateTime? _lastQueryAt;
  ActiveTrafficTrip? _localPlan;

  ActiveTrafficTrip? _storePlan() {
    // Store recibe este modelo en el cambio paralelo del padre. El acceso
    // dinámico permite que esta pantalla siga siendo compilable durante la
    // transición de ramas.
    final value = (store as dynamic).activeTrafficTrip;
    return value is ActiveTrafficTrip ? value : null;
  }

  void _setStorePlan(ActiveTrafficTrip plan) {
    (store as dynamic).setActiveTrafficTrip(plan);
  }

  void _clearStorePlan() {
    (store as dynamic).clearActiveTrafficTrip();
  }

  ActiveTrafficTrip? get _plan => _localPlan ?? _storePlan();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    final plan = _storePlan();
    if (plan != null) {
      _localPlan = plan;
      selectedDestination = plan.destination.ll;
      selectedDestinationLabel = plan.destinationLabel;
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    WidgetsBinding.instance.addPostFrameCallback((_) => _updateRefreshTimer());
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    appResumed = state == AppLifecycleState.resumed;
    if (!appResumed) {
      _refreshTimer?.cancel();
      _refreshTimer = null;
      _tileTimer?.cancel();
      _tileTimer = null;
      _stopLiveLocation();
    } else {
      _updateRefreshTimer();
    }
  }

  void _startLiveLocation() {
    if (_positionSub != null) return;
    try {
      _positionSub =
          Geolocator.getPositionStream(
            locationSettings: const LocationSettings(
              accuracy: LocationAccuracy.high,
              distanceFilter: 25,
            ),
          ).listen((pos) {
            if (!mounted || !appResumed) return;
            final point = LatLng(pos.latitude, pos.longitude);
            setState(() => me = point);
            _refreshIfMoved(point);
          }, onError: (_) {});
    } catch (_) {
      _positionSub = null;
    }
  }

  void _stopLiveLocation() {
    _positionSub?.cancel();
    _positionSub = null;
  }

  /// Si el conductor se movió mucho desde la última consulta, vuelve a pedir
  /// la ruta sin esperar al ciclo de 2 minutos (máximo una vez cada 45 s).
  void _refreshIfMoved(LatLng point) {
    if (selectedDestination == null || trafficLoading) return;
    final lastPoint = _lastQueryOrigin;
    final lastAt = _lastQueryAt;
    if (lastPoint == null || lastAt == null) return;
    if (DateTime.now().difference(lastAt) < const Duration(seconds: 45)) return;
    final meters = const Distance().as(LengthUnit.Meter, lastPoint, point);
    if (meters < 400) return;
    unawaited(_requestTraffic(allowLocate: false));
  }

  void _updateRefreshTimer() {
    _refreshTimer?.cancel();
    _refreshTimer = null;
    if (!mounted || !appResumed) {
      _tileTimer?.cancel();
      _tileTimer = null;
      _stopLiveLocation();
      return;
    }
    final route = ModalRoute.of(context);
    if (route != null && !route.isCurrent) {
      _tileTimer?.cancel();
      _tileTimer = null;
      _stopLiveLocation();
      return;
    }
    // La capa de velocidades de Mapbox cambia cada ~8 min: recargar los
    // mosaicos con ese ritmo. Se crea una sola vez para que las consultas de
    // ruta (que reinician el temporizador de ruta) no lo pospongan.
    _tileTimer ??= Timer.periodic(const Duration(minutes: 8), (_) {
      if (!mounted || !appResumed || !trafficLayer) return;
      setState(() => tileRevision++);
    });
    if (me != null) _startLiveLocation();
    if (me == null || selectedDestination == null) return;
    _refreshTimer = Timer.periodic(const Duration(minutes: 2), (_) {
      if (!mounted || !appResumed) return;
      final currentRoute = ModalRoute.of(context);
      if (currentRoute != null && !currentRoute.isCurrent) return;
      if (me == null || selectedDestination == null || trafficLoading) return;
      unawaited(_requestTraffic(allowLocate: false));
    });
  }

  void _moveMap(LatLng point, double targetZoom) {
    if (!mounted) return;
    if (!mapReady) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && mapReady) controller.move(point, targetZoom);
      });
      return;
    }
    controller.move(point, targetZoom);
  }

  void _fitMap(CameraFit fit) {
    if (!mounted) return;
    if (!mapReady) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && mapReady) controller.fitCamera(fit);
      });
      return;
    }
    controller.fitCamera(fit);
  }

  Future<void> _openMapLink(String address) async {
    try {
      final opened = await launchUrl(
        Uri.parse(address),
        mode: LaunchMode.externalApplication,
      );
      if (!opened && mounted) _message('No se pudo abrir el enlace del mapa');
    } catch (_) {
      if (mounted) _message('No se pudo abrir el enlace del mapa');
    }
  }

  void _handleTileError() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || mapError) return;
      setState(() => mapError = true);
    });
  }

  Future<void> _locate() async {
    if (!mounted || loading) return;
    setState(() => loading = true);
    try {
      final point = await currentLatLng();
      if (!mounted) return;
      if (point == null) {
        _message('Activa la ubicación y da el permiso para consultar tráfico');
        return;
      }
      setState(() => me = point);
      _moveMap(point, 16);
      // Los locales no deben bloquear el GPS ni la consulta de ruta.
      unawaited(_loadPlaces(point));
      _updateRefreshTimer();
    } catch (_) {
      if (mounted) _message('No pude obtener tu ubicación');
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _loadPlaces(LatLng point) async {
    if (!mounted) return;
    final request = ++placesRequest;
    setState(() {
      placesLoading = true;
      placesError = false;
    });
    try {
      final result = await nearbyPlaces(point, radiusMeters: radiusKm * 1000);
      if (!mounted || request != placesRequest) return;
      setState(() {
        places = result;
        if (result.isNotEmpty && !result.any((p) => p.category == category)) {
          category = 'Todos';
        }
      });
      if (result.isEmpty) {
        _message(
          'No se encontraron locales con nombre en este radio. Prueba 10 km.',
        );
      }
    } catch (_) {
      if (mounted && request == placesRequest) {
        setState(() => placesError = true);
        _message(
          'Los locales no respondieron. Pulsa actualizar para reintentar.',
        );
      }
    } finally {
      if (mounted && request == placesRequest) {
        setState(() => placesLoading = false);
      }
    }
  }

  Future<void> _searchDestination() async {
    final query = searchController.text.trim();
    if (query.isEmpty || trafficLoading) return;
    FocusScope.of(context).unfocus();
    setState(() => trafficLoading = true);
    try {
      final point = await geocode(query);
      if (!mounted) return;
      if (point == null) {
        _message('No encontré esa dirección. Prueba con colonia y municipio.');
        return;
      }
      selectedDestination = point.ll;
      selectedDestinationLabel = query;
    } catch (_) {
      if (mounted) _message('No se pudo buscar la dirección');
    } finally {
      if (mounted) setState(() => trafficLoading = false);
    }
    await _requestTraffic();
  }

  Future<void> _selectDestination(LatLng point, {String? label}) async {
    final old = selectedDestination;
    final changed =
        old == null ||
        old.latitude != point.latitude ||
        old.longitude != point.longitude;
    if (changed) {
      _localPlan = null;
      // La consulta anterior no debe pintarse como si fuera el nuevo destino.
      try {
        _clearStorePlan();
      } catch (_) {
        // El store actualizado por el padre siempre tendrá este método.
      }
    }
    setState(() {
      selectedDestination = point;
      selectedDestinationLabel = label ?? 'Punto seleccionado';
    });
    await _requestTraffic();
  }

  Future<void> _onMapLongPress(TapPosition _, LatLng point) async {
    await _selectDestination(point);
  }

  Future<void> _requestTraffic({bool allowLocate = true}) async {
    if (!mounted || trafficLoading) return;
    if (selectedDestination == null) {
      _message(
        'Busca una dirección o mantén pulsado el mapa para elegir destino',
      );
      return;
    }
    if (me == null && allowLocate) await _locate();
    if (!mounted) return;
    if (me == null) {
      _message('Activa Mi ubicación antes de consultar tráfico');
      return;
    }

    final destination = selectedDestination!;
    final origin = me!;
    final previous = _plan;
    setState(() {
      trafficLoading = true;
      trafficError = null;
    });
    try {
      final results = await Future.wait<TrafficRouteInfo?>([
        trafficRoute(
          GeoPoint(origin.latitude, origin.longitude),
          GeoPoint(destination.latitude, destination.longitude),
        ),
        trafficRoute(
          GeoPoint(destination.latitude, destination.longitude),
          GeoPoint(origin.latitude, origin.longitude),
        ),
      ]);
      if (!mounted) return;
      final outbound = results[0];
      final returnRoute = results[1];
      if (outbound == null) {
        setState(() {
          trafficStale = previous != null;
          trafficError = previous == null
              ? 'No se pudo consultar esta ruta'
              : 'Consulta fallida; se conserva la última consulta';
        });
        _message(trafficError!);
        return;
      }
      if (returnRoute == null && previous != null) {
        setState(() {
          trafficStale = true;
          trafficError = 'Consulta parcial; se conserva la última consulta';
        });
        _message(trafficError!);
        return;
      }
      final plan = ActiveTrafficTrip(
        origin: GeoPoint(origin.latitude, origin.longitude),
        destination: GeoPoint(destination.latitude, destination.longitude),
        originLabel: 'Mi ubicación',
        destinationLabel: selectedDestinationLabel.isEmpty
            ? 'Destino seleccionado'
            : selectedDestinationLabel,
        outbound: outbound,
        returnRoute: returnRoute,
      );
      _localPlan = plan;
      _setStorePlan(plan);
      _lastQueryOrigin = origin;
      _lastQueryAt = DateTime.now();
      setState(() {
        trafficStale = false;
        trafficError = returnRoute == null
            ? 'Regreso sin datos de tráfico'
            : null;
      });
      if (outbound.points.isNotEmpty) {
        _fitMap(
          CameraFit.coordinates(
            coordinates: outbound.points,
            padding: const EdgeInsets.fromLTRB(70, 190, 70, 130),
          ),
        );
      }
      if (returnRoute == null) {
        _message('Ida consultada; la vuelta no devolvió datos de tráfico');
      }
    } catch (_) {
      if (mounted) {
        setState(() {
          trafficStale = previous != null;
          trafficError = previous == null
              ? 'No se pudo consultar esta ruta'
              : 'Consulta fallida; se conserva la última consulta';
        });
        _message(trafficError!);
      }
    } finally {
      if (mounted) {
        setState(() => trafficLoading = false);
        _updateRefreshTimer();
      }
    }
  }

  void _showPlaceDetails(NearbyPlace place) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(
                    _placeIcon(place.category),
                    color: Theme.of(context).colorScheme.primary,
                    size: 32,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      place.name,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                '${place.category} · ${place.distanceKm.toStringAsFixed(1)} km',
              ),
              const SizedBox(height: 18),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  OutlinedButton.icon(
                    onPressed: () {
                      Navigator.pop(sheetContext);
                      _moveMap(place.point, 16);
                    },
                    icon: const Icon(Icons.center_focus_strong),
                    label: const Text('Centrar'),
                  ),
                  FilledButton.icon(
                    onPressed: () {
                      Navigator.pop(sheetContext);
                      unawaited(
                        _selectDestination(place.point, label: place.name),
                      );
                    },
                    icon: const Icon(Icons.traffic),
                    label: const Text('Ver tráfico hasta aquí'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showPlacesList() {
    final filtered = category == 'Todos'
        ? places
        : places.where((place) => place.category == category).toList();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.72,
        minChildSize: 0.42,
        maxChildSize: 0.92,
        builder: (context, scrollController) => Container(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surface,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: SafeArea(
            top: false,
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Locales y servicios',
                              style: Theme.of(context).textTheme.titleLarge
                                  ?.copyWith(fontWeight: FontWeight.bold),
                            ),
                            Text(
                              '${filtered.length} resultados · radio de $radiusKm km',
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: 'Cerrar',
                        onPressed: () => Navigator.pop(sheetContext),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),
                Expanded(
                  child: ListView.separated(
                    controller: scrollController,
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (context, index) {
                      final place = filtered[index];
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Theme.of(
                            context,
                          ).colorScheme.primary.withAlpha(35),
                          child: Icon(
                            _placeIcon(place.category),
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                        title: Text(
                          place.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Text(place.category),
                        trailing: Text(
                          '${place.distanceKm.toStringAsFixed(1)} km',
                        ),
                        onTap: () {
                          Navigator.pop(sheetContext);
                          unawaited(
                            _selectDestination(place.point, label: place.name),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _checkedAt(DateTime? value) {
    if (value == null) return 'Sin hora de consulta';
    final local = value.toLocal();
    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');
    return 'Consultado $hour:$minute';
  }

  String _durationLine(TrafficRouteInfo route) {
    final typical = route.typicalMinutes;
    final delay = route.delayMinutes;
    final parts = <String>['${route.minutes.toStringAsFixed(0)} min'];
    if (typical != null) parts.add('habitual ${typical.toStringAsFixed(0)}');
    if (delay != null) parts.add('+${delay.toStringAsFixed(0)} demora');
    return parts.join(' · ');
  }

  List<Polyline> _routePolylines(
    TrafficRouteInfo route, {
    bool returnRoute = false,
  }) {
    final segments = route.segments;
    if (segments.isNotEmpty) {
      return [
        for (final segment in segments)
          if (segment.points.length > 1)
            Polyline(
              points: segment.points,
              strokeWidth: returnRoute ? 6 : 9,
              color: _trafficColor(segment.congestion),
              borderStrokeWidth: 3,
              borderColor: Colors.black.withAlpha(returnRoute ? 130 : 190),
              strokeCap: StrokeCap.round,
              strokeJoin: StrokeJoin.round,
            ),
      ];
    }
    // Una ruta sin anotaciones no se pinta verde: queda explícitamente gris.
    if (route.points.length < 2) return [];
    return [
      Polyline(
        points: route.points,
        strokeWidth: returnRoute ? 6 : 9,
        color: _trafficColor('unknown'),
        borderStrokeWidth: 3,
        borderColor: Colors.black.withAlpha(190),
        strokeCap: StrokeCap.round,
        strokeJoin: StrokeJoin.round,
      ),
    ];
  }

  Widget _trafficStatus(ActiveTrafficTrip? plan) {
    if (plan == null) {
      return const Text(
        'Elige un destino para consultar ida y vuelta con tráfico real.',
        maxLines: 2,
        overflow: TextOverflow.ellipsis,
      );
    }
    final route = plan.outbound;
    final returnRoute = plan.returnRoute;
    final statusColor = _trafficColor(
      route.hasTrafficData
          ? route.congestion.firstWhere(
              (value) => value != null && value != 'unknown',
              orElse: () => 'unknown',
            )
          : 'unknown',
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          '${plan.originLabel} → ${plan.destinationLabel}',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 3),
        Text(
          'Ida ${_durationLine(route)} · ${route.km.toStringAsFixed(1)} km',
          style: TextStyle(color: statusColor, fontWeight: FontWeight.w700),
        ),
        if (returnRoute != null)
          Text(
            'Vuelta ${_durationLine(returnRoute)} · ${returnRoute.km.toStringAsFixed(1)} km',
            style: TextStyle(color: _trafficColor('moderate')),
          )
        else
          const Text(
            'Vuelta: sin datos de tráfico',
            style: TextStyle(color: Colors.grey),
          ),
        const SizedBox(height: 3),
        Wrap(
          spacing: 8,
          runSpacing: 2,
          children: [
            Text('${(route.coverageRatio * 100).round()}% cobertura conocida'),
            Text(_checkedAt(route.checkedAt)),
            Text(
              trafficStale || plan.fresh == false
                  ? 'Datos desactualizados'
                  : 'Datos recientes',
              style: TextStyle(
                color: trafficStale || !plan.fresh
                    ? Colors.orange
                    : Colors.green,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        if (trafficError != null) ...[
          const SizedBox(height: 3),
          Text(trafficError!, style: const TextStyle(color: Colors.orange)),
        ],
      ],
    );
  }

  double get _panelRadius => currentStyle().radiusPanel.clamp(10.0, 28.0).toDouble();

  /// Leyenda compacta: una barra de color en vez de una tarjeta de ancho completo.
  Widget _legend() {
    return Material(
      elevation: 3,
      color: Theme.of(context).colorScheme.surface.withValues(alpha: 0.94),
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Fluido',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
            ),
            const SizedBox(width: 6),
            Container(
              width: 64,
              height: 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                gradient: LinearGradient(
                  colors: [
                    _trafficColor('low'),
                    _trafficColor('moderate'),
                    _trafficColor('heavy'),
                    _trafficColor('severe'),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 6),
            const Text(
              'Severo',
              style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
            ),
            const SizedBox(width: 10),
            Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                color: _trafficColor('unknown'),
                shape: BoxShape.circle,
              ),
            ),
            const SizedBox(width: 4),
            const Text('Sin datos', style: TextStyle(fontSize: 11)),
          ],
        ),
      ),
    );
  }

  /// Buscador flotante de una sola línea; los filtros viven en una hoja.
  Widget _searchPill() {
    final scheme = Theme.of(context).colorScheme;
    final filtersActive = category != 'Todos' || radiusKm != 5;
    return Material(
      elevation: 6,
      shadowColor: Colors.black54,
      color: scheme.surface,
      borderRadius: BorderRadius.circular(_panelRadius),
      child: Padding(
        padding: const EdgeInsets.only(left: 14, right: 4),
        child: Row(
          children: [
            Icon(Icons.search, color: scheme.primary),
            Expanded(
              child: TextField(
                controller: searchController,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _searchDestination(),
                decoration: const InputDecoration(
                  hintText: 'Buscar dirección',
                  isDense: true,
                  filled: false,
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 16,
                  ),
                ),
              ),
            ),
            if (trafficLoading)
              const Padding(
                padding: EdgeInsets.all(14),
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(strokeWidth: 2.4),
                ),
              )
            else
              IconButton.filled(
                tooltip: 'Buscar y ver tráfico',
                onPressed: _searchDestination,
                icon: const Icon(Icons.route),
              ),
            IconButton(
              tooltip: 'Capas, filtros y locales',
              onPressed: _showMapOptions,
              icon: Badge(
                isLabelVisible: filtersActive,
                smallSize: 9,
                child: const Icon(Icons.tune),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Resumen de una línea de la ruta; al tocarlo abre el detalle completo.
  Widget _statusChip(ActiveTrafficTrip plan) {
    final route = plan.outbound;
    final color = _trafficColor(
      route.hasTrafficData
          ? route.congestion.firstWhere(
              (value) => value != null && value != 'unknown',
              orElse: () => 'unknown',
            )
          : 'unknown',
    );
    final stale = trafficStale || !plan.fresh;
    return Material(
      elevation: 5,
      shadowColor: Colors.black54,
      color: Theme.of(context).colorScheme.surface,
      borderRadius: BorderRadius.circular(22),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: _showTrafficDetails,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 14,
                height: 14,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              ),
              const SizedBox(width: 10),
              Flexible(
                child: Text(
                  'Ida ${route.minutes.toStringAsFixed(0)} min · ${route.km.toStringAsFixed(1)} km',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
              const SizedBox(width: 8),
              Icon(
                stale ? Icons.warning_amber_rounded : Icons.chevron_right,
                size: 20,
                color: stale ? Colors.orange : null,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _mapButton({
    required IconData icon,
    required String tooltip,
    required VoidCallback? onPressed,
    bool active = false,
    bool busy = false,
    String? badge,
  }) {
    final scheme = Theme.of(context).colorScheme;
    final shape = RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(_panelRadius.clamp(8.0, 24.0).toDouble()),
    );
    final fg = onPressed == null && !busy
        ? scheme.onSurface.withValues(alpha: 0.38)
        : (active ? scheme.onPrimary : scheme.primary);
    Widget button = Material(
      elevation: 5,
      shadowColor: Colors.black54,
      color: active ? scheme.primary : scheme.surface,
      shape: shape,
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onPressed,
        child: SizedBox(
          width: 48,
          height: 48,
          child: Center(
            child: busy
                ? SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.4,
                      color: fg,
                    ),
                  )
                : Icon(icon, color: fg),
          ),
        ),
      ),
    );
    if (badge != null) button = Badge(label: Text(badge), child: button);
    return Tooltip(
      message: tooltip,
      child: Semantics(button: true, label: tooltip, child: button),
    );
  }

  Widget _zoomPill() {
    final scheme = Theme.of(context).colorScheme;
    final radius = BorderRadius.circular(_panelRadius.clamp(8.0, 24.0).toDouble());
    return Material(
      elevation: 5,
      shadowColor: Colors.black54,
      color: scheme.surface,
      borderRadius: radius,
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Tooltip(
            message: 'Acercar',
            child: InkWell(
              onTap: () => _moveMap(controller.camera.center, zoom + 1),
              child: SizedBox(
                width: 48,
                height: 46,
                child: Icon(Icons.add, color: scheme.primary),
              ),
            ),
          ),
          const Divider(height: 1),
          Tooltip(
            message: 'Alejar',
            child: InkWell(
              onTap: () => _moveMap(controller.camera.center, zoom - 1),
              child: SizedBox(
                width: 48,
                height: 46,
                child: Icon(Icons.remove, color: scheme.primary),
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Botones de la derecha: lo esencial siempre a mano y lo demás plegado.
  Widget _controls(ActiveTrafficTrip? plan, int placeCount) {
    final shortScreen = MediaQuery.sizeOf(context).height < 560;
    final open = controlsOpen && !shortScreen;
    const gap = SizedBox(height: 8);
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        AnimatedSize(
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOutCubic,
          alignment: Alignment.bottomRight,
          child: open
              ? Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    _zoomPill(),
                    gap,
                    if (places.isNotEmpty) ...[
                      _mapButton(
                        icon: Icons.storefront_outlined,
                        tooltip: 'Locales ($placeCount)',
                        badge: '$placeCount',
                        onPressed: _showPlacesList,
                      ),
                      gap,
                    ],
                  ],
                )
              : const SizedBox(width: 0, height: 0),
        ),
        if (!shortScreen) ...[
          _mapButton(
            icon: open ? Icons.close : Icons.more_horiz,
            tooltip: open ? 'Menos opciones' : 'Más opciones',
            active: open,
            onPressed: () => setState(() => controlsOpen = !controlsOpen),
          ),
          gap,
        ],
        _mapButton(
          icon: Icons.refresh,
          tooltip: 'Actualizar tráfico',
          busy: trafficLoading,
          onPressed: trafficLoading ? null : () => _requestTraffic(),
        ),
        gap,
        _mapButton(
          icon: Icons.my_location,
          tooltip: 'Mi ubicación',
          busy: loading,
          onPressed: loading ? null : _locate,
        ),
        if (plan != null) ...[
          const SizedBox(height: 10),
          if (shortScreen)
            FloatingActionButton(
              heroTag: 'calculate-route',
              tooltip: 'Calcular esta ruta',
              onPressed: () => _openCalc(plan),
              child: Icon(currentStyle().icons.calculate),
            )
          else
            FloatingActionButton.extended(
              heroTag: 'calculate-route',
              onPressed: () => _openCalc(plan),
              icon: Icon(currentStyle().icons.calculate),
              label: const Text('Calcular esta ruta'),
            ),
        ],
      ],
    );
  }

  void _openCalc(ActiveTrafficTrip plan) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => CalcScreen(initialTrafficTrip: plan)),
    );
  }

  Widget _meDot() => Stack(
    alignment: Alignment.center,
    children: [
      Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF1E88E5).withValues(alpha: 0.22),
        ),
      ),
      Container(
        width: 20,
        height: 20,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xFF1E88E5),
          border: Border.all(color: Colors.white, width: 3),
          boxShadow: const [BoxShadow(color: Colors.black38, blurRadius: 6)],
        ),
      ),
    ],
  );

  /// Hoja con capas del mapa, filtros de locales y radio de búsqueda.
  void _showMapOptions() {
    final categories = <String>{
      'Todos',
      ...places.map((p) => p.category),
    }.toList();
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (context, setSheet) {
          void update(VoidCallback change) {
            setState(change);
            setSheet(() {});
          }

          final visibleCount = category == 'Todos'
              ? places.length
              : places.where((p) => p.category == category).length;
          final titleStyle = Theme.of(
            context,
          ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w900);
          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text('Capas del mapa', style: titleStyle),
                  const SizedBox(height: 10),
                  SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(
                        value: true,
                        icon: Icon(Icons.light_mode),
                        label: Text('Claro'),
                      ),
                      ButtonSegment(
                        value: false,
                        icon: Icon(Icons.dark_mode),
                        label: Text('Nocturno'),
                      ),
                    ],
                    selected: {brightMap},
                    onSelectionChanged: (value) =>
                        update(() => brightMap = value.first),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    secondary: const Icon(Icons.traffic),
                    title: const Text('Tráfico en el mapa'),
                    value: trafficLayer,
                    onChanged: (value) => update(() => trafficLayer = value),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    secondary: const Icon(Icons.hd_outlined),
                    title: const Text('Calles nítidas'),
                    subtitle: const Text(
                      'Mapa en alta resolución. Usa más datos y memoria; '
                      'desactívalo si el teléfono va lento.',
                    ),
                    value: sharpMap,
                    onChanged: (value) => update(() => sharpMap = value),
                  ),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    secondary: const Icon(Icons.label_outline),
                    title: const Text('Nombres de locales al acercar'),
                    value: showNames,
                    onChanged: (value) => update(() => showNames = value),
                  ),
                  const Divider(),
                  Text('Locales cercanos', style: titleStyle),
                  const SizedBox(height: 4),
                  Text(
                    placesLoading
                        ? 'Buscando locales…'
                        : placesError
                        ? 'Consulta fallida; actualiza para reintentar.'
                        : me == null
                        ? 'Pulsa Mi ubicación para buscar locales.'
                        : '$visibleCount locales · radio $radiusKm km',
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      for (final item in categories)
                        ChoiceChip(
                          label: Text(item),
                          selected: category == item,
                          onSelected: (_) => update(() => category = item),
                        ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 8,
                    children: [
                      for (final radius in [5, 10, 20])
                        ChoiceChip(
                          label: Text('$radius km'),
                          selected: radiusKm == radius,
                          onSelected: (selected) {
                            if (!selected) return;
                            update(() => radiusKm = radius);
                            if (me != null) unawaited(_loadPlaces(me!));
                          },
                        ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: me == null || placesLoading
                        ? null
                        : () {
                            Navigator.pop(sheetContext);
                            unawaited(_loadPlaces(me!));
                          },
                    icon: const Icon(Icons.refresh),
                    label: const Text('Actualizar locales'),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    'Ubicación en vivo · ruta cada 2 min o al avanzar 400 m · capa Mapbox ~8 min.',
                    style: TextStyle(fontSize: 11, color: Colors.grey),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  void _showTrafficDetails() {
    final plan = _plan;
    if (plan == null) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Tráfico de la ruta',
                style: Theme.of(
                  context,
                ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
              ),
              const SizedBox(height: 10),
              _trafficStatus(plan),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: () {
                  Navigator.pop(sheetContext);
                  _openCalc(plan);
                },
                icon: Icon(currentStyle().icons.calculate),
                label: const Text('Calcular esta ruta'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _refreshTimer?.cancel();
    _tileTimer?.cancel();
    _stopLiveLocation();
    WidgetsBinding.instance.removeObserver(this);
    placesRequest++;
    searchController.dispose();
    mapReady = false;
    controller.dispose();
    super.dispose();
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  Widget build(BuildContext context) {
    final plan = _plan;
    final home = store.hasHome ? LatLng(store.homeLat!, store.homeLon!) : null;
    final visiblePlaces = category == 'Todos'
        ? places
        : places.where((p) => p.category == category).toList();
    final labelsOnMap = showNames && zoom >= 16;
    final accent = currentStyle().accentFor(store.highVisibility);

    final routePolylines = <Polyline>[
      if (plan != null) ..._routePolylines(plan.outbound),
      if (plan?.returnRoute != null)
        ..._routePolylines(plan!.returnRoute!, returnRoute: true),
    ];
    return Scaffold(
      body: Stack(
        children: [
          FlutterMap(
            mapController: controller,
            options: MapOptions(
              initialCenter: LatLng(13.72, -89.2),
              initialZoom: 11,
              onMapReady: () {
                if (mounted) setState(() => mapReady = true);
              },
              onLongPress: _onMapLongPress,
              interactionOptions: InteractionOptions(
                flags: InteractiveFlag.all & ~InteractiveFlag.rotate,
              ),
              onPositionChanged: (camera, _) {
                if (!mounted || (camera.zoom - zoom).abs() < 0.5) return;
                setState(() => zoom = camera.zoom);
              },
            ),
            children: [
              TileLayer(
                key: ValueKey('mapbox-$tileRevision-$brightMap-$trafficLayer-$sharpMap'),
                urlTemplate: mapboxTileTemplate(
                  dark: !brightMap,
                  traffic: trafficLayer,
                  retina: sharpMap,
                ),
                tileSize: 512,
                zoomOffset: -1,
                maxNativeZoom: 22,
                panBuffer: 0,
                errorTileCallback: (_, __, ___) => _handleTileError(),
                evictErrorTileStrategy: EvictErrorTileStrategy.dispose,
                userAgentPackageName: 'com.rutaviva.rutaviva',
              ),
              if (routePolylines.isNotEmpty)
                PolylineLayer(polylines: routePolylines),
              MarkerLayer(
                markers: [
                  for (final p in visiblePlaces)
                    Marker(
                      point: p.point,
                      width: labelsOnMap ? 150 : 36,
                      height: labelsOnMap ? 44 : 36,
                      child: GestureDetector(
                        onTap: () => _showPlaceDetails(p),
                        child: labelsOnMap
                            ? Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 8,
                                  vertical: 5,
                                ),
                                decoration: BoxDecoration(
                                  color: const Color(0xF2181924),
                                  borderRadius: BorderRadius.circular(12),
                                  border: Border.all(
                                    color: accent,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Icon(
                                      _placeIcon(p.category),
                                      color: accent,
                                      size: 20,
                                    ),
                                    const SizedBox(width: 6),
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            p.name,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              color: Colors.white,
                                              fontSize: 11,
                                              fontWeight: FontWeight.bold,
                                            ),
                                          ),
                                          Text(
                                            '${p.category} · ${p.distanceKm.toStringAsFixed(1)} km',
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: const TextStyle(
                                              color: Color(0xFFC7CBD4),
                                              fontSize: 9,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : Container(
                                decoration: BoxDecoration(
                                  color: const Color(0xFF20212D),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                    color: accent,
                                    width: 2,
                                  ),
                                ),
                                child: Icon(
                                  _placeIcon(p.category),
                                  color: accent,
                                  size: 20,
                                ),
                              ),
                      ),
                    ),
                  if (home != null)
                    Marker(
                      point: home,
                      width: 40,
                      height: 40,
                      child: const Icon(
                        Icons.home,
                        color: Colors.orange,
                        size: 34,
                        shadows: [Shadow(color: Colors.black54, blurRadius: 6)],
                      ),
                    ),
                  if (plan != null)
                    Marker(
                      point: plan.origin.ll,
                      width: 44,
                      height: 44,
                      child: const Icon(
                        Icons.trip_origin,
                        color: Color(0xFF1565C0),
                        size: 34,
                        shadows: [Shadow(color: Colors.white, blurRadius: 8)],
                      ),
                    ),
                  if (me != null &&
                      (plan == null ||
                          (me!.latitude - plan.origin.lat).abs() > 0.000001 ||
                          (me!.longitude - plan.origin.lon).abs() > 0.000001))
                    Marker(
                      point: me!,
                      width: 40,
                      height: 40,
                      child: _meDot(),
                    ),
                  if (selectedDestination != null)
                    Marker(
                      point: selectedDestination!,
                      width: 44,
                      height: 44,
                      child: const Icon(
                        Icons.flag,
                        color: Color(0xFFE53935),
                        size: 38,
                        shadows: [Shadow(color: Colors.black54, blurRadius: 6)],
                      ),
                    ),
                ],
              ),
              RichAttributionWidget(
                alignment: AttributionAlignment.bottomLeft,
                permanentHeight: 32,
                popupBackgroundColor: const Color(0xFF20212D),
                showFlutterMapAttribution: false,
                attributions: [
                  LogoSourceAttribution(
                    Container(
                      color: const Color(0xBB151621),
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: Image.asset('assets/icon/mapbox-logo.png'),
                    ),
                    height: 30,
                    tooltip: 'Mapbox',
                    onTap: () =>
                        _openMapLink('https://www.mapbox.com/about/maps'),
                  ),
                  TextSourceAttribution(
                    'Mapbox',
                    onTap: () =>
                        _openMapLink('https://www.mapbox.com/about/maps'),
                  ),
                  TextSourceAttribution(
                    'OpenStreetMap contributors',
                    onTap: () =>
                        _openMapLink('https://www.openstreetmap.org/copyright'),
                  ),
                  TextSourceAttribution(
                    'Mejorar este mapa',
                    prependCopyright: false,
                    onTap: () =>
                        _openMapLink('https://apps.mapbox.com/feedback/'),
                  ),
                ],
              ),
            ],
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 560),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _searchPill(),
                        if (plan != null) ...[
                          const SizedBox(height: 8),
                          _statusChip(plan),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          if (trafficLayer || plan != null)
            Positioned(left: 10, bottom: 44, child: _legend()),
          Positioned(
            right: 10,
            bottom: 10,
            child: _controls(plan, visiblePlaces.length),
          ),
          if (mapError)
            Positioned(
              left: 12,
              right: 12,
              bottom: 96,
              child: Card(
                color: Colors.orange.shade900,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Text('No se pudo cargar el fondo Mapbox.'),
                      ),
                      TextButton(
                        onPressed: () => setState(() {
                          mapError = false;
                          tileRevision++;
                        }),
                        child: const Text('Reintentar'),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
