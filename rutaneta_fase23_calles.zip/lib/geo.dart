import 'dart:convert';
import 'dart:math';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart' show Distance, LatLng, LengthUnit;

class GeoPoint {
  final double lat;
  final double lon;
  const GeoPoint(this.lat, this.lon);

  LatLng get ll => LatLng(lat, lon);
}

class RouteInfo {
  final double km;
  final double minutes; // sin tráfico
  final List<LatLng> points;
  const RouteInfo(this.km, this.minutes, this.points);
}

class NearbyPlace {
  final String name;
  final String category;
  final LatLng point;
  final double distanceKm;

  const NearbyPlace({
    required this.name,
    required this.category,
    required this.point,
    required this.distanceKm,
  });
}

class TrafficRouteInfo {
  final double km;
  final double minutes;
  final List<LatLng> points;
  final List<String?> congestion;
  final double? typicalMinutes;
  final DateTime? checkedAt;
  final String source;
  final List<TrafficSegment> segments;
  final List<double>? _annotationDistances;

  const TrafficRouteInfo({
    required this.km,
    required this.minutes,
    required this.points,
    required this.congestion,
    this.typicalMinutes,
    this.checkedAt,
    this.source = 'Mapbox',
    this.segments = const [],
    List<double>? annotationDistances,
  }) : _annotationDistances = annotationDistances;

  static const _knownCongestion = {'low', 'moderate', 'heavy', 'severe'};

  bool get hasTrafficData => congestion.any(
    (value) => _knownCongestion.contains(value?.trim().toLowerCase()),
  );

  double get coverageRatio {
    final known = congestion
        .map((value) => _knownCongestion.contains(value?.trim().toLowerCase()))
        .toList(growable: false);
    if (known.isEmpty) return 0;
    final distances = _annotationDistances;
    if (distances != null && distances.length == known.length) {
      var totalDistance = 0.0;
      var knownDistance = 0.0;
      for (var i = 0; i < known.length; i++) {
        final distance = distances[i];
        if (!distance.isFinite || distance < 0) {
          totalDistance = 0;
          break;
        }
        totalDistance += distance;
        if (known[i]) knownDistance += distance;
      }
      if (totalDistance > 0 && totalDistance.isFinite) {
        return (knownDistance / totalDistance).clamp(0.0, 1.0).toDouble();
      }
    }
    return (known.where((value) => value).length / known.length)
        .clamp(0.0, 1.0)
        .toDouble();
  }

  double? get delayMinutes =>
      typicalMinutes == null ? null : max(0, minutes - typicalMinutes!);

  String get status {
    if (congestion.any((value) => value?.trim().toLowerCase() == 'severe')) {
      return 'Severo';
    }
    if (congestion.any((value) => value?.trim().toLowerCase() == 'heavy')) {
      return 'Alto';
    }
    if (congestion.any((value) => value?.trim().toLowerCase() == 'moderate')) {
      return 'Moderado';
    }
    if (congestion.any((value) => value?.trim().toLowerCase() == 'low')) {
      return 'Fluido';
    }
    return 'Sin datos';
  }
}

class TrafficSegment {
  final List<LatLng> points;
  final String congestion;

  const TrafficSegment({required this.points, required this.congestion});
}

const _mapboxPublicToken =
    'pk.eyJ1Ijoiam9zZXJzNzAiLCJhIjoiY212eDZiaTAxMDEzYzJ5b285YnU5NmpwNiJ9.4w4YP1VUXmVLqVgx-s4EVw';

/// Mapbox raster de 512 px: usar tileSize=512 y zoomOffset=-1.
/// El token público ya autorizado se usa tanto para el fondo como para rutas.
///
/// Sin capa de tráfico, el modo claro usa `streets-v12` (calles bien marcadas)
/// en vez de `light-v11`, que es un fondo deliberadamente apagado.
/// Con [retina] se piden mosaicos @2x (1024 px) para que las calles se vean
/// nítidas en pantallas de alta densidad, a costa de más datos y memoria.
String mapboxTileTemplate({
  bool dark = true,
  bool traffic = false,
  bool retina = true,
}) {
  final style = traffic
      ? (dark ? 'navigation-night-v1' : 'navigation-day-v1')
      : (dark ? 'dark-v11' : 'streets-v12');
  return 'https://api.mapbox.com/styles/v1/mapbox/$style/tiles/512/'
      '{z}/{x}/{y}${retina ? '@2x' : ''}'
      '?access_token=${Uri.encodeQueryComponent(_mapboxPublicToken)}';
}

String _placeCategory(Map<String, dynamic> tags) {
  final amenity = '${tags['amenity'] ?? ''}';
  final shop = '${tags['shop'] ?? ''}';
  if (amenity == 'fuel') return 'Gasolinera';
  if ({
    'restaurant',
    'fast_food',
    'cafe',
    'food_court',
    'bar',
    'pub',
    'ice_cream',
  }.contains(amenity)) {
    return 'Comida';
  }
  if (amenity == 'pharmacy') return 'Farmacia';
  if ({
    'hospital',
    'clinic',
    'doctors',
    'dentist',
    'veterinary',
  }.contains(amenity)) {
    return 'Salud';
  }
  if ({'bank', 'atm', 'bureau_de_change'}.contains(amenity)) {
    return 'Finanzas';
  }
  if ({
    'car_rental',
    'car_wash',
    'vehicle_inspection',
    'charging_station',
  }.contains(amenity)) {
    return 'Automotriz';
  }
  if ({'parking', 'bus_station', 'taxi'}.contains(amenity)) {
    return 'Transporte';
  }
  if ({'post_office', 'police', 'fire_station', 'townhall'}.contains(amenity)) {
    return 'Servicios';
  }
  if (amenity == 'marketplace') return 'Mercado';
  if ({'school', 'college', 'university', 'library'}.contains(amenity)) {
    return 'Educación';
  }
  if ({'supermarket', 'wholesale', 'department_store'}.contains(shop)) {
    return 'Supermercado';
  }
  if (shop == 'convenience') return 'Minisúper';
  if ({
    'bakery',
    'butcher',
    'greengrocer',
    'confectionery',
    'deli',
  }.contains(shop)) {
    return 'Alimentos';
  }
  if ({
    'car',
    'car_repair',
    'car_parts',
    'tyres',
    'motorcycle',
  }.contains(shop)) {
    return 'Automotriz';
  }
  if ({
    'clothes',
    'shoes',
    'jewelry',
    'beauty',
    'hairdresser',
    'cosmetics',
  }.contains(shop)) {
    return 'Ropa y belleza';
  }
  if ({'electronics', 'computer', 'mobile_phone', 'hifi'}.contains(shop)) {
    return 'Tecnología';
  }
  if (amenity.isNotEmpty) return 'Servicios';
  if (shop.isNotEmpty) return 'Tienda';
  if ('${tags['tourism'] ?? ''}'.isNotEmpty) return 'Turismo';
  if ('${tags['leisure'] ?? ''}'.isNotEmpty) return 'Recreación';
  if ('${tags['craft'] ?? ''}'.isNotEmpty) return 'Taller';
  if ('${tags['office'] ?? ''}'.isNotEmpty) return 'Oficina';
  return 'Lugar';
}

/// Consulta negocios OSM con Photon; usa Overpass como respaldo.
Future<List<NearbyPlace>> nearbyPlaces(
  LatLng center, {
  int radiusMeters = 5000,
  http.Client? client,
}) async {
  final connection = client ?? http.Client();
  try {
    final uri = Uri.https('photon.komoot.io', '/reverse', {
      'lat': '${center.latitude}',
      'lon': '${center.longitude}',
      'radius': '${radiusMeters / 1000}',
      'limit': '100',
      'osm_tag': ['shop', 'amenity', 'tourism', 'leisure', 'craft', 'office'],
    });
    try {
      final response = await connection
          .get(
            uri,
            headers: {'User-Agent': 'RutaNeta/4.5.2 (com.rutaviva.rutaviva)'},
          )
          .timeout(const Duration(seconds: 12));
      if (response.statusCode != 200)
        throw const FormatException('Photon no disponible');
      final body =
          jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
      if (body['features'] is! List)
        throw const FormatException('Respuesta de locales incompleta');
      final result = <NearbyPlace>[];
      final seen = <String>{};
      final distance = Distance();
      for (final raw in body['features'] as List) {
        if (raw is! Map) continue;
        final properties = raw['properties'];
        final geometry = raw['geometry'];
        if (properties is! Map || geometry is! Map) continue;
        final coords = geometry['coordinates'];
        if (coords is! List ||
            coords.length < 2 ||
            coords[0] is! num ||
            coords[1] is! num)
          continue;
        final name = '${properties['name'] ?? ''}'.trim();
        if (name.isEmpty) continue;
        final tags = <String, dynamic>{
          '${properties['osm_key']}': properties['osm_value'],
        };
        final category = _placeCategory(tags);
        if (category == 'Lugar') continue;
        final point = LatLng(
          (coords[1] as num).toDouble(),
          (coords[0] as num).toDouble(),
        );
        final km = distance.as(LengthUnit.Kilometer, center, point);
        if (km > radiusMeters / 1000) continue;
        final id =
            '${properties['osm_type']}/${properties['osm_id']}/${name.toLowerCase()}';
        if (!seen.add(id)) continue;
        result.add(
          NearbyPlace(
            name: name,
            category: category,
            point: point,
            distanceKm: km,
          ),
        );
      }
      result.sort((a, b) => a.distanceKm.compareTo(b.distanceKm));
      return result;
    } catch (_) {
      return await _overpassPlaces(
        center,
        radiusMeters: radiusMeters,
        client: connection,
      );
    }
  } finally {
    if (client == null) connection.close();
  }
}

Future<List<NearbyPlace>> _overpassPlaces(
  LatLng center, {
  required int radiusMeters,
  required http.Client client,
}) async {
  final query =
      '''[out:json][timeout:8];
(
  nwr(around:$radiusMeters,${center.latitude},${center.longitude})[name][shop];
  nwr(around:$radiusMeters,${center.latitude},${center.longitude})[name][amenity~"fuel|restaurant|fast_food|cafe|food_court|bar|pub|ice_cream|pharmacy|hospital|clinic|doctors|dentist|veterinary|bank|atm|bureau_de_change|car_rental|car_wash|vehicle_inspection|charging_station|parking|bus_station|taxi|post_office|police|fire_station|townhall|school|college|university|library|marketplace"];
  nwr(around:$radiusMeters,${center.latitude},${center.longitude})[name][tourism~"hotel|motel|hostel|guest_house|museum|attraction|viewpoint|information"];
  nwr(around:$radiusMeters,${center.latitude},${center.longitude})[name][leisure~"fitness_centre|sports_centre|park|swimming_pool"];
  nwr(around:$radiusMeters,${center.latitude},${center.longitude})[name][craft];
  nwr(around:$radiusMeters,${center.latitude},${center.longitude})[name][office];
);
out center tags;''';
  final res = await client
      .post(
        Uri.parse('https://overpass-api.de/api/interpreter'),
        headers: {'User-Agent': 'RutaNeta/4.5.2 (com.rutaviva.rutaviva)'},
        body: {'data': query},
      )
      .timeout(const Duration(seconds: 12));
  if (res.statusCode != 200) {
    throw Exception('Overpass respondió con estado ${res.statusCode}');
  }
  final body = jsonDecode(res.body) as Map<String, dynamic>;
  if (body['remark'] != null || body['elements'] is! List) {
    throw const FormatException('Overpass no pudo completar la consulta');
  }
  final elements = body['elements'] as List? ?? const [];
  final distance = Distance();
  final places = <NearbyPlace>[];
  final seen = <String>{};
  for (final raw in elements) {
    final e = raw as Map<String, dynamic>;
    final identity = '${e['type']}/${e['id']}';
    if (!seen.add(identity)) continue;
    final tags = (e['tags'] as Map?)?.cast<String, dynamic>() ?? const {};
    final lat =
        (e['lat'] as num?)?.toDouble() ??
        ((e['center'] as Map?)?['lat'] as num?)?.toDouble();
    final lon =
        (e['lon'] as num?)?.toDouble() ??
        ((e['center'] as Map?)?['lon'] as num?)?.toDouble();
    final name = '${tags['name'] ?? ''}'.trim();
    if (lat == null || lon == null || name.isEmpty) continue;
    final point = LatLng(lat, lon);
    places.add(
      NearbyPlace(
        name: name,
        category: _placeCategory(tags),
        point: point,
        distanceKm: distance.as(LengthUnit.Kilometer, center, point),
      ),
    );
  }
  places.sort((a, b) => a.distanceKm.compareTo(b.distanceKm));
  return places.take(180).toList();
}

List<dynamic>? _trafficAnnotationValues(
  Map<String, dynamic> route,
  String key,
) {
  final rawLegs = route['legs'];
  if (rawLegs == null) return null;
  if (rawLegs is! List) throw const FormatException('legs inválidos');
  final values = <dynamic>[];
  for (final rawLeg in rawLegs) {
    if (rawLeg is! Map) throw const FormatException('leg inválido');
    final rawAnnotation = rawLeg['annotation'];
    if (rawAnnotation == null) continue;
    if (rawAnnotation is! Map) {
      throw const FormatException('annotation inválida');
    }
    final rawValues = rawAnnotation[key];
    if (rawValues == null) continue;
    if (rawValues is! List) {
      throw const FormatException('annotation array inválido');
    }
    values.addAll(rawValues);
  }
  return values;
}

String _trafficCategory(dynamic value) {
  final category = value?.toString().trim().toLowerCase();
  if (TrafficRouteInfo._knownCongestion.contains(category)) return category!;
  return 'unknown';
}

double? _positiveFiniteNumber(dynamic value) {
  if (value is! num) return null;
  final number = value.toDouble();
  return number.isFinite && number > 0 ? number : null;
}

/// Ruta con tráfico de Mapbox. La ruta requiere un token público de Mapbox.
Future<TrafficRouteInfo?> trafficRoute(
  GeoPoint a,
  GeoPoint b, {
  http.Client? client,
}) async {
  final connection = client ?? http.Client();
  final checkedAt = DateTime.now();
  final uri = Uri.https(
    'api.mapbox.com',
    '/directions/v5/mapbox/driving-traffic/${a.lon},${a.lat};${b.lon},${b.lat}',
    {
      'alternatives': 'false',
      'overview': 'full',
      'geometries': 'geojson',
      'annotations': 'congestion,congestion_numeric,duration,distance',
      'access_token': _mapboxPublicToken,
    },
  );
  try {
    final res = await connection
        .get(uri, headers: {'User-Agent': 'RutaNeta/4.7.0'})
        .timeout(const Duration(seconds: 20));
    if (res.statusCode != 200) return null;

    final decoded = jsonDecode(utf8.decode(res.bodyBytes));
    if (decoded is! Map) return null;
    final rawRoutes = decoded['routes'];
    if (rawRoutes is! List || rawRoutes.isEmpty) return null;
    final rawRoute = rawRoutes.first;
    if (rawRoute is! Map) return null;
    final route = rawRoute.cast<String, dynamic>();

    final meters = _positiveFiniteNumber(route['distance']);
    final seconds = _positiveFiniteNumber(route['duration']);
    if (meters == null || seconds == null) return null;
    final typicalSeconds = _positiveFiniteNumber(route['duration_typical']);

    final rawGeometry = route['geometry'];
    if (rawGeometry is! Map) return null;
    final rawCoordinates = rawGeometry['coordinates'];
    if (rawCoordinates is! List || rawCoordinates.length < 2) return null;
    final points = <LatLng>[];
    for (final rawCoordinate in rawCoordinates) {
      if (rawCoordinate is! List || rawCoordinate.length < 2) return null;
      final lon = rawCoordinate[0];
      final lat = rawCoordinate[1];
      if (lon is! num || lat is! num) return null;
      final longitude = lon.toDouble();
      final latitude = lat.toDouble();
      if (!longitude.isFinite || !latitude.isFinite) return null;
      points.add(LatLng(latitude, longitude));
    }

    final rawCongestion = _trafficAnnotationValues(route, 'congestion') ?? [];
    final rawDistance = _trafficAnnotationValues(route, 'distance');
    final segmentCount = points.length - 1;
    final congestion = <String?>[
      for (var i = 0; i < segmentCount; i++)
        _trafficCategory(i < rawCongestion.length ? rawCongestion[i] : null),
    ];
    final segments = <TrafficSegment>[
      for (var i = 0; i < segmentCount; i++)
        TrafficSegment(
          points: List<LatLng>.unmodifiable([points[i], points[i + 1]]),
          congestion: congestion[i]!,
        ),
    ];
    List<double>? annotationDistances;
    if (rawDistance != null && rawDistance.length == segmentCount) {
      final parsed = <double>[];
      var valid = true;
      for (final value in rawDistance) {
        if (value is! num || !value.toDouble().isFinite || value < 0) {
          valid = false;
          break;
        }
        parsed.add(value.toDouble());
      }
      if (valid) annotationDistances = List<double>.unmodifiable(parsed);
    }

    return TrafficRouteInfo(
      km: meters / 1000,
      minutes: seconds / 60,
      points: List<LatLng>.unmodifiable(points),
      congestion: List<String?>.unmodifiable(congestion),
      typicalMinutes: typicalSeconds == null ? null : typicalSeconds / 60,
      checkedAt: checkedAt,
      source: 'Mapbox',
      segments: List<TrafficSegment>.unmodifiable(segments),
      annotationDistances: annotationDistances,
    );
  } catch (_) {
    return null;
  } finally {
    if (client == null) connection.close();
  }
}

/// Busca una dirección en El Salvador con Nominatim (OpenStreetMap).
Future<GeoPoint?> geocode(String query) async {
  final q = query.trim();
  if (q.isEmpty) return null;
  final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
    'q': '$q, El Salvador',
    'format': 'json',
    'limit': '1',
    'countrycodes': 'sv',
  });
  final res = await http
      .get(uri, headers: {'User-Agent': 'RutaNeta/1.0'})
      .timeout(const Duration(seconds: 12));
  if (res.statusCode != 200) return null;
  final list = jsonDecode(res.body) as List;
  if (list.isEmpty) return null;
  final m = list.first as Map<String, dynamic>;
  final lat = double.tryParse('${m['lat']}');
  final lon = double.tryParse('${m['lon']}');
  if (lat == null || lon == null) return null;
  return GeoPoint(lat, lon);
}

/// Distancia, tiempo y trazo de la ruta por carretera con OSRM (sin tráfico).
Future<RouteInfo?> drivingRoute(GeoPoint a, GeoPoint b) async {
  final uri = Uri.parse(
    'https://router.project-osrm.org/route/v1/driving/'
    '${a.lon},${a.lat};${b.lon},${b.lat}?overview=full&geometries=geojson',
  );
  final res = await http.get(uri).timeout(const Duration(seconds: 15));
  if (res.statusCode != 200) return null;
  final j = jsonDecode(res.body) as Map<String, dynamic>;
  final routes = j['routes'] as List?;
  if (routes == null || routes.isEmpty) return null;
  final r = routes.first as Map<String, dynamic>;
  final meters = (r['distance'] as num).toDouble();
  final seconds = (r['duration'] as num).toDouble();
  final points = <LatLng>[];
  final geometry = r['geometry'] as Map<String, dynamic>?;
  final coords = geometry?['coordinates'] as List?;
  if (coords != null) {
    for (final c in coords) {
      final pair = c as List;
      points.add(
        LatLng((pair[1] as num).toDouble(), (pair[0] as num).toDouble()),
      );
    }
  }
  return RouteInfo(meters / 1000, seconds / 60, points);
}

/// Posición actual del teléfono, o null si no hay permiso o GPS apagado.
Future<LatLng?> currentLatLng() async {
  if (!await Geolocator.isLocationServiceEnabled()) return null;
  var perm = await Geolocator.checkPermission();
  if (perm == LocationPermission.denied) {
    perm = await Geolocator.requestPermission();
  }
  if (perm == LocationPermission.denied ||
      perm == LocationPermission.deniedForever) {
    return null;
  }
  final pos = await Geolocator.getCurrentPosition();
  return LatLng(pos.latitude, pos.longitude);
}

double haversineKm(GeoPoint a, GeoPoint b) {
  const r = 6371.0;
  double rad(double d) => d * pi / 180;
  final dLat = rad(b.lat - a.lat);
  final dLon = rad(b.lon - a.lon);
  final h =
      pow(sin(dLat / 2), 2) +
      cos(rad(a.lat)) * cos(rad(b.lat)) * pow(sin(dLon / 2), 2);
  return 2 * r * asin(sqrt(h));
}
