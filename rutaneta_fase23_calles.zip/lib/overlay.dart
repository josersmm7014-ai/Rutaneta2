import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import 'app_style.dart';
import 'ocr.dart';
import 'overlay_bridge.dart';
import 'traffic_review_panel.dart';
export 'overlay_controller.dart';

enum _Mode { idle, loading, review, result, error }

class OverlayBubble extends StatefulWidget {
  const OverlayBubble({super.key});
  @override
  State<OverlayBubble> createState() => _OverlayBubbleState();
}

class _OverlayBubbleState extends State<OverlayBubble> {
  bool compact = true;
  bool returnEmpty = true;
  bool saved = false;
  bool useTraffic = false;
  Map<String, dynamic>? selectedTraffic;
  String previousKm = '';
  String previousMinutes = '';
  double net = 0;
  double perHour = 0;
  bool homeMode = false;
  String _styleId = 'neta';
  bool _highVisibility = false;
  int _width = 310;
  int _height = 460;
  _Mode mode = _Mode.idle;
  String message = '';
  Map<String, dynamic> result = {};
  final price = TextEditingController();
  final km = TextEditingController();
  final minutes = TextEditingController();
  final goal = TextEditingController(text: '4.00');
  Timer? _timeout;
  int _operation = 0;

  @override
  void initState() {
    super.initState();
    _refreshSummary();
    _getBounds();
  }

  Future<void> _refreshSummary() async {
    try {
      _onData(await OverlayBridge.command('summary'));
    } catch (_) {}
  }

  Future<void> _command(String name) async {
    try {
      _onData(await OverlayBridge.command(name));
    } catch (e) {
      if (mounted)
        setState(() {
          mode = _Mode.error;
          message =
              'No respondió el servicio ($e). Abre RutaNeta y vuelve a activar la burbuja.';
        });
    }
  }

  Future<void> _getBounds() async {
    try {
      final screen = await FlutterOverlayWindow.getScreenSize().timeout(
        const Duration(seconds: 2),
      );
      if (screen.x > 0)
        _width = math.min(330, math.max(220, screen.x.round() - 24));
      if (screen.y > 0)
        _height = math.min(480, math.max(260, screen.y.round() - 140));
    } catch (_) {}
  }

  Future<void> _setCompact(bool value) async {
    if (!mounted) return;
    FocusScope.of(context).unfocus();
    setState(() => compact = value);
    // Al abrir la burbuja en reposo se vuelve a leer el resumen, que incluye
    // el tema elegido; así un cambio de tema se ve sin reiniciarla.
    if (!value && mode == _Mode.idle) unawaited(_refreshSummary());
    try {
      await FlutterOverlayWindow.updateFlag(
        value ? OverlayFlag.defaultFlag : OverlayFlag.focusPointer,
      ).timeout(const Duration(seconds: 2));
      await FlutterOverlayWindow.resizeOverlay(
        value ? 180 : _width,
        value ? 76 : _height,
        // Arrastrar la ventana solo en modo compacto. Expandida, el gesto de
        // arrastre compite con el scroll y reubica la ventana en cada frame.
        value,
      ).timeout(const Duration(seconds: 2));
    } catch (_) {}
  }

  void _onData(dynamic event) {
    if (!mounted) return;
    try {
      final map = event is Map
          ? Map<String, dynamic>.from(event)
          : jsonDecode('$event') as Map<String, dynamic>;
      if (!map.containsKey('state')) {
        setState(() {
          net = (map['net'] as num?)?.toDouble() ?? net;
          perHour = (map['perHour'] as num?)?.toDouble() ?? perHour;
          homeMode = map['homeMode'] as bool? ?? homeMode;
          _styleId = map['styleId'] as String? ?? _styleId;
          _highVisibility = map['highVisibility'] as bool? ?? _highVisibility;
          final rawTraffic = map['trafficTrip'];
          final next = rawTraffic is Map
              ? Map<String, dynamic>.from(rawTraffic)
              : null;
          if (useTraffic &&
              next?['destinationId'] != selectedTraffic?['destinationId']) {
            useTraffic = false;
            km.text = previousKm;
            minutes.text = previousMinutes;
            message = 'El destino del mapa cambió. Confirma la nueva ruta.';
          }
          selectedTraffic = next;
          if (map['targetNetPerHour'] is num && mode != _Mode.review) {
            goal.text = (map['targetNetPerHour'] as num).toStringAsFixed(2);
          }
        });
        return;
      }
      final state = map['state'];
      if (state != 'loading') _timeout?.cancel();
      setState(() {
        message = '${map['msg'] ?? ''}';
        if (state == 'review') {
          mode = _Mode.review;
          useTraffic = false;
          price.text = map['price'] == null ? '' : '${map['price']}';
          km.text = map['km'] == null ? '' : '${map['km']}';
          minutes.text = map['minutes'] == null ? '' : '${map['minutes']}';
        } else if (state == 'result') {
          mode = _Mode.result;
          result = map;
          saved = false;
        } else if (state == 'loading') {
          mode = _Mode.loading;
        } else if (state == 'saved') {
          saved = true;
        } else {
          mode = _Mode.error;
        }
      });
      if (state == 'review' || state == 'result' || state == 'error')
        _setCompact(false);
      if (state == 'review') _refreshSummary();
    } catch (_) {}
  }

  Future<void> _capture() async {
    if (mode == _Mode.loading) return;
    _timeout?.cancel();
    final operation = ++_operation;
    setState(() {
      mode = _Mode.loading;
      message = '1/3 · Solicitando imagen de pantalla…';
    });
    _timeout = Timer(const Duration(seconds: 22), () {
      if (mounted && operation == _operation && mode == _Mode.loading) {
        _operation++;
        setState(() {
          mode = _Mode.error;
          message =
              'La lectura agotó el tiempo de espera. Puedes ingresar el viaje manualmente.';
        });
      }
    });
    try {
      await _setCompact(false);
      final path = await OverlayBridge.capture();
      if (!mounted || operation != _operation) return;
      setState(() => message = '2/3 · Reconociendo precio, km y minutos…');
      final detected = await readScreenshot(
        path,
      ).timeout(const Duration(seconds: 12));
      if (!mounted || operation != _operation) return;
      _onData({
        'state': 'review',
        'price': detected.price,
        'km': detected.km,
        'minutes': detected.minutes,
        'msg': detected.warnings.isEmpty
            ? '3/3 · Revisa los datos y pulsa CALCULAR.'
            : '3/3 · ${detected.warnings.join(' ')}',
      });
    } catch (e) {
      if (mounted && operation == _operation)
        _onData({
          'state': 'error',
          'msg':
              'La lectura falló: $e. Activa la captura desde Inicio o ingresa los datos manualmente.',
        });
    } finally {
      if (operation == _operation) _timeout?.cancel();
    }
  }

  void _manual() {
    _operation++;
    _timeout?.cancel();
    setState(() {
      mode = _Mode.review;
      message = 'Ingresa los datos del viaje';
      useTraffic = false;
    });
    _setCompact(false);
    _refreshSummary();
  }

  void _toggleTraffic(bool enabled) {
    setState(() {
      if (enabled && selectedTraffic != null) {
        previousKm = km.text;
        previousMinutes = minutes.text;
        km.text = (selectedTraffic!['km'] as num).toStringAsFixed(2);
        minutes.text = (selectedTraffic!['minutes'] as num).toStringAsFixed(1);
      } else if (useTraffic) {
        km.text = previousKm;
        minutes.text = previousMinutes;
      }
      useTraffic = enabled;
    });
  }

  Future<void> _calculate() async {
    double? number(TextEditingController c) =>
        double.tryParse(c.text.trim().replaceAll(',', '.'));
    final p = number(price), d = number(km), t = number(minutes);
    if (p == null ||
        d == null ||
        t == null ||
        ![p, d, t].every((v) => v.isFinite && v > 0)) {
      setState(
        () => message = 'Completa los tres datos con valores mayores que cero.',
      );
      return;
    }
    final target = number(goal);
    if (target == null || !target.isFinite || target <= 0) {
      setState(
        () => message = 'El objetivo neto por hora debe ser mayor que cero.',
      );
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      mode = _Mode.loading;
      message = 'Calculando rentabilidad…';
    });
    _timeout?.cancel();
    final operation = ++_operation;
    try {
      final reply = await OverlayBridge.command('calculate', {
        'id': DateTime.now().microsecondsSinceEpoch.toString(),
        'price': p,
        'km': d,
        'minutes': t,
        'returnEmpty': returnEmpty,
        'targetNetPerHour': target,
        'useTraffic': useTraffic,
        'confirmTrafficRoute': useTraffic,
        'trafficDestinationId': selectedTraffic?['destinationId'],
      });
      if (mounted && operation == _operation) _onData(reply);
    } catch (e) {
      if (mounted && operation == _operation)
        _onData({
          'state': 'error',
          'msg':
              'No llegó el cálculo: $e. Abre RutaNeta y vuelve a activar la burbuja.',
        });
    }
  }

  @override
  void dispose() {
    _timeout?.cancel();
    _operation++;
    price.dispose();
    km.dispose();
    minutes.dispose();
    goal.dispose();
    super.dispose();
  }

  String _money(dynamic value) =>
      '\$${((value as num?)?.toDouble() ?? 0).toStringAsFixed(2)}';

  Color get _signalColor => result['signal'] == 'red'
      ? const Color(0xFFFF5C6C)
      : result['signal'] == 'yellow'
      ? const Color(0xFFFFD54F)
      : const Color(0xFF4ADE80);

  Widget _trafficLights() => Semantics(
    label: 'Resultado del viaje: ${result['verdict']}',
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        for (final entry in const {
          'red': Color(0xFFFF5C6C),
          'yellow': Color(0xFFFFD54F),
          'green': Color(0xFF4ADE80),
        }.entries)
          Container(
            key: ValueKey('traffic-${entry.key}'),
            width: 24,
            height: 24,
            margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: entry.value.withValues(
                alpha: result['signal'] == entry.key ? 1 : 0.15,
              ),
              border: Border.all(
                color: entry.value,
                width: result['signal'] == entry.key ? 2 : 1,
              ),
            ),
          ),
      ],
    ),
  );

  Future<void> _copyFare() async {
    try {
      final value = (result['recommendedFare'] as num).toDouble();
      await Clipboard.setData(ClipboardData(text: value.toStringAsFixed(2)));
      if (mounted)
        setState(() => message = 'Tarifa copiada. Tú decides si la ofreces.');
    } catch (_) {
      if (mounted)
        setState(
          () => message =
              'No se pudo copiar. Puedes escribir la tarifa manualmente.',
        );
    }
  }

  Widget _button(
    String label,
    VoidCallback? action, {
    bool secondary = false,
  }) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: secondary
        ? OutlinedButton(onPressed: action, child: Text(label))
        : FilledButton(onPressed: action, child: Text(label)),
  );
  Widget _field(
    String label,
    TextEditingController controller, {
    bool routeMetric = false,
  }) => Padding(
    padding: const EdgeInsets.only(top: 8),
    child: TextField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: label,
        isDense: true,
        border: const OutlineInputBorder(),
      ),
      onTap: () => FlutterOverlayWindow.resizeOverlay(_width, _height, false),
      onChanged: (_) {
        if (routeMetric && useTraffic) setState(() => useTraffic = false);
      },
    ),
  );

  @override
  Widget build(BuildContext context) {
    final style = styleById(_styleId);
    final green = style.accentFor(_highVisibility);
    final bubbleColor = style.bgDark.withValues(alpha: 0.95);
    final borderColor = mode == _Mode.result ? _signalColor : green;
    if (compact) {
      return Material(
        color: Colors.transparent,
        child: Container(
          margin: const EdgeInsets.all(4),
          decoration: BoxDecoration(
            color: bubbleColor,
            borderRadius: BorderRadius.circular(
              (style.radiusPanel * 1.33).clamp(8.0, 34.0).toDouble(),
            ),
            border: Border.all(color: borderColor, width: 2),
          ),
          child: Row(
            children: [
              Expanded(
                child: InkWell(
                  onTap: () => _setCompact(false),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          mode == _Mode.result
                              ? _money(result['net'])
                              : 'RutaNeta',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        if (mode == _Mode.result)
                          Text(
                            '${result['verdict']}',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: borderColor,
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
              IconButton(
                tooltip: 'Leer viaje de pantalla',
                onPressed: _capture,
                icon: Icon(style.icons.calculate, color: borderColor),
              ),
            ],
          ),
        ),
      );
    }
    final children = <Widget>[];
    if (mode == _Mode.loading) {
      children.addAll([
        const SizedBox(height: 28),
        const Center(child: CircularProgressIndicator()),
        const SizedBox(height: 20),
        Text(message, textAlign: TextAlign.center),
        _button('CANCELAR Y ESCRIBIR DATOS', _manual, secondary: true),
      ]);
    } else if (mode == _Mode.review) {
      children.addAll([
        Text(message),
        _field('Precio del viaje (\$)', price),
        _field('Distancia (km)', km, routeMetric: true),
        _field('Tiempo del viaje (min)', minutes, routeMetric: true),
        _field('Objetivo neto por hora (\$/h)', goal),
        Row(
          children: [
            const Expanded(
              child: Text(
                'Incluir regreso vacío',
                style: TextStyle(fontSize: 13),
              ),
            ),
            Switch(
              value: returnEmpty,
              onChanged: (v) {
                setState(() => returnEmpty = v);
                if (useTraffic &&
                    v &&
                    selectedTraffic?['returnMinutes'] == null)
                  _toggleTraffic(false);
              },
            ),
          ],
        ),
        TrafficReviewPanel(
          route: selectedTraffic,
          returnEmpty: returnEmpty,
          selected: useTraffic,
          onSelected: _toggleTraffic,
          onRefresh: _refreshSummary,
        ),
        _button('CALCULAR CON ESTOS DATOS', _calculate),
        _button('VOLVER A LEER PANTALLA', _capture, secondary: true),
      ]);
    } else if (mode == _Mode.result) {
      final increase = (result['requiredIncrease'] as num?)?.toDouble() ?? 0;
      children.addAll([
        _trafficLights(),
        Text(
          '${result['verdict']}',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: _signalColor,
            fontSize: 25,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          'Neto estimado ${_money(result['net'])}',
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        Text(
          '${_money(result['perHour'])} por hora · Tarifa ${_money(result['price'])}',
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _signalColor.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(style.radiusField),
            border: Border.all(color: _signalColor),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'TARIFA RECOMENDADA',
                style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
              ),
              Text(
                _money(result['recommendedFare']),
                style: const TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Text(
                'Para alcanzar ${_money(result['targetNetPerHour'])} netos por hora.',
              ),
              if (result['trafficUsed'] == true)
                const Text(
                  'Calculada con los tiempos de la ruta consultada.',
                  style: TextStyle(fontSize: 12),
                ),
              if (result['trafficFareIncrease'] != null)
                Text(
                  'El tráfico añade ${_money(result['trafficFareIncrease'])} frente al tiempo habitual.',
                  style: const TextStyle(fontSize: 12),
                ),
              const SizedBox(height: 6),
              Text(
                'Mínimo para cubrir costos: ${_money(result['breakEvenFare'])}',
              ),
              Text(
                increase > 0
                    ? 'Sube tu oferta ${_money(increase)}.'
                    : 'Tu oferta ya alcanza el objetivo. No hace falta bajarla.',
              ),
              Text(
                'Con la tarifa recomendada: ${_money(result['projectedNet'])} netos estimados.',
              ),
              if (increase > 0)
                _button('COPIAR TARIFA', _copyFare, secondary: true),
            ],
          ),
        ),
        if (message.isNotEmpty) Text(message),
        const SizedBox(height: 8),
        Text('${result['km']} km · ${result['minutes']} min'),
        if (result['trafficUsed'] == true && result['traffic'] is Map) ...[
          Text(
            'Destino: ${result['traffic']['destination']}',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          Text(
            '${result['traffic']['status']} · consultado ${trafficConsultedTime(result['traffic']['checkedAt'])}',
            style: const TextStyle(fontSize: 12),
          ),
          if (result['trafficDelayMinutes'] != null)
            Text(
              'Demora frente al tiempo habitual: ${(result['trafficDelayMinutes'] as num).toStringAsFixed(0)} min',
              style: const TextStyle(fontSize: 12),
            ),
          if (result['returnEmpty'] == true)
            Text(
              'Vuelta: ${result['returnKm']} km · ${result['returnMinutes']} min',
              style: const TextStyle(fontSize: 12),
            ),
          const Text(
            'Cobertura parcial posible: los tramos sin datos no se consideran libres.',
            style: TextStyle(fontSize: 11),
          ),
        ],
        Text(
          'Combustible: ${_money(result['fuel'])}\nComisión (15%): ${_money(result['commission'])}\nDesgaste: ${_money(result['wear'])}',
        ),
        Text(
          result['returnEmpty'] == true
              ? 'Incluye regreso vacío en tiempo y costos.'
              : 'Sin regreso vacío.',
        ),
        const Text(
          'Estimación con los datos indicados. Suma la recogida si deseas incluirla.',
          style: TextStyle(fontSize: 11),
        ),
        _button(
          saved ? 'VIAJE GUARDADO' : 'GUARDAR VIAJE',
          saved ? null : () => _command('saveTrip'),
        ),
        _button('NUEVA CAPTURA', _capture),
        _button('EDITAR DATOS', _manual, secondary: true),
      ]);
    } else if (mode == _Mode.error) {
      children.addAll([
        const Icon(Icons.error_outline, color: Colors.orangeAccent, size: 34),
        Text(message),
        _button('REINTENTAR CAPTURA', _capture),
        _button('INGRESAR DATOS MANUALMENTE', _manual, secondary: true),
      ]);
    } else {
      children.addAll([
        Text(
          'Neto hoy: ${_money(net)}',
          style: const TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
        ),
        Text('${_money(perHour)} por hora'),
        _button('LEER VIAJE DE PANTALLA', _capture),
        _button('INGRESAR VIAJE MANUALMENTE', _manual, secondary: true),
        _button(
          homeMode ? 'HACIA CASA ACTIVO' : 'HACIA CASA',
          () => _command('toggleHome'),
          secondary: true,
        ),
        const SizedBox(height: 10),
        const Text(
          'Configura y revisa los datos con el vehículo detenido.',
          style: TextStyle(fontSize: 11),
        ),
      ]);
    }
    return Theme(
      data: ThemeData.dark(useMaterial3: true).copyWith(
        colorScheme: ColorScheme.fromSeed(
          seedColor: green,
          brightness: Brightness.dark,
        ),
        textTheme: ThemeData.dark(
          useMaterial3: true,
        ).textTheme.apply(fontFamily: style.fontFamily),
        inputDecorationTheme: InputDecorationTheme(
          border: style.underlineFields
              ? const UnderlineInputBorder()
              : OutlineInputBorder(
                  borderRadius: BorderRadius.circular(style.radiusField),
                ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: _highVisibility
                ? const Color(0xFFFFD54F)
                : style.buttonColor,
            foregroundColor: Colors.black,
            minimumSize: const Size.fromHeight(46),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(style.radiusButton),
            ),
          ),
        ),
      ),
      child: Material(
        color: Colors.transparent,
        child: Container(
          margin: const EdgeInsets.all(4),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: bubbleColor,
            borderRadius: BorderRadius.circular(style.radiusCard),
            border: Border.all(color: borderColor, width: 2),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'RutaNeta',
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  IconButton(
                    tooltip: 'Reducir',
                    onPressed: () => _setCompact(true),
                    icon: const Icon(Icons.close_fullscreen),
                  ),
                  IconButton(
                    tooltip: 'Cerrar burbuja',
                    onPressed: () => FlutterOverlayWindow.closeOverlay(),
                    icon: const Icon(Icons.close),
                  ),
                ],
              ),
              const Divider(height: 8),
              Expanded(
                child: SingleChildScrollView(
                  physics: const ClampingScrollPhysics(),
                  child: RepaintBoundary(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: children,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
